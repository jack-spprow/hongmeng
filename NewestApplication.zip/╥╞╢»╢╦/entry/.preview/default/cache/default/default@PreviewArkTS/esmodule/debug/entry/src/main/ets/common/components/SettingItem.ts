if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface SettingItem_Params {
    title?: string;
    route?: string;
    isDestructive?: boolean;
}
import { Router } from "@normalized:N&&&entry/src/main/ets/common/router/Router&";
export class SettingItem extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.__title = new SynchedPropertySimpleOneWayPU(params.title, this, "title");
        this.__route = new SynchedPropertySimpleOneWayPU(params.route, this, "route");
        this.__isDestructive = new SynchedPropertySimpleOneWayPU(params.isDestructive, this, "isDestructive");
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: SettingItem_Params) {
        if (params.isDestructive === undefined) {
            this.__isDestructive.set(false // 是否为危险操作（按钮）
            );
        }
    }
    updateStateVars(params: SettingItem_Params) {
        this.__title.reset(params.title);
        this.__route.reset(params.route);
        this.__isDestructive.reset(params.isDestructive);
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__title.purgeDependencyOnElmtId(rmElmtId);
        this.__route.purgeDependencyOnElmtId(rmElmtId);
        this.__isDestructive.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__title.aboutToBeDeleted();
        this.__route.aboutToBeDeleted();
        this.__isDestructive.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    private __title: SynchedPropertySimpleOneWayPU<string>;
    get title() {
        return this.__title.get();
    }
    set title(newValue: string) {
        this.__title.set(newValue);
    }
    private __route: SynchedPropertySimpleOneWayPU<string>;
    get route() {
        return this.__route.get();
    }
    set route(newValue: string) {
        this.__route.set(newValue);
    }
    private __isDestructive: SynchedPropertySimpleOneWayPU<boolean>; // 是否为危险操作（按钮）
    get isDestructive() {
        return this.__isDestructive.get();
    }
    set isDestructive(newValue: boolean) {
        this.__isDestructive.set(newValue);
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            If.create();
            // 判断是否为退出按钮样式
            if (this.isDestructive) {
                this.ifElseBranchUpdateFunction(0, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Button.createWithLabel(this.title);
                        Button.debugLine("entry/src/main/ets/common/components/SettingItem.ets(12:7)", "entry");
                        Button.fontSize(18);
                        Button.fontColor(Color.White);
                        Button.backgroundColor(Color.Red);
                        Button.borderRadius(12);
                        Button.padding(16);
                        Button.margin({ top: 10, bottom: 10 });
                        Button.width('100%');
                        Button.onClick(() => {
                            Router.push(this.route);
                        });
                    }, Button);
                    Button.pop();
                });
            }
            else {
                this.ifElseBranchUpdateFunction(1, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Row.create();
                        Row.debugLine("entry/src/main/ets/common/components/SettingItem.ets(24:7)", "entry");
                        Row.padding(16);
                        Row.backgroundColor('#f5f5f5');
                        Row.borderRadius(8);
                        Row.margin({ bottom: 10 });
                        Row.onClick(() => {
                            Router.push(this.route);
                        });
                        Row.justifyContent(FlexAlign.SpaceBetween);
                        Row.alignItems(VerticalAlign.Center);
                        Row.width('100%');
                    }, Row);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create(this.title);
                        Text.debugLine("entry/src/main/ets/common/components/SettingItem.ets(25:9)", "entry");
                        Text.fontSize(18);
                    }, Text);
                    Text.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Image.create({ "id": 0, "type": 30000, params: ['icon/chevron_right.svg'], "bundleName": "com.example.myapplication", "moduleName": "entry" });
                        Image.debugLine("entry/src/main/ets/common/components/SettingItem.ets(27:9)", "entry");
                        Image.width(16);
                        Image.height(16);
                    }, Image);
                    Row.pop();
                });
            }
        }, If);
        If.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
}
