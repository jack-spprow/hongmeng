if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface ProfileSettings_Params {
    userName?: string;
    email?: string;
    phone?: string;
    intro?: string;
    avatarUrl?: string;
}
class ProfileSettings extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.__userName = new ObservedPropertySimplePU('张三', this, "userName");
        this.__email = new ObservedPropertySimplePU('zhangsan@example.com', this, "email");
        this.__phone = new ObservedPropertySimplePU('138****8888', this, "phone");
        this.__intro = new ObservedPropertySimplePU('', this, "intro");
        this.__avatarUrl = new ObservedPropertySimplePU('/common/default_avatar.png', this, "avatarUrl");
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: ProfileSettings_Params) {
        if (params.userName !== undefined) {
            this.userName = params.userName;
        }
        if (params.email !== undefined) {
            this.email = params.email;
        }
        if (params.phone !== undefined) {
            this.phone = params.phone;
        }
        if (params.intro !== undefined) {
            this.intro = params.intro;
        }
        if (params.avatarUrl !== undefined) {
            this.avatarUrl = params.avatarUrl;
        }
    }
    updateStateVars(params: ProfileSettings_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__userName.purgeDependencyOnElmtId(rmElmtId);
        this.__email.purgeDependencyOnElmtId(rmElmtId);
        this.__phone.purgeDependencyOnElmtId(rmElmtId);
        this.__intro.purgeDependencyOnElmtId(rmElmtId);
        this.__avatarUrl.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__userName.aboutToBeDeleted();
        this.__email.aboutToBeDeleted();
        this.__phone.aboutToBeDeleted();
        this.__intro.aboutToBeDeleted();
        this.__avatarUrl.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    private __userName: ObservedPropertySimplePU<string>;
    get userName() {
        return this.__userName.get();
    }
    set userName(newValue: string) {
        this.__userName.set(newValue);
    }
    private __email: ObservedPropertySimplePU<string>;
    get email() {
        return this.__email.get();
    }
    set email(newValue: string) {
        this.__email.set(newValue);
    }
    private __phone: ObservedPropertySimplePU<string>;
    get phone() {
        return this.__phone.get();
    }
    set phone(newValue: string) {
        this.__phone.set(newValue);
    }
    private __intro: ObservedPropertySimplePU<string>;
    get intro() {
        return this.__intro.get();
    }
    set intro(newValue: string) {
        this.__intro.set(newValue);
    }
    private __avatarUrl: ObservedPropertySimplePU<string>;
    get avatarUrl() {
        return this.__avatarUrl.get();
    }
    set avatarUrl(newValue: string) {
        this.__avatarUrl.set(newValue);
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create({ space: 20 });
            Column.debugLine("entry/src/main/ets/pages/settings/ProfileSettings.ets(12:5)", "entry");
            Column.padding(20);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Image.create(this.avatarUrl);
            Image.debugLine("entry/src/main/ets/pages/settings/ProfileSettings.ets(13:7)", "entry");
            Image.width(100);
            Image.height(100);
            Image.borderRadius(50);
            Image.onClick(() => {
                console.log('上传头像功能触发');
            });
        }, Image);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            TextInput.create({ placeholder: '用户名', text: this.userName });
            TextInput.debugLine("entry/src/main/ets/pages/settings/ProfileSettings.ets(21:7)", "entry");
            TextInput.onChange((value: string) => this.userName = value);
        }, TextInput);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            TextInput.create({ placeholder: '邮箱', text: this.email });
            TextInput.debugLine("entry/src/main/ets/pages/settings/ProfileSettings.ets(24:7)", "entry");
            TextInput.onChange((value: string) => this.email = value);
        }, TextInput);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            TextInput.create({ placeholder: '手机号', text: this.phone });
            TextInput.debugLine("entry/src/main/ets/pages/settings/ProfileSettings.ets(27:7)", "entry");
            TextInput.onChange((value: string) => this.phone = value);
        }, TextInput);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            TextInput.create({ placeholder: '个人简介', text: this.intro });
            TextInput.debugLine("entry/src/main/ets/pages/settings/ProfileSettings.ets(30:7)", "entry");
            TextInput.onChange((value: string) => this.intro = value);
        }, TextInput);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Button.createWithLabel('修改密码');
            Button.debugLine("entry/src/main/ets/pages/settings/ProfileSettings.ets(33:7)", "entry");
            Button.onClick(() => {
                console.log('跳转到修改密码页');
            });
        }, Button);
        Button.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Button.createWithLabel('保存');
            Button.debugLine("entry/src/main/ets/pages/settings/ProfileSettings.ets(38:7)", "entry");
            Button.type(ButtonType.Capsule);
            Button.onClick(() => {
                console.log('保存用户资料');
            });
        }, Button);
        Button.pop();
        Column.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
    static getEntryName(): string {
        return "ProfileSettings";
    }
}
registerNamedRoute(() => new ProfileSettings(undefined, {}), "", { bundleName: "com.example.myapplication", moduleName: "entry", pagePath: "pages/settings/ProfileSettings", pageFullPath: "entry/src/main/ets/pages/settings/ProfileSettings", integratedHsp: "false", moduleType: "followWithHap" });
