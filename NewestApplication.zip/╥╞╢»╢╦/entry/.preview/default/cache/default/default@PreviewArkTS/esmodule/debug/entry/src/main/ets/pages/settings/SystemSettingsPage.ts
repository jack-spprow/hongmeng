if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface SystemSettingsPage_Params {
}
import { Routes } from "@normalized:N&&&entry/src/main/ets/pages/common/constants/Routes&";
import { SettingItem } from "@normalized:N&&&entry/src/main/ets/pages/common/components/SettingItem&";
class SystemSettingsPage extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: SystemSettingsPage_Params) {
    }
    updateStateVars(params: SystemSettingsPage_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
    }
    aboutToBeDeleted() {
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/settings/SystemSettingsPage.ets(10:5)", "entry");
            Column.height('100%');
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 固定在顶部的标题
            Text.create('系统设置');
            Text.debugLine("entry/src/main/ets/pages/settings/SystemSettingsPage.ets(12:9)", "entry");
            // 固定在顶部的标题
            Text.fontSize(26);
            // 固定在顶部的标题
            Text.fontWeight(FontWeight.Bold);
            // 固定在顶部的标题
            Text.padding({
                top: 10,
                bottom: 10,
                left: 20,
                right: 20
            });
        }, Text);
        // 固定在顶部的标题
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Scroll.create();
            Scroll.debugLine("entry/src/main/ets/pages/settings/SystemSettingsPage.ets(21:7)", "entry");
            Scroll.layoutWeight(1);
        }, Scroll);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/settings/SystemSettingsPage.ets(22:9)", "entry");
            Column.padding({ left: 20, right: 20, bottom: 20 });
            Column.width('100%');
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 第一组：1 ~ 3（无间距）
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/settings/SystemSettingsPage.ets(24:11)", "entry");
            // 第一组：1 ~ 3（无间距）
            Column.padding({ bottom: 20 });
            // 第一组：1 ~ 3（无间距）
            Column.width('100%');
        }, Column);
        {
            this.observeComponentCreation2((elmtId, isInitialRender) => {
                if (isInitialRender) {
                    let componentCall = new SettingItem(this, { title: '个人信息', route: Routes.PROFILE }, undefined, elmtId, () => { }, { page: "entry/src/main/ets/pages/settings/SystemSettingsPage.ets", line: 25, col: 13 });
                    ViewPU.create(componentCall);
                    let paramsLambda = () => {
                        return {
                            title: '个人信息',
                            route: Routes.PROFILE
                        };
                    };
                    componentCall.paramsGenerator_ = paramsLambda;
                }
                else {
                    this.updateStateVarsOfChildByElmtId(elmtId, {
                        title: '个人信息', route: Routes.PROFILE
                    });
                }
            }, { name: "SettingItem" });
        }
        {
            this.observeComponentCreation2((elmtId, isInitialRender) => {
                if (isInitialRender) {
                    let componentCall = new SettingItem(this, { title: '账号与安全', route: Routes.ACCOUNT }, undefined, elmtId, () => { }, { page: "entry/src/main/ets/pages/settings/SystemSettingsPage.ets", line: 26, col: 13 });
                    ViewPU.create(componentCall);
                    let paramsLambda = () => {
                        return {
                            title: '账号与安全',
                            route: Routes.ACCOUNT
                        };
                    };
                    componentCall.paramsGenerator_ = paramsLambda;
                }
                else {
                    this.updateStateVarsOfChildByElmtId(elmtId, {
                        title: '账号与安全', route: Routes.ACCOUNT
                    });
                }
            }, { name: "SettingItem" });
        }
        {
            this.observeComponentCreation2((elmtId, isInitialRender) => {
                if (isInitialRender) {
                    let componentCall = new SettingItem(this, { title: '通知设置', route: Routes.NOTIFY }, undefined, elmtId, () => { }, { page: "entry/src/main/ets/pages/settings/SystemSettingsPage.ets", line: 27, col: 13 });
                    ViewPU.create(componentCall);
                    let paramsLambda = () => {
                        return {
                            title: '通知设置',
                            route: Routes.NOTIFY
                        };
                    };
                    componentCall.paramsGenerator_ = paramsLambda;
                }
                else {
                    this.updateStateVarsOfChildByElmtId(elmtId, {
                        title: '通知设置', route: Routes.NOTIFY
                    });
                }
            }, { name: "SettingItem" });
        }
        // 第一组：1 ~ 3（无间距）
        Column.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 第二组：4 ~ 7（无间距）
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/settings/SystemSettingsPage.ets(33:11)", "entry");
            // 第二组：4 ~ 7（无间距）
            Column.padding({ bottom: 20 });
            // 第二组：4 ~ 7（无间距）
            Column.width('100%');
        }, Column);
        {
            this.observeComponentCreation2((elmtId, isInitialRender) => {
                if (isInitialRender) {
                    let componentCall = new SettingItem(this, { title: '全局护眼', route: Routes.EYECARE }, undefined, elmtId, () => { }, { page: "entry/src/main/ets/pages/settings/SystemSettingsPage.ets", line: 34, col: 13 });
                    ViewPU.create(componentCall);
                    let paramsLambda = () => {
                        return {
                            title: '全局护眼',
                            route: Routes.EYECARE
                        };
                    };
                    componentCall.paramsGenerator_ = paramsLambda;
                }
                else {
                    this.updateStateVarsOfChildByElmtId(elmtId, {
                        title: '全局护眼', route: Routes.EYECARE
                    });
                }
            }, { name: "SettingItem" });
        }
        {
            this.observeComponentCreation2((elmtId, isInitialRender) => {
                if (isInitialRender) {
                    let componentCall = new SettingItem(this, { title: '家长监督', route: Routes.PARENT }, undefined, elmtId, () => { }, { page: "entry/src/main/ets/pages/settings/SystemSettingsPage.ets", line: 35, col: 13 });
                    ViewPU.create(componentCall);
                    let paramsLambda = () => {
                        return {
                            title: '家长监督',
                            route: Routes.PARENT
                        };
                    };
                    componentCall.paramsGenerator_ = paramsLambda;
                }
                else {
                    this.updateStateVarsOfChildByElmtId(elmtId, {
                        title: '家长监督', route: Routes.PARENT
                    });
                }
            }, { name: "SettingItem" });
        }
        {
            this.observeComponentCreation2((elmtId, isInitialRender) => {
                if (isInitialRender) {
                    let componentCall = new SettingItem(this, { title: '清除缓存', route: Routes.CACHE }, undefined, elmtId, () => { }, { page: "entry/src/main/ets/pages/settings/SystemSettingsPage.ets", line: 36, col: 13 });
                    ViewPU.create(componentCall);
                    let paramsLambda = () => {
                        return {
                            title: '清除缓存',
                            route: Routes.CACHE
                        };
                    };
                    componentCall.paramsGenerator_ = paramsLambda;
                }
                else {
                    this.updateStateVarsOfChildByElmtId(elmtId, {
                        title: '清除缓存', route: Routes.CACHE
                    });
                }
            }, { name: "SettingItem" });
        }
        {
            this.observeComponentCreation2((elmtId, isInitialRender) => {
                if (isInitialRender) {
                    let componentCall = new SettingItem(this, { title: '个性化推荐', route: Routes.RECOMMEND }, undefined, elmtId, () => { }, { page: "entry/src/main/ets/pages/settings/SystemSettingsPage.ets", line: 37, col: 13 });
                    ViewPU.create(componentCall);
                    let paramsLambda = () => {
                        return {
                            title: '个性化推荐',
                            route: Routes.RECOMMEND
                        };
                    };
                    componentCall.paramsGenerator_ = paramsLambda;
                }
                else {
                    this.updateStateVarsOfChildByElmtId(elmtId, {
                        title: '个性化推荐', route: Routes.RECOMMEND
                    });
                }
            }, { name: "SettingItem" });
        }
        // 第二组：4 ~ 7（无间距）
        Column.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 第三组：8 ~ 11（无间距）
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/settings/SystemSettingsPage.ets(43:11)", "entry");
            // 第三组：8 ~ 11（无间距）
            Column.padding({ bottom: 20 });
            // 第三组：8 ~ 11（无间距）
            Column.width('100%');
        }, Column);
        {
            this.observeComponentCreation2((elmtId, isInitialRender) => {
                if (isInitialRender) {
                    let componentCall = new SettingItem(this, { title: '关于', route: Routes.ABOUT }, undefined, elmtId, () => { }, { page: "entry/src/main/ets/pages/settings/SystemSettingsPage.ets", line: 44, col: 13 });
                    ViewPU.create(componentCall);
                    let paramsLambda = () => {
                        return {
                            title: '关于',
                            route: Routes.ABOUT
                        };
                    };
                    componentCall.paramsGenerator_ = paramsLambda;
                }
                else {
                    this.updateStateVarsOfChildByElmtId(elmtId, {
                        title: '关于', route: Routes.ABOUT
                    });
                }
            }, { name: "SettingItem" });
        }
        {
            this.observeComponentCreation2((elmtId, isInitialRender) => {
                if (isInitialRender) {
                    let componentCall = new SettingItem(this, { title: '个人信息收集清单', route: Routes.PRIVACY }, undefined, elmtId, () => { }, { page: "entry/src/main/ets/pages/settings/SystemSettingsPage.ets", line: 45, col: 13 });
                    ViewPU.create(componentCall);
                    let paramsLambda = () => {
                        return {
                            title: '个人信息收集清单',
                            route: Routes.PRIVACY
                        };
                    };
                    componentCall.paramsGenerator_ = paramsLambda;
                }
                else {
                    this.updateStateVarsOfChildByElmtId(elmtId, {
                        title: '个人信息收集清单', route: Routes.PRIVACY
                    });
                }
            }, { name: "SettingItem" });
        }
        {
            this.observeComponentCreation2((elmtId, isInitialRender) => {
                if (isInitialRender) {
                    let componentCall = new SettingItem(this, { title: '第三方信息共享清单', route: Routes.THIRD }, undefined, elmtId, () => { }, { page: "entry/src/main/ets/pages/settings/SystemSettingsPage.ets", line: 46, col: 13 });
                    ViewPU.create(componentCall);
                    let paramsLambda = () => {
                        return {
                            title: '第三方信息共享清单',
                            route: Routes.THIRD
                        };
                    };
                    componentCall.paramsGenerator_ = paramsLambda;
                }
                else {
                    this.updateStateVarsOfChildByElmtId(elmtId, {
                        title: '第三方信息共享清单', route: Routes.THIRD
                    });
                }
            }, { name: "SettingItem" });
        }
        {
            this.observeComponentCreation2((elmtId, isInitialRender) => {
                if (isInitialRender) {
                    let componentCall = new SettingItem(this, { title: '退出登录', route: Routes.LOGOUT, isDestructive: true }, undefined, elmtId, () => { }, { page: "entry/src/main/ets/pages/settings/SystemSettingsPage.ets", line: 47, col: 13 });
                    ViewPU.create(componentCall);
                    let paramsLambda = () => {
                        return {
                            title: '退出登录',
                            route: Routes.LOGOUT,
                            isDestructive: true
                        };
                    };
                    componentCall.paramsGenerator_ = paramsLambda;
                }
                else {
                    this.updateStateVarsOfChildByElmtId(elmtId, {
                        title: '退出登录', route: Routes.LOGOUT, isDestructive: true
                    });
                }
            }, { name: "SettingItem" });
        }
        // 第三组：8 ~ 11（无间距）
        Column.pop();
        Column.pop();
        Scroll.pop();
        Column.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
    static getEntryName(): string {
        return "SystemSettingsPage";
    }
}
registerNamedRoute(() => new SystemSettingsPage(undefined, {}), "", { bundleName: "com.example.myapplication", moduleName: "entry", pagePath: "pages/settings/SystemSettingsPage", pageFullPath: "entry/src/main/ets/pages/settings/SystemSettingsPage", integratedHsp: "false", moduleType: "followWithHap" });
