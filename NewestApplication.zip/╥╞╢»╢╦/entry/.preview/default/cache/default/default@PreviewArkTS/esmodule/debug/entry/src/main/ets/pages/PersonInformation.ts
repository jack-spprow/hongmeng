if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface PersonInformation_Params {
    tags?: Array<string>;
    selectedTags?: Set<number>;
    text?: string;
    controller?: TextInputController;
    textError?: string;
}
import router from "@ohos:router";
export default class PersonInformation extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.__tags = new ObservedPropertyObjectPU([
            "Harmony", "OS", "ArkTS", "OpenHarmony", "DevEco", "UI", "AI", "IoT"
        ], this, "tags");
        this.__selectedTags = new ObservedPropertyObjectPU(new Set(), this, "selectedTags");
        this.__text = new ObservedPropertySimplePU('', this, "text");
        this.controller = new TextInputController();
        this.__textError = new ObservedPropertySimplePU('', this, "textError");
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: PersonInformation_Params) {
        if (params.tags !== undefined) {
            this.tags = params.tags;
        }
        if (params.selectedTags !== undefined) {
            this.selectedTags = params.selectedTags;
        }
        if (params.text !== undefined) {
            this.text = params.text;
        }
        if (params.controller !== undefined) {
            this.controller = params.controller;
        }
        if (params.textError !== undefined) {
            this.textError = params.textError;
        }
    }
    updateStateVars(params: PersonInformation_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__tags.purgeDependencyOnElmtId(rmElmtId);
        this.__selectedTags.purgeDependencyOnElmtId(rmElmtId);
        this.__text.purgeDependencyOnElmtId(rmElmtId);
        this.__textError.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__tags.aboutToBeDeleted();
        this.__selectedTags.aboutToBeDeleted();
        this.__text.aboutToBeDeleted();
        this.__textError.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    //所有可选的兴趣标签
    private __tags: ObservedPropertyObjectPU<Array<string>>;
    get tags() {
        return this.__tags.get();
    }
    set tags(newValue: Array<string>) {
        this.__tags.set(newValue);
    }
    // 被选中的标签（存储索引）
    private __selectedTags: ObservedPropertyObjectPU<Set<number>>;
    get selectedTags() {
        return this.__selectedTags.get();
    }
    set selectedTags(newValue: Set<number>) {
        this.__selectedTags.set(newValue);
    }
    private __text: ObservedPropertySimplePU<string>;
    get text() {
        return this.__text.get();
    }
    set text(newValue: string) {
        this.__text.set(newValue);
    }
    private controller: TextInputController;
    private __textError: ObservedPropertySimplePU<string>;
    get textError() {
        return this.__textError.get();
    }
    set textError(newValue: string) {
        this.__textError.set(newValue);
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/PersonInformation.ets(18:5)", "entry");
            Column.width('100%');
            Column.height('100%');
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create({ space: 100 });
            Row.debugLine("entry/src/main/ets/pages/PersonInformation.ets(20:7)", "entry");
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Image.create({ "id": 0, "type": 30000, params: ['icons/chevron_left_2.svg'], "bundleName": "com.example.myapplication", "moduleName": "entry" });
            Image.debugLine("entry/src/main/ets/pages/PersonInformation.ets(22:11)", "entry");
            Image.width(20);
            Image.onClick(() => { this.chevron_left_2_ButtonEvent(); });
        }, Image);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('个人资料');
            Text.debugLine("entry/src/main/ets/pages/PersonInformation.ets(23:11)", "entry");
            Text.fontSize(19);
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('完成');
            Text.debugLine("entry/src/main/ets/pages/PersonInformation.ets(24:11)", "entry");
            Text.fontColor(Color.Blue);
            Text.onClick(() => { this.chevron_left_2_ButtonEvent(); });
        }, Text);
        Text.pop();
        Row.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Divider.create();
            Divider.debugLine("entry/src/main/ets/pages/PersonInformation.ets(26:7)", "entry");
            Divider.strokeWidth(2);
            Divider.color('#F1F3F5');
        }, Divider);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/PersonInformation.ets(27:7)", "entry");
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Image.create({ "id": 0, "type": 30000, params: ['image/dog.jpg'], "bundleName": "com.example.myapplication", "moduleName": "entry" });
            Image.debugLine("entry/src/main/ets/pages/PersonInformation.ets(29:12)", "entry");
            Image.width(100);
            Image.borderRadius(50);
        }, Image);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('点击更换头像');
            Text.debugLine("entry/src/main/ets/pages/PersonInformation.ets(30:12)", "entry");
            Text.fontSize(10);
            Text.fontColor(Color.Gray);
        }, Text);
        Text.pop();
        Column.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/PersonInformation.ets(32:7)", "entry");
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('昵称');
            Text.debugLine("entry/src/main/ets/pages/PersonInformation.ets(34:9)", "entry");
            Text.width('98%');
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            TextInput.create({ placeholder: '胡桃' });
            TextInput.debugLine("entry/src/main/ets/pages/PersonInformation.ets(35:9)", "entry");
            TextInput.fontColor(Color.Gray);
            TextInput.showUnderline(true);
            TextInput.width(350);
            TextInput.height(60);
        }, TextInput);
        Column.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/PersonInformation.ets(40:7)", "entry");
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('手机');
            Text.debugLine("entry/src/main/ets/pages/PersonInformation.ets(42:9)", "entry");
            Text.width('98%');
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            TextInput.create({ placeholder: '+86 139700000' });
            TextInput.debugLine("entry/src/main/ets/pages/PersonInformation.ets(43:9)", "entry");
            TextInput.fontColor(Color.Gray);
            TextInput.showUnderline(true);
            TextInput.width(350);
            TextInput.height(60);
        }, TextInput);
        Column.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/PersonInformation.ets(48:7)", "entry");
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('邮箱');
            Text.debugLine("entry/src/main/ets/pages/PersonInformation.ets(50:9)", "entry");
            Text.width('98%');
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            TextInput.create({ placeholder: 'iss-edu@isoftstone.com' });
            TextInput.debugLine("entry/src/main/ets/pages/PersonInformation.ets(51:9)", "entry");
            TextInput.fontColor(Color.Gray);
            TextInput.showUnderline(true);
            TextInput.width(350);
            TextInput.height(60);
        }, TextInput);
        Column.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/PersonInformation.ets(56:7)", "entry");
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('密码');
            Text.debugLine("entry/src/main/ets/pages/PersonInformation.ets(58:9)", "entry");
            Text.width('98%');
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            TextInput.create({ placeholder: '' });
            TextInput.debugLine("entry/src/main/ets/pages/PersonInformation.ets(59:9)", "entry");
            TextInput.fontColor(Color.Gray);
            TextInput.showUnderline(true);
            TextInput.showError(this.textError);
            TextInput.type(InputType.Password);
            TextInput.width(350);
            TextInput.height(60);
            TextInput.showPasswordIcon(true);
            TextInput.backgroundColor(Color.White);
        }, TextInput);
        Column.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create({ space: 20 });
            Column.debugLine("entry/src/main/ets/pages/PersonInformation.ets(68:7)", "entry");
            Column.width("98%");
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 标题：已选择 X 个
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/PersonInformation.ets(70:9)", "entry");
            // 标题：已选择 X 个
            Row.width("98%");
            // 标题：已选择 X 个
            Row.justifyContent(FlexAlign.Start);
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create("兴趣标签");
            Text.debugLine("entry/src/main/ets/pages/PersonInformation.ets(71:11)", "entry");
            Text.fontSize(18);
            Text.fontWeight(FontWeight.Bold);
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(`已选择 ${this.selectedTags.size} 个`);
            Text.debugLine("entry/src/main/ets/pages/PersonInformation.ets(75:11)", "entry");
            Text.fontSize(14);
            Text.fontColor("#666");
            Text.margin({ left: 10 });
        }, Text);
        Text.pop();
        // 标题：已选择 X 个
        Row.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 标签列表（Flex 布局换行）
            Flex.create({ wrap: FlexWrap.Wrap });
            Flex.debugLine("entry/src/main/ets/pages/PersonInformation.ets(84:9)", "entry");
            // 标签列表（Flex 布局换行）
            Flex.width("100%");
        }, Flex);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            ForEach.create();
            const forEachItemGenFunction = (_item, index: number) => {
                const tag = _item;
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    // 每个标签按钮
                    Button.createWithLabel(tag);
                    Button.debugLine("entry/src/main/ets/pages/PersonInformation.ets(87:13)", "entry");
                    // 每个标签按钮
                    Button.padding(10);
                    // 每个标签按钮
                    Button.margin(5);
                    // 每个标签按钮
                    Button.borderRadius(20);
                    // 每个标签按钮
                    Button.backgroundColor(this.selectedTags.has(index) ? "#007DFF" : "#F0F0F0");
                    // 每个标签按钮
                    Button.fontColor(this.selectedTags.has(index) ? Color.White : Color.Black);
                    // 每个标签按钮
                    Button.onClick(() => {
                        // 切换选中状态
                        if (this.selectedTags.has(index)) {
                            this.selectedTags.delete(index);
                        }
                        else {
                            this.selectedTags.add(index);
                        }
                        // 触发 UI 更新
                        this.selectedTags = new Set(this.selectedTags);
                    });
                }, Button);
                // 每个标签按钮
                Button.pop();
            };
            this.forEachUpdateFunction(elmtId, this.tags, forEachItemGenFunction, undefined, true, false);
        }, ForEach);
        ForEach.pop();
        // 标签列表（Flex 布局换行）
        Flex.pop();
        Column.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/PersonInformation.ets(108:7)", "entry");
            Column.width('100%');
            Column.height('100%');
            Column.backgroundColor(Color.White);
            Column.borderRadius(25);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('个人简介');
            Text.debugLine("entry/src/main/ets/pages/PersonInformation.ets(109:9)", "entry");
            Text.width('98%');
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            TextInput.create({ text: this.text, controller: this.controller });
            TextInput.debugLine("entry/src/main/ets/pages/PersonInformation.ets(110:9)", "entry");
            TextInput.placeholderFont({ size: 16, weight: 400 });
            TextInput.width(336);
            TextInput.height(56);
            TextInput.maxLength(30);
            TextInput.showUnderline(false);
            TextInput.showCounter(true, { thresholdPercentage: 1, highlightBorder: true });
            TextInput.onChange((value: string) => {
                this.text = value;
            });
        }, TextInput);
        Column.pop();
        Column.pop();
    }
    chevron_left_2_ButtonEvent() {
        router.pushUrl({
            url: "pages/My"
        });
    }
    rerender() {
        this.updateDirtyElements();
    }
    static getEntryName(): string {
        return "PersonInformation";
    }
}
registerNamedRoute(() => new PersonInformation(undefined, {}), "", { bundleName: "com.example.myapplication", moduleName: "entry", pagePath: "pages/PersonInformation", pageFullPath: "entry/src/main/ets/pages/PersonInformation", integratedHsp: "false", moduleType: "followWithHap" });
