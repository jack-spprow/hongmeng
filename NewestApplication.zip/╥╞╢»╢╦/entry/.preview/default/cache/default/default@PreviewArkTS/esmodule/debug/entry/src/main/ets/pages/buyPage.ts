if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface buyPay_Params {
    isvisit?: boolean;
    isbuy?: boolean;
}
import router from "@ohos:router";
class buyPay extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.__isvisit = new ObservedPropertySimplePU(false, this, "isvisit");
        this.__isbuy = new ObservedPropertySimplePU(false, this, "isbuy");
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: buyPay_Params) {
        if (params.isvisit !== undefined) {
            this.isvisit = params.isvisit;
        }
        if (params.isbuy !== undefined) {
            this.isbuy = params.isbuy;
        }
    }
    updateStateVars(params: buyPay_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__isvisit.purgeDependencyOnElmtId(rmElmtId);
        this.__isbuy.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__isvisit.aboutToBeDeleted();
        this.__isbuy.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    private __isvisit: ObservedPropertySimplePU<boolean>;
    get isvisit() {
        return this.__isvisit.get();
    }
    set isvisit(newValue: boolean) {
        this.__isvisit.set(newValue);
    }
    private __isbuy: ObservedPropertySimplePU<boolean>;
    get isbuy() {
        return this.__isbuy.get();
    }
    set isbuy(newValue: boolean) {
        this.__isbuy.set(newValue);
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Stack.create({ alignContent: Alignment.Bottom });
            Stack.debugLine("entry/src/main/ets/pages/buyPage.ets(9:5)", "entry");
            Stack.width('100%');
            Stack.height('100%');
        }, Stack);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            If.create();
            // 是否试课
            if (this.isvisit) {
                this.ifElseBranchUpdateFunction(0, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Column.create();
                        Column.debugLine("entry/src/main/ets/pages/buyPage.ets(12:9)", "entry");
                        Column.zIndex(1);
                        Column.width('100%');
                        Column.height('100%');
                        Column.justifyContent(FlexAlign.Center);
                        Column.backgroundColor('rgba(0,0,0,0.5)');
                    }, Column);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Column.create();
                        Column.debugLine("entry/src/main/ets/pages/buyPage.ets(13:11)", "entry");
                        Column.padding(24);
                        Column.backgroundColor('#FFFFFF');
                        Column.borderRadius(12);
                        Column.width('80%');
                    }, Column);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create('试课确认');
                        Text.debugLine("entry/src/main/ets/pages/buyPage.ets(14:13)", "entry");
                        Text.fontSize(18);
                        Text.margin({ bottom: 16 });
                    }, Text);
                    Text.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create('您将试听第一课：林教头风雪山神庙');
                        Text.debugLine("entry/src/main/ets/pages/buyPage.ets(18:13)", "entry");
                        Text.fontSize(16);
                        Text.margin({ bottom: 24 });
                    }, Text);
                    Text.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Row.create();
                        Row.debugLine("entry/src/main/ets/pages/buyPage.ets(22:13)", "entry");
                        Row.width('100%');
                        Row.justifyContent(FlexAlign.SpaceBetween);
                    }, Row);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Button.createWithLabel('取消');
                        Button.debugLine("entry/src/main/ets/pages/buyPage.ets(23:15)", "entry");
                        Button.width('40%');
                        Button.height(40);
                        Button.backgroundColor('#F5F5F5');
                        Button.fontColor('#333333');
                        Button.onClick(() => {
                            this.isvisit = false;
                        });
                    }, Button);
                    Button.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Button.createWithLabel('开始试课');
                        Button.debugLine("entry/src/main/ets/pages/buyPage.ets(32:15)", "entry");
                        Button.width('40%');
                        Button.height(40);
                        Button.backgroundColor('#FF0000');
                        Button.fontColor('#FFFFFF');
                        Button.onClick(() => {
                            this.isvisit = false;
                            // 这里添加开始试课的逻辑
                        });
                    }, Button);
                    Button.pop();
                    Row.pop();
                    Column.pop();
                    Column.pop();
                });
            }
            // 是否购买
            else {
                this.ifElseBranchUpdateFunction(1, () => {
                });
            }
        }, If);
        If.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            If.create();
            // 是否购买
            if (this.isbuy) {
                this.ifElseBranchUpdateFunction(0, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Column.create();
                        Column.debugLine("entry/src/main/ets/pages/buyPage.ets(60:9)", "entry");
                        Column.zIndex(1);
                        Column.width('100%');
                        Column.height('100%');
                        Column.justifyContent(FlexAlign.Center);
                        Column.backgroundColor('rgba(0,0,0,0.5)');
                    }, Column);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Column.create();
                        Column.debugLine("entry/src/main/ets/pages/buyPage.ets(61:11)", "entry");
                        Column.padding(24);
                        Column.backgroundColor('#FFFFFF');
                        Column.borderRadius(12);
                        Column.width('80%');
                    }, Column);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create('确认购买');
                        Text.debugLine("entry/src/main/ets/pages/buyPage.ets(62:13)", "entry");
                        Text.fontSize(18);
                        Text.margin({ bottom: 16 });
                    }, Text);
                    Text.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Row.create();
                        Row.debugLine("entry/src/main/ets/pages/buyPage.ets(66:13)", "entry");
                        Row.width('100%');
                        Row.justifyContent(FlexAlign.Start);
                        Row.margin({ bottom: 8 });
                    }, Row);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create('课程：');
                        Text.debugLine("entry/src/main/ets/pages/buyPage.ets(67:15)", "entry");
                        Text.fontSize(16);
                    }, Text);
                    Text.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create('胡说系列·高中语文必修五');
                        Text.debugLine("entry/src/main/ets/pages/buyPage.ets(69:15)", "entry");
                        Text.fontSize(16);
                    }, Text);
                    Text.pop();
                    Row.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Row.create();
                        Row.debugLine("entry/src/main/ets/pages/buyPage.ets(76:13)", "entry");
                        Row.width('100%');
                        Row.justifyContent(FlexAlign.Start);
                        Row.margin({ bottom: 24 });
                    }, Row);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create('价格:   ');
                        Text.debugLine("entry/src/main/ets/pages/buyPage.ets(77:15)", "entry");
                        Text.fontSize(16);
                    }, Text);
                    Text.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create('¥9.90');
                        Text.debugLine("entry/src/main/ets/pages/buyPage.ets(79:15)", "entry");
                        Text.fontSize(18);
                        Text.fontColor('#FF0000');
                    }, Text);
                    Text.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create('¥40.00');
                        Text.debugLine("entry/src/main/ets/pages/buyPage.ets(82:15)", "entry");
                        Text.fontSize(14);
                        Text.fontColor('#999999');
                        Text.margin({ left: 10 });
                        Text.decoration({ type: TextDecorationType.LineThrough });
                    }, Text);
                    Text.pop();
                    Row.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Row.create();
                        Row.debugLine("entry/src/main/ets/pages/buyPage.ets(92:13)", "entry");
                        Row.width('100%');
                        Row.justifyContent(FlexAlign.SpaceBetween);
                    }, Row);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Button.createWithLabel('取消');
                        Button.debugLine("entry/src/main/ets/pages/buyPage.ets(93:15)", "entry");
                        Button.width('40%');
                        Button.height(40);
                        Button.backgroundColor('#F5F5F5');
                        Button.fontColor('#333333');
                        Button.onClick(() => {
                            this.isbuy = false;
                        });
                    }, Button);
                    Button.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Button.createWithLabel('确认购买');
                        Button.debugLine("entry/src/main/ets/pages/buyPage.ets(102:15)", "entry");
                        Button.width('40%');
                        Button.height(40);
                        Button.backgroundColor('#FF0000');
                        Button.fontColor('#FFFFFF');
                        Button.onClick(() => {
                            this.isbuy = false;
                            // 这里添加开始购买的逻辑
                        });
                    }, Button);
                    Button.pop();
                    Row.pop();
                    Column.pop();
                    Column.pop();
                });
            }
            // Tab内容
            else {
                this.ifElseBranchUpdateFunction(1, () => {
                });
            }
        }, If);
        If.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // Tab内容
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/buyPage.ets(128:7)", "entry");
            // Tab内容
            Column.width('100%');
            // Tab内容
            Column.margin({ bottom: 120 });
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/buyPage.ets(129:9)", "entry");
            Row.width('100%');
            Row.height(56);
            Row.backgroundColor('#FFFFFF');
            Row.justifyContent(FlexAlign.SpaceBetween);
            Row.alignItems(VerticalAlign.Center);
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Image.create({ "id": 0, "type": 30000, params: ['image/back.png'], "bundleName": "com.example.myapplication", "moduleName": "entry" });
            Image.debugLine("entry/src/main/ets/pages/buyPage.ets(130:11)", "entry");
            Image.width(24);
            Image.height(24);
            Image.margin({ left: 16 });
            Image.onClick(() => {
                this.BackEvent();
            });
        }, Image);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('课程详情');
            Text.debugLine("entry/src/main/ets/pages/buyPage.ets(138:11)", "entry");
            Text.fontSize(18);
            Text.fontWeight(FontWeight.Medium);
            Text.margin({ left: 16 });
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Blank.create();
            Blank.debugLine("entry/src/main/ets/pages/buyPage.ets(143:11)", "entry");
        }, Blank);
        Blank.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Image.create({ "id": 0, "type": 30000, params: ['image/share.png'], "bundleName": "com.example.myapplication", "moduleName": "entry" });
            Image.debugLine("entry/src/main/ets/pages/buyPage.ets(145:11)", "entry");
            Image.width(24);
            Image.height(24);
            Image.margin({ right: 16 });
        }, Image);
        Row.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Tabs.create();
            Tabs.debugLine("entry/src/main/ets/pages/buyPage.ets(156:9)", "entry");
            Tabs.height('100%');
        }, Tabs);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            TabContent.create(() => {
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Scroll.create();
                    Scroll.debugLine("entry/src/main/ets/pages/buyPage.ets(158:13)", "entry");
                    Scroll.height('100%');
                }, Scroll);
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Column.create();
                    Column.debugLine("entry/src/main/ets/pages/buyPage.ets(159:15)", "entry");
                    Column.alignItems(HorizontalAlign.Start);
                    Column.justifyContent(FlexAlign.Start);
                    Column.width('100%');
                    Column.padding(16);
                }, Column);
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Image.create({ "id": 0, "type": 30000, params: ['image/course.jpg'], "bundleName": "com.example.myapplication", "moduleName": "entry" });
                    Image.debugLine("entry/src/main/ets/pages/buyPage.ets(160:17)", "entry");
                    Image.width('100%');
                    Image.height(220);
                    Image.objectFit(ImageFit.Cover);
                }, Image);
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    // 标题
                    Text.create('胡说系列·高中语文必修五');
                    Text.debugLine("entry/src/main/ets/pages/buyPage.ets(165:17)", "entry");
                    // 标题
                    Text.fontSize(20);
                    // 标题
                    Text.width('100%');
                    // 标题
                    Text.textAlign(TextAlign.Start);
                }, Text);
                // 标题
                Text.pop();
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Text.create('打开语文书的正确姿势');
                    Text.debugLine("entry/src/main/ets/pages/buyPage.ets(170:17)", "entry");
                    Text.fontSize(14);
                    Text.fontColor('#666666');
                    Text.width('100%');
                    Text.textAlign(TextAlign.Start);
                }, Text);
                Text.pop();
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    // 价格
                    Row.create();
                    Row.debugLine("entry/src/main/ets/pages/buyPage.ets(177:17)", "entry");
                    // 价格
                    Row.width('100%');
                    // 价格
                    Row.margin({ top: 10 });
                }, Row);
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Text.create('￥9.90');
                    Text.debugLine("entry/src/main/ets/pages/buyPage.ets(178:19)", "entry");
                    Text.fontSize(20);
                    Text.fontColor('#FF0000');
                }, Text);
                Text.pop();
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Text.create('¥40.00');
                    Text.debugLine("entry/src/main/ets/pages/buyPage.ets(182:19)", "entry");
                    Text.fontSize(14);
                    Text.fontColor('#999999');
                    Text.margin({ left: 10 });
                    Text.decoration({ type: TextDecorationType.LineThrough });
                }, Text);
                Text.pop();
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Blank.create();
                    Blank.debugLine("entry/src/main/ets/pages/buyPage.ets(188:19)", "entry");
                }, Blank);
                Blank.pop();
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Text.create('① 9 人已学习');
                    Text.debugLine("entry/src/main/ets/pages/buyPage.ets(190:19)", "entry");
                    Text.fontSize(12);
                    Text.fontColor('#999999');
                }, Text);
                Text.pop();
                // 价格
                Row.pop();
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    // 课程信息
                    Row.create();
                    Row.debugLine("entry/src/main/ets/pages/buyPage.ets(198:17)", "entry");
                    // 课程信息
                    Row.margin({ top: 10 });
                    // 课程信息
                    Row.width('95%');
                }, Row);
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Text.create('章  节 ');
                    Text.debugLine("entry/src/main/ets/pages/buyPage.ets(199:19)", "entry");
                    Text.fontSize(12);
                    Text.fontColor('#666666');
                }, Text);
                Text.pop();
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Text.create('共 8 节');
                    Text.debugLine("entry/src/main/ets/pages/buyPage.ets(202:19)", "entry");
                    Text.fontSize(12);
                    Text.fontColor('#333333');
                }, Text);
                Text.pop();
                // 课程信息
                Row.pop();
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Row.create();
                    Row.debugLine("entry/src/main/ets/pages/buyPage.ets(209:17)", "entry");
                    Row.margin({ top: 8 });
                    Row.width('95%');
                }, Row);
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Text.create('来  源 ');
                    Text.debugLine("entry/src/main/ets/pages/buyPage.ets(210:19)", "entry");
                    Text.fontSize(12);
                    Text.fontColor('#666666');
                }, Text);
                Text.pop();
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Text.create('逗 你 学');
                    Text.debugLine("entry/src/main/ets/pages/buyPage.ets(213:19)", "entry");
                    Text.fontSize(12);
                    Text.fontColor('#333333');
                }, Text);
                Text.pop();
                Row.pop();
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    // 标签区域
                    Row.create();
                    Row.debugLine("entry/src/main/ets/pages/buyPage.ets(221:17)", "entry");
                    // 标签区域
                    Row.margin({ top: 10 });
                    // 标签区域
                    Row.width('100%');
                }, Row);
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Text.create('文艺修养');
                    Text.debugLine("entry/src/main/ets/pages/buyPage.ets(222:19)", "entry");
                    Text.fontSize(12);
                    Text.padding({
                        left: 10,
                        right: 10,
                        top: 4,
                        bottom: 4
                    });
                    Text.borderRadius(12);
                    Text.backgroundColor('#F0F0F0');
                    Text.margin({ right: 8, bottom: 8 });
                }, Text);
                Text.pop();
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Text.create('名著');
                    Text.debugLine("entry/src/main/ets/pages/buyPage.ets(234:19)", "entry");
                    Text.fontSize(12);
                    Text.padding({
                        left: 10,
                        right: 10,
                        top: 4,
                        bottom: 4
                    });
                    Text.borderRadius(12);
                    Text.backgroundColor('#F0F0F0');
                    Text.margin({ right: 8, bottom: 8 });
                }, Text);
                Text.pop();
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Text.create('文学鉴赏');
                    Text.debugLine("entry/src/main/ets/pages/buyPage.ets(246:19)", "entry");
                    Text.fontSize(12);
                    Text.padding({
                        left: 10,
                        right: 10,
                        top: 4,
                        bottom: 4
                    });
                    Text.borderRadius(12);
                    Text.backgroundColor('#F0F0F0');
                    Text.margin({ right: 8, bottom: 8 });
                }, Text);
                Text.pop();
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Text.create('传统文化');
                    Text.debugLine("entry/src/main/ets/pages/buyPage.ets(258:19)", "entry");
                    Text.fontSize(12);
                    Text.padding({
                        left: 10,
                        right: 10,
                        top: 4,
                        bottom: 4
                    });
                    Text.borderRadius(12);
                    Text.backgroundColor('#F0F0F0');
                    Text.margin({ bottom: 8 });
                }, Text);
                Text.pop();
                // 标签区域
                Row.pop();
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    // 分割线
                    Divider.create();
                    Divider.debugLine("entry/src/main/ets/pages/buyPage.ets(274:17)", "entry");
                    // 分割线
                    Divider.strokeWidth(1);
                    // 分割线
                    Divider.color('#EEEEEE');
                    // 分割线
                    Divider.margin({ top: 15, bottom: 15 });
                }, Divider);
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Text.create('课程介绍');
                    Text.debugLine("entry/src/main/ets/pages/buyPage.ets(279:17)", "entry");
                    Text.fontSize(16);
                    Text.width('100%');
                    Text.textAlign(TextAlign.Start);
                }, Text);
                Text.pop();
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    // 课程介绍内容
                    Text.create('本课程精选高中语文必修教材中最具代表性的经典课文，通过深入浅出的精讲剖析，将知识性与趣味性完美融合。我们不仅详细解析每篇课文的文学技巧、思想内涵和时代背景，更以幽默风趣的教学风格激发学习兴趣，让学生充分感受语文的魅力。课程特别注重学习效率的提升，帮助学生精准把握重点难点，掌握科学的学习方法，真正实现"把时间花在刀刃上"——用最少的时间投入获取最大的学习效益。通过系统学习，学生将在文学鉴赏能力...');
                    Text.debugLine("entry/src/main/ets/pages/buyPage.ets(285:17)", "entry");
                    // 课程介绍内容
                    Text.fontSize(14);
                    // 课程介绍内容
                    Text.lineHeight(20);
                    // 课程介绍内容
                    Text.textAlign(TextAlign.Start);
                    // 课程介绍内容
                    Text.margin({ top: 8 });
                }, Text);
                // 课程介绍内容
                Text.pop();
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Divider.create();
                    Divider.debugLine("entry/src/main/ets/pages/buyPage.ets(291:17)", "entry");
                    Divider.strokeWidth(1);
                    Divider.color('#EEEEEE');
                    Divider.margin({ top: 15, bottom: 15 });
                }, Divider);
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    // 出版社信息
                    Text.create('人教版');
                    Text.debugLine("entry/src/main/ets/pages/buyPage.ets(297:17)", "entry");
                    // 出版社信息
                    Text.fontSize(16);
                    // 出版社信息
                    Text.width('100%');
                    // 出版社信息
                    Text.textAlign(TextAlign.Start);
                }, Text);
                // 出版社信息
                Text.pop();
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    // 课程特色
                    Text.create('语文课文');
                    Text.debugLine("entry/src/main/ets/pages/buyPage.ets(303:17)", "entry");
                    // 课程特色
                    Text.fontSize(14);
                    // 课程特色
                    Text.width('100%');
                    // 课程特色
                    Text.textAlign(TextAlign.Start);
                    // 课程特色
                    Text.margin({ top: 8 });
                }, Text);
                // 课程特色
                Text.pop();
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Text.create('另类"胡说"');
                    Text.debugLine("entry/src/main/ets/pages/buyPage.ets(309:17)", "entry");
                    Text.fontSize(14);
                    Text.fontColor('#666666');
                    Text.width('100%');
                    Text.textAlign(TextAlign.Start);
                    Text.margin({ top: 4 });
                }, Text);
                Text.pop();
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Text.create('必修1-5同步精讲');
                    Text.debugLine("entry/src/main/ets/pages/buyPage.ets(316:17)", "entry");
                    Text.fontSize(14);
                    Text.fontWeight(FontWeight.Bold);
                    Text.width('100%');
                    Text.textAlign(TextAlign.Start);
                    Text.margin({ top: 8 });
                }, Text);
                Text.pop();
                Column.pop();
                Scroll.pop();
            });
            TabContent.tabBar('介绍');
            TabContent.debugLine("entry/src/main/ets/pages/buyPage.ets(157:11)", "entry");
        }, TabContent);
        TabContent.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            TabContent.create(() => {
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Scroll.create();
                    Scroll.debugLine("entry/src/main/ets/pages/buyPage.ets(331:13)", "entry");
                    Scroll.width('100%');
                    Scroll.height('100%');
                }, Scroll);
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Column.create();
                    Column.debugLine("entry/src/main/ets/pages/buyPage.ets(332:15)", "entry");
                    Column.width('100%');
                    Column.padding(16);
                }, Column);
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Row.create();
                    Row.debugLine("entry/src/main/ets/pages/buyPage.ets(333:17)", "entry");
                    Row.width('100%');
                    Row.alignItems(VerticalAlign.Top);
                    Row.justifyContent(FlexAlign.SpaceBetween);
                }, Row);
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Text.create('共 八 节');
                    Text.debugLine("entry/src/main/ets/pages/buyPage.ets(334:19)", "entry");
                    Text.fontSize(12);
                    Text.fontColor('#666666');
                }, Text);
                Text.pop();
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Text.create('已学完 0 节');
                    Text.debugLine("entry/src/main/ets/pages/buyPage.ets(338:19)", "entry");
                    Text.fontSize(12);
                    Text.fontColor('#666666');
                }, Text);
                Text.pop();
                Row.pop();
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Column.create();
                    Column.debugLine("entry/src/main/ets/pages/buyPage.ets(346:17)", "entry");
                    Column.width('100%');
                    Column.margin({ top: 15 });
                    Column.alignItems(HorizontalAlign.Start);
                }, Column);
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Text.create('1.林教头风雪山神庙');
                    Text.debugLine("entry/src/main/ets/pages/buyPage.ets(347:19)", "entry");
                }, Text);
                Text.pop();
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Row.create();
                    Row.debugLine("entry/src/main/ets/pages/buyPage.ets(348:19)", "entry");
                }, Row);
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Image.create({ "id": 0, "type": 30000, params: ['image/listen.png'], "bundleName": "com.example.myapplication", "moduleName": "entry" });
                    Image.debugLine("entry/src/main/ets/pages/buyPage.ets(349:21)", "entry");
                    Image.width(18);
                }, Image);
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Text.create('   4分18秒');
                    Text.debugLine("entry/src/main/ets/pages/buyPage.ets(351:21)", "entry");
                    Text.fontColor('#666666');
                }, Text);
                Text.pop();
                Row.pop();
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Divider.create();
                    Divider.debugLine("entry/src/main/ets/pages/buyPage.ets(355:19)", "entry");
                    Divider.strokeWidth(1);
                    Divider.color('#EEEEEE');
                    Divider.margin({ top: 15, bottom: 15 });
                }, Divider);
                Column.pop();
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Column.create();
                    Column.debugLine("entry/src/main/ets/pages/buyPage.ets(364:17)", "entry");
                    Column.width('100%');
                    Column.alignItems(HorizontalAlign.Start);
                }, Column);
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Text.create('2.装在套子里的人');
                    Text.debugLine("entry/src/main/ets/pages/buyPage.ets(365:19)", "entry");
                }, Text);
                Text.pop();
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Row.create();
                    Row.debugLine("entry/src/main/ets/pages/buyPage.ets(366:19)", "entry");
                }, Row);
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Image.create({ "id": 0, "type": 30000, params: ['image/listen.png'], "bundleName": "com.example.myapplication", "moduleName": "entry" });
                    Image.debugLine("entry/src/main/ets/pages/buyPage.ets(367:21)", "entry");
                    Image.width(18);
                }, Image);
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Text.create('   3分49秒');
                    Text.debugLine("entry/src/main/ets/pages/buyPage.ets(369:21)", "entry");
                    Text.fontColor('#666666');
                }, Text);
                Text.pop();
                Row.pop();
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Divider.create();
                    Divider.debugLine("entry/src/main/ets/pages/buyPage.ets(373:19)", "entry");
                    Divider.strokeWidth(1);
                    Divider.color('#EEEEEE');
                    Divider.margin({ top: 15, bottom: 15 });
                }, Divider);
                Column.pop();
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Column.create();
                    Column.debugLine("entry/src/main/ets/pages/buyPage.ets(381:17)", "entry");
                    Column.width('100%');
                    Column.alignItems(HorizontalAlign.Start);
                }, Column);
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Text.create('3.归去来兮');
                    Text.debugLine("entry/src/main/ets/pages/buyPage.ets(382:19)", "entry");
                }, Text);
                Text.pop();
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Row.create();
                    Row.debugLine("entry/src/main/ets/pages/buyPage.ets(383:19)", "entry");
                }, Row);
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Image.create({ "id": 0, "type": 30000, params: ['image/listen.png'], "bundleName": "com.example.myapplication", "moduleName": "entry" });
                    Image.debugLine("entry/src/main/ets/pages/buyPage.ets(384:21)", "entry");
                    Image.width(18);
                }, Image);
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Text.create('   4分15秒');
                    Text.debugLine("entry/src/main/ets/pages/buyPage.ets(386:21)", "entry");
                    Text.fontColor('#666666');
                }, Text);
                Text.pop();
                Row.pop();
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Divider.create();
                    Divider.debugLine("entry/src/main/ets/pages/buyPage.ets(390:19)", "entry");
                    Divider.strokeWidth(1);
                    Divider.color('#EEEEEE');
                    Divider.margin({ top: 15, bottom: 15 });
                }, Divider);
                Column.pop();
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Column.create();
                    Column.debugLine("entry/src/main/ets/pages/buyPage.ets(398:17)", "entry");
                    Column.width('100%');
                    Column.alignItems(HorizontalAlign.Start);
                }, Column);
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Text.create('4.滕王阁序');
                    Text.debugLine("entry/src/main/ets/pages/buyPage.ets(399:19)", "entry");
                }, Text);
                Text.pop();
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Row.create();
                    Row.debugLine("entry/src/main/ets/pages/buyPage.ets(400:19)", "entry");
                }, Row);
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Image.create({ "id": 0, "type": 30000, params: ['image/listen.png'], "bundleName": "com.example.myapplication", "moduleName": "entry" });
                    Image.debugLine("entry/src/main/ets/pages/buyPage.ets(401:21)", "entry");
                    Image.width(18);
                }, Image);
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Text.create('   5分13秒');
                    Text.debugLine("entry/src/main/ets/pages/buyPage.ets(403:21)", "entry");
                    Text.fontColor('#666666');
                }, Text);
                Text.pop();
                Row.pop();
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Divider.create();
                    Divider.debugLine("entry/src/main/ets/pages/buyPage.ets(407:19)", "entry");
                    Divider.strokeWidth(1);
                    Divider.color('#EEEEEE');
                    Divider.margin({ top: 15, bottom: 15 });
                }, Divider);
                Column.pop();
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Column.create();
                    Column.debugLine("entry/src/main/ets/pages/buyPage.ets(415:17)", "entry");
                    Column.width('100%');
                    Column.alignItems(HorizontalAlign.Start);
                }, Column);
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Text.create('5.咬文嚼字');
                    Text.debugLine("entry/src/main/ets/pages/buyPage.ets(416:19)", "entry");
                }, Text);
                Text.pop();
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Row.create();
                    Row.debugLine("entry/src/main/ets/pages/buyPage.ets(417:19)", "entry");
                }, Row);
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Image.create({ "id": 0, "type": 30000, params: ['image/listen.png'], "bundleName": "com.example.myapplication", "moduleName": "entry" });
                    Image.debugLine("entry/src/main/ets/pages/buyPage.ets(418:21)", "entry");
                    Image.width(18);
                }, Image);
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Text.create('   3分59秒');
                    Text.debugLine("entry/src/main/ets/pages/buyPage.ets(420:21)", "entry");
                    Text.fontColor('#666666');
                }, Text);
                Text.pop();
                Row.pop();
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Divider.create();
                    Divider.debugLine("entry/src/main/ets/pages/buyPage.ets(424:19)", "entry");
                    Divider.strokeWidth(1);
                    Divider.color('#EEEEEE');
                    Divider.margin({ top: 15, bottom: 15 });
                }, Divider);
                Column.pop();
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Column.create();
                    Column.debugLine("entry/src/main/ets/pages/buyPage.ets(432:17)", "entry");
                    Column.width('100%');
                    Column.alignItems(HorizontalAlign.Start);
                }, Column);
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Text.create('6.说木叶');
                    Text.debugLine("entry/src/main/ets/pages/buyPage.ets(433:19)", "entry");
                }, Text);
                Text.pop();
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Row.create();
                    Row.debugLine("entry/src/main/ets/pages/buyPage.ets(434:19)", "entry");
                }, Row);
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Image.create({ "id": 0, "type": 30000, params: ['image/listen.png'], "bundleName": "com.example.myapplication", "moduleName": "entry" });
                    Image.debugLine("entry/src/main/ets/pages/buyPage.ets(435:21)", "entry");
                    Image.width(18);
                }, Image);
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Text.create('   3分48秒');
                    Text.debugLine("entry/src/main/ets/pages/buyPage.ets(437:21)", "entry");
                    Text.fontColor('#666666');
                }, Text);
                Text.pop();
                Row.pop();
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Divider.create();
                    Divider.debugLine("entry/src/main/ets/pages/buyPage.ets(441:19)", "entry");
                    Divider.strokeWidth(1);
                    Divider.color('#EEEEEE');
                    Divider.margin({ top: 15, bottom: 15 });
                }, Divider);
                Column.pop();
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Column.create();
                    Column.debugLine("entry/src/main/ets/pages/buyPage.ets(449:17)", "entry");
                    Column.width('100%');
                    Column.alignItems(HorizontalAlign.Start);
                }, Column);
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Text.create('7.中国建筑的特征');
                    Text.debugLine("entry/src/main/ets/pages/buyPage.ets(450:19)", "entry");
                }, Text);
                Text.pop();
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Row.create();
                    Row.debugLine("entry/src/main/ets/pages/buyPage.ets(451:19)", "entry");
                }, Row);
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Image.create({ "id": 0, "type": 30000, params: ['image/listen.png'], "bundleName": "com.example.myapplication", "moduleName": "entry" });
                    Image.debugLine("entry/src/main/ets/pages/buyPage.ets(452:21)", "entry");
                    Image.width(18);
                }, Image);
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Text.create('   3分55秒');
                    Text.debugLine("entry/src/main/ets/pages/buyPage.ets(454:21)", "entry");
                    Text.fontColor('#666666');
                }, Text);
                Text.pop();
                Row.pop();
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Divider.create();
                    Divider.debugLine("entry/src/main/ets/pages/buyPage.ets(458:19)", "entry");
                    Divider.strokeWidth(1);
                    Divider.color('#EEEEEE');
                    Divider.margin({ top: 15, bottom: 15 });
                }, Divider);
                Column.pop();
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Column.create();
                    Column.debugLine("entry/src/main/ets/pages/buyPage.ets(466:17)", "entry");
                    Column.width('100%');
                    Column.alignItems(HorizontalAlign.Start);
                }, Column);
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Text.create('8.作为生物的社会');
                    Text.debugLine("entry/src/main/ets/pages/buyPage.ets(467:19)", "entry");
                }, Text);
                Text.pop();
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Row.create();
                    Row.debugLine("entry/src/main/ets/pages/buyPage.ets(468:19)", "entry");
                }, Row);
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Image.create({ "id": 0, "type": 30000, params: ['image/listen.png'], "bundleName": "com.example.myapplication", "moduleName": "entry" });
                    Image.debugLine("entry/src/main/ets/pages/buyPage.ets(469:21)", "entry");
                    Image.width(18);
                }, Image);
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Text.create('   3分13秒');
                    Text.debugLine("entry/src/main/ets/pages/buyPage.ets(471:21)", "entry");
                    Text.fontColor('#666666');
                }, Text);
                Text.pop();
                Row.pop();
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Divider.create();
                    Divider.debugLine("entry/src/main/ets/pages/buyPage.ets(475:19)", "entry");
                    Divider.strokeWidth(1);
                    Divider.color('#EEEEEE');
                    Divider.margin({ top: 15, bottom: 15 });
                }, Divider);
                Column.pop();
                Column.pop();
                Scroll.pop();
            });
            TabContent.tabBar('目录');
            TabContent.debugLine("entry/src/main/ets/pages/buyPage.ets(330:11)", "entry");
        }, TabContent);
        TabContent.pop();
        Tabs.pop();
        // Tab内容
        Column.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 按钮
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/buyPage.ets(498:7)", "entry");
            // 按钮
            Row.width('100%');
            // 按钮
            Row.height(60);
            // 按钮
            Row.alignItems(VerticalAlign.Bottom);
            // 按钮
            Row.justifyContent(FlexAlign.Center);
            // 按钮
            Row.backgroundColor('#FFFFFF');
            // 按钮
            Row.border({ width: 0.5, color: '#EEEEEE' });
            // 按钮
            Row.padding({ left: 16, right: 16 });
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 试课按钮
            Button.createWithLabel('试课', { type: ButtonType.Capsule, stateEffect: true });
            Button.debugLine("entry/src/main/ets/pages/buyPage.ets(500:9)", "entry");
            // 试课按钮
            Button.width('40%');
            // 试课按钮
            Button.height(40);
            // 试课按钮
            Button.fontSize(16);
            // 试课按钮
            Button.backgroundColor('#FFFFFF');
            // 试课按钮
            Button.fontColor('#FF0000');
            // 试课按钮
            Button.border({ width: 1, color: '#FF0000' });
            // 试课按钮
            Button.margin({ right: 10 });
            // 试课按钮
            Button.onClick(() => {
                this.isvisit = true;
            });
        }, Button);
        // 试课按钮
        Button.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 购买按钮
            Button.createWithLabel('立即购买', { type: ButtonType.Capsule, stateEffect: true });
            Button.debugLine("entry/src/main/ets/pages/buyPage.ets(513:9)", "entry");
            // 购买按钮
            Button.width('50%');
            // 购买按钮
            Button.height(40);
            // 购买按钮
            Button.fontSize(16);
            // 购买按钮
            Button.backgroundColor('#FF0000');
            // 购买按钮
            Button.fontColor('#FFFFFF');
            // 购买按钮
            Button.onClick(() => {
                this.isbuy = true;
            });
        }, Button);
        // 购买按钮
        Button.pop();
        // 按钮
        Row.pop();
        Stack.pop();
    }
    BackEvent() {
        router.pushUrl({
            url: 'pages/MainPage'
        });
    }
    rerender() {
        this.updateDirtyElements();
    }
    static getEntryName(): string {
        return "buyPay";
    }
}
registerNamedRoute(() => new buyPay(undefined, {}), "", { bundleName: "com.example.myapplication", moduleName: "entry", pagePath: "pages/buyPage", pageFullPath: "entry/src/main/ets/pages/buyPage", integratedHsp: "false", moduleType: "followWithHap" });
