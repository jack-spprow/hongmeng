if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface Equipment_Params {
    content?: string;
    currentTabIndex?: number;
    iconPressed1?: boolean;
    iconPressed2?: boolean;
    activeLanguage?: string;
    activeSort?: string;
    tabItems?: TabItem[];
    courses?: CourseItem[];
    languages?: string[];
    sortOptions?: string[];
    type?: string[];
}
interface TabItem {
    name: string;
    icon: Resource;
}
interface CourseItem {
    id: number;
    picture: Resource;
    title: string;
    price: number;
    students: number;
    isCertified?: boolean;
}
export default class Equipment extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.__content = new ObservedPropertySimplePU('提问什么都可以！', this, "content");
        this.__currentTabIndex = new ObservedPropertySimplePU(0, this, "currentTabIndex");
        this.__iconPressed1 = new ObservedPropertySimplePU(false, this, "iconPressed1");
        this.__iconPressed2 = new ObservedPropertySimplePU(false, this, "iconPressed2");
        this.__activeLanguage = new ObservedPropertySimplePU('ArkTS', this, "activeLanguage");
        this.__activeSort = new ObservedPropertySimplePU('综合排序', this, "activeSort");
        this.tabItems = [
            { name: '首页', icon: { "id": 0, "type": 30000, params: ['icons/house.svg'], "bundleName": "com.example.myapplication", "moduleName": "entry" } },
            { name: '找课', icon: { "id": 0, "type": 30000, params: ['icons/magnifyingglass.svg'], "bundleName": "com.example.myapplication", "moduleName": "entry" } },
            { name: '学习', icon: { "id": 0, "type": 30000, params: ['icons/book.svg'], "bundleName": "com.example.myapplication", "moduleName": "entry" } },
            { name: '我的', icon: { "id": 0, "type": 30000, params: ['icons/human.svg'], "bundleName": "com.example.myapplication", "moduleName": "entry" } }
        ];
        this.courses = [
            { id: 1, picture: { "id": 16777236, "type": 20000, params: [], "bundleName": "com.example.myapplication", "moduleName": "entry" }, title: 'TypeScript快速入门', price: 66.6, students: 27, isCertified: true },
            { id: 2, picture: { "id": 16777235, "type": 20000, params: [], "bundleName": "com.example.myapplication", "moduleName": "entry" }, title: 'ArkTS基础知识', price: 48.5, students: 100 },
            { id: 3, picture: { "id": 16777230, "type": 20000, params: [], "bundleName": "com.example.myapplication", "moduleName": "entry" }, title: 'ArkTS开发实践', price: 99.0, students: 30 },
            { id: 4, picture: { "id": 16777228, "type": 20000, params: [], "bundleName": "com.example.myapplication", "moduleName": "entry" }, title: '应用程序入口', price: 9.9, students: 19 },
            { id: 5, picture: { "id": 16777231, "type": 20000, params: [], "bundleName": "com.example.myapplication", "moduleName": "entry" }, title: '基础组件的使用', price: 0.99, students: 56 },
            { id: 6, picture: { "id": 16777229, "type": 20000, params: [], "bundleName": "com.example.myapplication", "moduleName": "entry" }, title: '容器组件介绍', price: 52.0, students: 37 },
            { id: 7, picture: { "id": 16777233, "type": 20000, params: [], "bundleName": "com.example.myapplication", "moduleName": "entry" }, title: '构建列表页面', price: 9.9, students: 57 },
            { id: 8, picture: { "id": 16777234, "type": 20000, params: [], "bundleName": "com.example.myapplication", "moduleName": "entry" }, title: '页签切换', price: 12.04, students: 87 },
            { id: 9, picture: { "id": 16777232, "type": 20000, params: [], "bundleName": "com.example.myapplication", "moduleName": "entry" }, title: '管理组件状态', price: 12.34, students: 18 }
        ];
        this.languages = ['ArkTS', 'ArkUI', 'JavaScript', 'TypeScript'];
        this.sortOptions = ['综合排序', '价格区间'];
        this.type = ['语言', '职业', '认证', 'HM OS', '大数据', '华为云', '人工智能'];
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: Equipment_Params) {
        if (params.content !== undefined) {
            this.content = params.content;
        }
        if (params.currentTabIndex !== undefined) {
            this.currentTabIndex = params.currentTabIndex;
        }
        if (params.iconPressed1 !== undefined) {
            this.iconPressed1 = params.iconPressed1;
        }
        if (params.iconPressed2 !== undefined) {
            this.iconPressed2 = params.iconPressed2;
        }
        if (params.activeLanguage !== undefined) {
            this.activeLanguage = params.activeLanguage;
        }
        if (params.activeSort !== undefined) {
            this.activeSort = params.activeSort;
        }
        if (params.tabItems !== undefined) {
            this.tabItems = params.tabItems;
        }
        if (params.courses !== undefined) {
            this.courses = params.courses;
        }
        if (params.languages !== undefined) {
            this.languages = params.languages;
        }
        if (params.sortOptions !== undefined) {
            this.sortOptions = params.sortOptions;
        }
        if (params.type !== undefined) {
            this.type = params.type;
        }
    }
    updateStateVars(params: Equipment_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__content.purgeDependencyOnElmtId(rmElmtId);
        this.__currentTabIndex.purgeDependencyOnElmtId(rmElmtId);
        this.__iconPressed1.purgeDependencyOnElmtId(rmElmtId);
        this.__iconPressed2.purgeDependencyOnElmtId(rmElmtId);
        this.__activeLanguage.purgeDependencyOnElmtId(rmElmtId);
        this.__activeSort.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__content.aboutToBeDeleted();
        this.__currentTabIndex.aboutToBeDeleted();
        this.__iconPressed1.aboutToBeDeleted();
        this.__iconPressed2.aboutToBeDeleted();
        this.__activeLanguage.aboutToBeDeleted();
        this.__activeSort.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    private __content: ObservedPropertySimplePU<string>;
    get content() {
        return this.__content.get();
    }
    set content(newValue: string) {
        this.__content.set(newValue);
    }
    private __currentTabIndex: ObservedPropertySimplePU<number>;
    get currentTabIndex() {
        return this.__currentTabIndex.get();
    }
    set currentTabIndex(newValue: number) {
        this.__currentTabIndex.set(newValue);
    }
    private __iconPressed1: ObservedPropertySimplePU<boolean>;
    get iconPressed1() {
        return this.__iconPressed1.get();
    }
    set iconPressed1(newValue: boolean) {
        this.__iconPressed1.set(newValue);
    }
    private __iconPressed2: ObservedPropertySimplePU<boolean>;
    get iconPressed2() {
        return this.__iconPressed2.get();
    }
    set iconPressed2(newValue: boolean) {
        this.__iconPressed2.set(newValue);
    }
    private __activeLanguage: ObservedPropertySimplePU<string>;
    get activeLanguage() {
        return this.__activeLanguage.get();
    }
    set activeLanguage(newValue: string) {
        this.__activeLanguage.set(newValue);
    }
    private __activeSort: ObservedPropertySimplePU<string>;
    get activeSort() {
        return this.__activeSort.get();
    }
    set activeSort(newValue: string) {
        this.__activeSort.set(newValue);
    }
    private tabItems: TabItem[];
    private courses: CourseItem[];
    private languages: string[];
    private sortOptions: string[];
    private type: string[];
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/SearchClass.ets(48:5)", "entry");
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            //this.Magnifyingglass()
            Search.create({ placeholder: '想问什么都可以' });
            Search.debugLine("entry/src/main/ets/pages/SearchClass.ets(50:7)", "entry");
            //this.Magnifyingglass()
            Search.searchButton("探索");
        }, Search);
        //this.Magnifyingglass()
        Search.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 排序选项
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/SearchClass.ets(52:7)", "entry");
            // 排序选项
            Row.justifyContent(FlexAlign.Start);
            // 排序选项
            Row.width('100%');
            // 排序选项
            Row.margin({ top: 20 });
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            ForEach.create();
            const forEachItemGenFunction = (_item, index: number) => {
                const option = _item;
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Row.create();
                    Row.debugLine("entry/src/main/ets/pages/SearchClass.ets(54:11)", "entry");
                    Row.justifyContent(FlexAlign.Center);
                    Row.height(36);
                    Row.padding(10);
                    Row.borderRadius(4);
                    Row.backgroundColor(Color.Transparent);
                }, Row);
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Text.create(option);
                    Text.debugLine("entry/src/main/ets/pages/SearchClass.ets(55:13)", "entry");
                    Text.fontSize(12);
                }, Text);
                Text.pop();
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    If.create();
                    // 根据选项显示不同图标
                    if (option === '综合排序') {
                        this.ifElseBranchUpdateFunction(0, () => {
                            this.observeComponentCreation2((elmtId, isInitialRender) => {
                                Column.create();
                                Column.debugLine("entry/src/main/ets/pages/SearchClass.ets(60:15)", "entry");
                                Column.onClick((e: ClickEvent) => {
                                    this.iconPressed1 = true;
                                    this.iconPressed2 = false;
                                });
                            }, Column);
                            this.observeComponentCreation2((elmtId, isInitialRender) => {
                                Image.create({ "id": 0, "type": 30000, params: ['icons/arrowtriangle_down_fill.svg'], "bundleName": "com.example.myapplication", "moduleName": "entry" });
                                Image.debugLine("entry/src/main/ets/pages/SearchClass.ets(61:17)", "entry");
                                Image.width(10);
                                Image.height(10);
                                Image.margin({ left: 8 });
                                Image.fillColor(this.iconPressed1 ? '#666666' : '#ff000000');
                                Image.opacity(this.iconPressed1 ? 0.8 : 1.0);
                            }, Image);
                            Column.pop();
                        });
                    }
                    else {
                        this.ifElseBranchUpdateFunction(1, () => {
                            this.observeComponentCreation2((elmtId, isInitialRender) => {
                                Column.create();
                                Column.debugLine("entry/src/main/ets/pages/SearchClass.ets(73:15)", "entry");
                                Column.onClick((e: ClickEvent) => {
                                    this.iconPressed2 = true;
                                    this.iconPressed1 = false;
                                });
                            }, Column);
                            this.observeComponentCreation2((elmtId, isInitialRender) => {
                                Image.create({ "id": 0, "type": 30000, params: ['icons/arrowtriangle_down_fill.svg'], "bundleName": "com.example.myapplication", "moduleName": "entry" });
                                Image.debugLine("entry/src/main/ets/pages/SearchClass.ets(74:17)", "entry");
                                Image.width(10);
                                Image.height(10);
                                Image.margin({ left: 8 });
                                Image.fillColor(this.iconPressed2 ? '#666666' : '#ff000000');
                                Image.opacity(this.iconPressed2 ? 0.8 : 1.0);
                            }, Image);
                            Column.pop();
                        });
                    }
                }, If);
                If.pop();
                Row.pop();
            };
            this.forEachUpdateFunction(elmtId, this.sortOptions, forEachItemGenFunction, undefined, true, false);
        }, ForEach);
        ForEach.pop();
        // 排序选项
        Row.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Divider.create();
            Divider.debugLine("entry/src/main/ets/pages/SearchClass.ets(98:7)", "entry");
            Divider.color('#ffc3c3c3');
            Divider.strokeWidth(1);
        }, Divider);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/SearchClass.ets(102:7)", "entry");
            Row.width('100%');
            Row.height('79%');
            Row.backgroundColor('#ffffffff');
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/SearchClass.ets(103:9)", "entry");
            Column.width('20%');
            Column.height('100%');
            Column.backgroundColor('#f0f0f0');
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            ForEach.create();
            const forEachItemGenFunction = (_item, index: number) => {
                const language = _item;
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Column.create();
                    Column.debugLine("entry/src/main/ets/pages/SearchClass.ets(105:13)", "entry");
                    Column.width('100%');
                    Column.height(60);
                    Column.backgroundColor(this.activeLanguage === language ? '#FFFFFF' : '#f0f0f0' // 选中时白色，未选中时灰色
                    );
                    Column.onClick(() => {
                        this.activeLanguage = language; // 点击后更新 activeLanguage
                    });
                }, Column);
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Text.create(language);
                    Text.debugLine("entry/src/main/ets/pages/SearchClass.ets(106:15)", "entry");
                    Text.width('100%');
                    Text.height('100%');
                    Text.textAlign(TextAlign.Center);
                    Text.fontColor(this.activeLanguage === language ? '#c43ab2ee' : '#ff000000');
                }, Text);
                Text.pop();
                Column.pop();
            };
            this.forEachUpdateFunction(elmtId, this.type, forEachItemGenFunction, undefined, true, false);
        }, ForEach);
        ForEach.pop();
        Column.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/SearchClass.ets(126:9)", "entry");
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 语言筛选
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/SearchClass.ets(128:11)", "entry");
            // 语言筛选
            Row.width('80%');
            // 语言筛选
            Row.padding(0);
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            ForEach.create();
            const forEachItemGenFunction = _item => {
                const language = _item;
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Button.createWithLabel(language);
                    Button.debugLine("entry/src/main/ets/pages/SearchClass.ets(130:15)", "entry");
                    Button.fontSize(12);
                    Button.fontColor('#ff343434');
                    Button.backgroundColor(Color.Transparent);
                    ViewStackProcessor.visualState("pressed");
                    ViewStackProcessor.visualState("normal");
                    ViewStackProcessor.visualState();
                    Button.onClick(() => {
                        this.activeLanguage = language;
                    });
                }, Button);
                Button.pop();
            };
            this.forEachUpdateFunction(elmtId, this.languages, forEachItemGenFunction);
        }, ForEach);
        ForEach.pop();
        // 语言筛选
        Row.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Divider.create();
            Divider.debugLine("entry/src/main/ets/pages/SearchClass.ets(150:11)", "entry");
            Divider.color('#ffc3c3c3');
            Divider.strokeWidth(1);
            Divider.width('80%');
        }, Divider);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 课程列表
            Scroll.create();
            Scroll.debugLine("entry/src/main/ets/pages/SearchClass.ets(156:11)", "entry");
        }, Scroll);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/SearchClass.ets(157:13)", "entry");
            Column.width('80%');
            Column.padding(0);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            ForEach.create();
            const forEachItemGenFunction = _item => {
                const course = _item;
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Row.create();
                    Row.debugLine("entry/src/main/ets/pages/SearchClass.ets(159:17)", "entry");
                }, Row);
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Image.create(course.picture);
                    Image.debugLine("entry/src/main/ets/pages/SearchClass.ets(161:19)", "entry");
                    Image.width(77);
                    Image.height(77);
                    Image.objectFit(ImageFit.Cover);
                    Image.borderRadius(8);
                }, Image);
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Column.create();
                    Column.debugLine("entry/src/main/ets/pages/SearchClass.ets(167:19)", "entry");
                    Column.width('75%');
                    Column.padding(0);
                    Column.backgroundColor('#ffffff');
                    Column.borderRadius(8);
                    Column.margin({ bottom: 10 });
                    Column.alignItems(HorizontalAlign.Start);
                }, Column);
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Text.create(course.title);
                    Text.debugLine("entry/src/main/ets/pages/SearchClass.ets(169:21)", "entry");
                    Text.fontSize(14);
                    Text.fontColor('#ff2b2b2b');
                    Text.margin({ top: 8 });
                    Text.padding({ left: 5 });
                }, Text);
                Text.pop();
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Row.create();
                    Row.debugLine("entry/src/main/ets/pages/SearchClass.ets(175:21)", "entry");
                    Row.margin({ top: 30 });
                }, Row);
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Text.create(`${course.price.toFixed(2)}`);
                    Text.debugLine("entry/src/main/ets/pages/SearchClass.ets(176:23)", "entry");
                    Text.fontSize(10);
                    Text.fontColor('#ff2b2b2b');
                    Text.padding({ left: 5 });
                }, Text);
                Text.pop();
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Text.create(`${course.students}人在学`);
                    Text.debugLine("entry/src/main/ets/pages/SearchClass.ets(181:23)", "entry");
                    Text.fontSize(10);
                    Text.fontColor('#ff2b2b2b');
                    Text.textAlign(TextAlign.End);
                    Text.margin({ left: 10 });
                    Text.layoutWeight(1);
                    Text.padding({ right: 10 });
                }, Text);
                Text.pop();
                Row.pop();
                Column.pop();
                Row.pop();
            };
            this.forEachUpdateFunction(elmtId, this.courses, forEachItemGenFunction);
        }, ForEach);
        ForEach.pop();
        Column.pop();
        // 课程列表
        Scroll.pop();
        Column.pop();
        Row.pop();
        Column.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
    static getEntryName(): string {
        return "Equipment";
    }
}
registerNamedRoute(() => new Equipment(undefined, {}), "", { bundleName: "com.example.myapplication", moduleName: "entry", pagePath: "pages/SearchClass", pageFullPath: "entry/src/main/ets/pages/SearchClass", integratedHsp: "false", moduleType: "followWithHap" });
