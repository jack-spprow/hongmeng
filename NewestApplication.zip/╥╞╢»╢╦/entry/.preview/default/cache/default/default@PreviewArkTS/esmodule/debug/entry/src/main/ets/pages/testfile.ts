if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface MyCoursePage_Params {
    currentTab?: number;
}
class MyCoursePage extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.__currentTab = new ObservedPropertySimplePU(0 // 0-近期学习 1-我的购买
        , this, "currentTab");
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: MyCoursePage_Params) {
        if (params.currentTab !== undefined) {
            this.currentTab = params.currentTab;
        }
    }
    updateStateVars(params: MyCoursePage_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__currentTab.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__currentTab.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    private __currentTab: ObservedPropertySimplePU<number>; // 0-近期学习 1-我的购买
    get currentTab() {
        return this.__currentTab.get();
    }
    set currentTab(newValue: number) {
        this.__currentTab.set(newValue);
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/testfile.ets(7:5)", "entry");
            Column.width('100%');
            Column.height('100%');
            Column.padding(16);
            Column.backgroundColor(Color.White);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 标题
            Text.create('我的课程');
            Text.debugLine("entry/src/main/ets/pages/testfile.ets(9:7)", "entry");
            // 标题
            Text.fontSize(24);
            // 标题
            Text.fontWeight(FontWeight.Bold);
            // 标题
            Text.margin({ top: 20, bottom: 20 });
            // 标题
            Text.width('100%');
            // 标题
            Text.textAlign(TextAlign.Center);
        }, Text);
        // 标题
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 标签栏
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/testfile.ets(17:7)", "entry");
            // 标签栏
            Row.width('100%');
            // 标签栏
            Row.borderRadius(8);
            // 标签栏
            Row.margin({ bottom: 20 });
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Button.createWithLabel('近期学习');
            Button.debugLine("entry/src/main/ets/pages/testfile.ets(18:9)", "entry");
            Button.width('50%');
            Button.height(40);
            Button.fontColor(this.currentTab === 0 ? Color.White : Color.Black);
            Button.backgroundColor(this.currentTab === 0 ? '#007DFF' : '#F5F5F5');
            Button.onClick(() => {
                this.currentTab = 0;
            });
        }, Button);
        Button.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Button.createWithLabel('我的购买');
            Button.debugLine("entry/src/main/ets/pages/testfile.ets(27:9)", "entry");
            Button.width('50%');
            Button.height(40);
            Button.fontColor(this.currentTab === 1 ? Color.White : Color.Black);
            Button.backgroundColor(this.currentTab === 1 ? '#007DFF' : '#F5F5F5');
            Button.onClick(() => {
                this.currentTab = 1;
            });
        }, Button);
        Button.pop();
        // 标签栏
        Row.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            If.create();
            // 内容区域
            if (this.currentTab === 0) {
                this.ifElseBranchUpdateFunction(0, () => {
                    this.recentStudyContent.bind(this)();
                });
            }
            else {
                this.ifElseBranchUpdateFunction(1, () => {
                    this.myPurchasesContent.bind(this)();
                });
            }
        }, If);
        If.pop();
        Column.pop();
    }
    // 近期学习内容
    recentStudyContent(parent = null) {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/testfile.ets(56:5)", "entry");
        }, Column);
        // 这里可以添加你的课程列表
        // 示例课程项
        this.courseItem.bind(this)('课程封面1.png', 'ArkUI开发入门', '学习至第3章', '80%');
        this.courseItem.bind(this)('课程封面2.png', 'HarmonyOS应用开发', '学习至第5章', '65%');
        Column.pop();
    }
    // 我的购买内容
    myPurchasesContent(parent = null) {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/testfile.ets(67:5)", "entry");
        }, Column);
        // 这里可以添加已购课程列表
        // 示例课程项
        this.courseItem.bind(this)('课程封面3.png', 'TypeScript进阶', '已购买', '');
        this.courseItem.bind(this)('课程封面4.png', '前端性能优化', '已购买', '');
        Column.pop();
    }
    // 课程项组件
    courseItem(image: string, title: string, subTitle: string, progress: string, parent = null) {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/testfile.ets(78:5)", "entry");
            Row.width('100%');
            Row.padding(12);
            Row.margin({ bottom: 12 });
            Row.backgroundColor('#F9F9F9');
            Row.borderRadius(8);
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 课程封面
            Image.create(image);
            Image.debugLine("entry/src/main/ets/pages/testfile.ets(80:7)", "entry");
            // 课程封面
            Image.width(80);
            // 课程封面
            Image.height(60);
            // 课程封面
            Image.objectFit(ImageFit.Cover);
            // 课程封面
            Image.borderRadius(4);
        }, Image);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 课程信息
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/testfile.ets(87:7)", "entry");
            // 课程信息
            Column.margin({ left: 12 });
            // 课程信息
            Column.alignItems(HorizontalAlign.Start);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(title);
            Text.debugLine("entry/src/main/ets/pages/testfile.ets(88:9)", "entry");
            Text.fontSize(16);
            Text.fontWeight(FontWeight.Medium);
            Text.margin({ bottom: 4 });
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(subTitle);
            Text.debugLine("entry/src/main/ets/pages/testfile.ets(93:9)", "entry");
            Text.fontSize(12);
            Text.fontColor('#999999');
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            If.create();
            if (progress) {
                this.ifElseBranchUpdateFunction(0, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Row.create();
                        Row.debugLine("entry/src/main/ets/pages/testfile.ets(98:11)", "entry");
                        Row.width('100%');
                        Row.margin({ top: 8 });
                    }, Row);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Progress.create({ value: parseInt(progress), total: 100, type: ProgressType.Linear });
                        Progress.debugLine("entry/src/main/ets/pages/testfile.ets(99:13)", "entry");
                        Progress.width('70%');
                        Progress.height(4);
                    }, Progress);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create(progress);
                        Text.debugLine("entry/src/main/ets/pages/testfile.ets(103:13)", "entry");
                        Text.fontSize(12);
                        Text.margin({ left: 8 });
                    }, Text);
                    Text.pop();
                    Row.pop();
                });
            }
            else {
                this.ifElseBranchUpdateFunction(1, () => {
                });
            }
        }, If);
        If.pop();
        // 课程信息
        Column.pop();
        Row.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
    static getEntryName(): string {
        return "MyCoursePage";
    }
}
registerNamedRoute(() => new MyCoursePage(undefined, {}), "", { bundleName: "com.example.myapplication", moduleName: "entry", pagePath: "pages/testfile", pageFullPath: "entry/src/main/ets/pages/testfile", integratedHsp: "false", moduleType: "followWithHap" });
