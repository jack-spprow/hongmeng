if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface ChildAccountBinding_Params {
    isBound?: boolean;
    childAccount?: string;
    monitorEnabled?: boolean;
}
class ChildAccountBinding extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.__isBound = new ObservedPropertySimplePU(false, this, "isBound");
        this.__childAccount = new ObservedPropertySimplePU('', this, "childAccount");
        this.__monitorEnabled = new ObservedPropertySimplePU(false, this, "monitorEnabled");
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: ChildAccountBinding_Params) {
        if (params.isBound !== undefined) {
            this.isBound = params.isBound;
        }
        if (params.childAccount !== undefined) {
            this.childAccount = params.childAccount;
        }
        if (params.monitorEnabled !== undefined) {
            this.monitorEnabled = params.monitorEnabled;
        }
    }
    updateStateVars(params: ChildAccountBinding_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__isBound.purgeDependencyOnElmtId(rmElmtId);
        this.__childAccount.purgeDependencyOnElmtId(rmElmtId);
        this.__monitorEnabled.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__isBound.aboutToBeDeleted();
        this.__childAccount.aboutToBeDeleted();
        this.__monitorEnabled.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    private __isBound: ObservedPropertySimplePU<boolean>;
    get isBound() {
        return this.__isBound.get();
    }
    set isBound(newValue: boolean) {
        this.__isBound.set(newValue);
    }
    private __childAccount: ObservedPropertySimplePU<string>;
    get childAccount() {
        return this.__childAccount.get();
    }
    set childAccount(newValue: string) {
        this.__childAccount.set(newValue);
    }
    private __monitorEnabled: ObservedPropertySimplePU<boolean>;
    get monitorEnabled() {
        return this.__monitorEnabled.get();
    }
    set monitorEnabled(newValue: boolean) {
        this.__monitorEnabled.set(newValue);
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create({ space: 20 });
            Column.debugLine("entry/src/main/ets/pages/settings/ParentalControl.ets(10:5)", "entry");
            Column.padding(20);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            If.create();
            if (!this.isBound) {
                this.ifElseBranchUpdateFunction(0, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Column.create({ space: 10 });
                        Column.debugLine("entry/src/main/ets/pages/settings/ParentalControl.ets(12:9)", "entry");
                    }, Column);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        TextInput.create({ placeholder: '输入孩子的账号', text: this.childAccount });
                        TextInput.debugLine("entry/src/main/ets/pages/settings/ParentalControl.ets(13:11)", "entry");
                        TextInput.onChange(v => this.childAccount = v);
                    }, TextInput);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Button.createWithLabel('绑定孩子账号');
                        Button.debugLine("entry/src/main/ets/pages/settings/ParentalControl.ets(16:11)", "entry");
                        Button.onClick(() => {
                            if (this.childAccount.trim() !== '') {
                                this.isBound = true;
                                console.log('绑定成功:', this.childAccount);
                            }
                            else {
                                console.log('请输入有效账号');
                            }
                        });
                    }, Button);
                    Button.pop();
                    Column.pop();
                });
            }
            else {
                this.ifElseBranchUpdateFunction(1, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Column.create({ space: 10 });
                        Column.debugLine("entry/src/main/ets/pages/settings/ParentalControl.ets(27:9)", "entry");
                    }, Column);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create('已绑定孩子账号：' + this.childAccount);
                        Text.debugLine("entry/src/main/ets/pages/settings/ParentalControl.ets(28:11)", "entry");
                    }, Text);
                    Text.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Row.create();
                        Row.debugLine("entry/src/main/ets/pages/settings/ParentalControl.ets(30:11)", "entry");
                        Row.justifyContent(FlexAlign.SpaceBetween);
                        Row.alignItems(VerticalAlign.Center);
                    }, Row);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create('启用监督功能');
                        Text.debugLine("entry/src/main/ets/pages/settings/ParentalControl.ets(31:13)", "entry");
                    }, Text);
                    Text.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Toggle.create({ type: ToggleType.Switch, isOn: this.monitorEnabled });
                        Toggle.debugLine("entry/src/main/ets/pages/settings/ParentalControl.ets(32:13)", "entry");
                        Toggle.onChange(v => {
                            this.monitorEnabled = v;
                            console.log('家长监督:', v);
                        });
                    }, Toggle);
                    Toggle.pop();
                    Row.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Button.createWithLabel('解除绑定');
                        Button.debugLine("entry/src/main/ets/pages/settings/ParentalControl.ets(41:11)", "entry");
                        Button.onClick(() => {
                            this.isBound = false;
                            this.childAccount = '';
                            this.monitorEnabled = false;
                            console.log('已解除绑定');
                        });
                    }, Button);
                    Button.pop();
                    Column.pop();
                });
            }
        }, If);
        If.pop();
        Column.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
    static getEntryName(): string {
        return "ChildAccountBinding";
    }
}
registerNamedRoute(() => new ChildAccountBinding(undefined, {}), "", { bundleName: "com.example.myapplication", moduleName: "entry", pagePath: "pages/settings/ParentalControl", pageFullPath: "entry/src/main/ets/pages/settings/ParentalControl", integratedHsp: "false", moduleType: "followWithHap" });
