if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface NotificationSettings_Params {
    notifyByPhone?: boolean;
    notifyByEmail?: boolean;
    courseUpdate?: boolean;
    eventNotify?: boolean;
}
class NotificationSettings extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.__notifyByPhone = new ObservedPropertySimplePU(true, this, "notifyByPhone");
        this.__notifyByEmail = new ObservedPropertySimplePU(false, this, "notifyByEmail");
        this.__courseUpdate = new ObservedPropertySimplePU(true, this, "courseUpdate");
        this.__eventNotify = new ObservedPropertySimplePU(false, this, "eventNotify");
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: NotificationSettings_Params) {
        if (params.notifyByPhone !== undefined) {
            this.notifyByPhone = params.notifyByPhone;
        }
        if (params.notifyByEmail !== undefined) {
            this.notifyByEmail = params.notifyByEmail;
        }
        if (params.courseUpdate !== undefined) {
            this.courseUpdate = params.courseUpdate;
        }
        if (params.eventNotify !== undefined) {
            this.eventNotify = params.eventNotify;
        }
    }
    updateStateVars(params: NotificationSettings_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__notifyByPhone.purgeDependencyOnElmtId(rmElmtId);
        this.__notifyByEmail.purgeDependencyOnElmtId(rmElmtId);
        this.__courseUpdate.purgeDependencyOnElmtId(rmElmtId);
        this.__eventNotify.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__notifyByPhone.aboutToBeDeleted();
        this.__notifyByEmail.aboutToBeDeleted();
        this.__courseUpdate.aboutToBeDeleted();
        this.__eventNotify.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    private __notifyByPhone: ObservedPropertySimplePU<boolean>;
    get notifyByPhone() {
        return this.__notifyByPhone.get();
    }
    set notifyByPhone(newValue: boolean) {
        this.__notifyByPhone.set(newValue);
    }
    private __notifyByEmail: ObservedPropertySimplePU<boolean>;
    get notifyByEmail() {
        return this.__notifyByEmail.get();
    }
    set notifyByEmail(newValue: boolean) {
        this.__notifyByEmail.set(newValue);
    }
    private __courseUpdate: ObservedPropertySimplePU<boolean>;
    get courseUpdate() {
        return this.__courseUpdate.get();
    }
    set courseUpdate(newValue: boolean) {
        this.__courseUpdate.set(newValue);
    }
    private __eventNotify: ObservedPropertySimplePU<boolean>;
    get eventNotify() {
        return this.__eventNotify.get();
    }
    set eventNotify(newValue: boolean) {
        this.__eventNotify.set(newValue);
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create({ space: 15 });
            Column.debugLine("entry/src/main/ets/pages/settings/NotificationSettings.ets(11:5)", "entry");
            Column.padding(20);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('通知接收方式');
            Text.debugLine("entry/src/main/ets/pages/settings/NotificationSettings.ets(12:7)", "entry");
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/settings/NotificationSettings.ets(14:7)", "entry");
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('手机通知');
            Text.debugLine("entry/src/main/ets/pages/settings/NotificationSettings.ets(15:9)", "entry");
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Toggle.create({ type: ToggleType.Switch, isOn: this.notifyByPhone });
            Toggle.debugLine("entry/src/main/ets/pages/settings/NotificationSettings.ets(16:9)", "entry");
            Toggle.onChange(v => this.notifyByPhone = v);
        }, Toggle);
        Toggle.pop();
        Row.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/settings/NotificationSettings.ets(20:7)", "entry");
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('邮箱通知');
            Text.debugLine("entry/src/main/ets/pages/settings/NotificationSettings.ets(21:9)", "entry");
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Toggle.create({ type: ToggleType.Switch, isOn: this.notifyByEmail });
            Toggle.debugLine("entry/src/main/ets/pages/settings/NotificationSettings.ets(22:9)", "entry");
            Toggle.onChange(v => this.notifyByEmail = v);
        }, Toggle);
        Toggle.pop();
        Row.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Divider.create();
            Divider.debugLine("entry/src/main/ets/pages/settings/NotificationSettings.ets(26:7)", "entry");
        }, Divider);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('通知类型设置');
            Text.debugLine("entry/src/main/ets/pages/settings/NotificationSettings.ets(28:7)", "entry");
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/settings/NotificationSettings.ets(30:7)", "entry");
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('课程更新通知');
            Text.debugLine("entry/src/main/ets/pages/settings/NotificationSettings.ets(31:9)", "entry");
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Toggle.create({ type: ToggleType.Switch, isOn: this.courseUpdate });
            Toggle.debugLine("entry/src/main/ets/pages/settings/NotificationSettings.ets(32:9)", "entry");
            Toggle.onChange(v => this.courseUpdate = v);
        }, Toggle);
        Toggle.pop();
        Row.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/settings/NotificationSettings.ets(36:7)", "entry");
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('活动通知');
            Text.debugLine("entry/src/main/ets/pages/settings/NotificationSettings.ets(37:9)", "entry");
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Toggle.create({ type: ToggleType.Switch, isOn: this.eventNotify });
            Toggle.debugLine("entry/src/main/ets/pages/settings/NotificationSettings.ets(38:9)", "entry");
            Toggle.onChange(v => this.eventNotify = v);
        }, Toggle);
        Toggle.pop();
        Row.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Button.createWithLabel('保存设置');
            Button.debugLine("entry/src/main/ets/pages/settings/NotificationSettings.ets(42:7)", "entry");
            Button.onClick(() => {
                console.log('通知设置已保存');
            });
        }, Button);
        Button.pop();
        Column.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
    static getEntryName(): string {
        return "NotificationSettings";
    }
}
registerNamedRoute(() => new NotificationSettings(undefined, {}), "", { bundleName: "com.example.myapplication", moduleName: "entry", pagePath: "pages/settings/NotificationSettings", pageFullPath: "entry/src/main/ets/pages/settings/NotificationSettings", integratedHsp: "false", moduleType: "followWithHap" });
