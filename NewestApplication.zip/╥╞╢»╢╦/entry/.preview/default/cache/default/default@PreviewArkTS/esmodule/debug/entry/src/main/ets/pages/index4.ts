if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface index4_Params {
    newsList?: News[];
}
import type News from '../model/Model';
export default class index4 extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.__newsList = new ObservedPropertyObjectPU([
            {
                id: 1,
                cover: 'edu4.jpg',
                title: 'hello world入门'
            },
            {
                id: 2,
                cover: 'edu11.png',
                title: 'HarmonyOS极客马拉松'
            },
            {
                id: 3,
                cover: 'edu5.jpg',
                title: 'ArkTs基础知识'
            }
        ], this, "newsList");
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: index4_Params) {
        if (params.newsList !== undefined) {
            this.newsList = params.newsList;
        }
    }
    updateStateVars(params: index4_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__newsList.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__newsList.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    private __newsList: ObservedPropertyObjectPU<News[]>;
    get newsList() {
        return this.__newsList.get();
    }
    set newsList(newValue: News[]) {
        this.__newsList.set(newValue);
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/index4.ets(24:7)", "entry");
            Column.width('100%');
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/index4.ets(26:9)", "entry");
            Row.width('100%');
            Row.justifyContent(FlexAlign.End);
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Image.create({ "id": 0, "type": 30000, params: ['icons/gearshape_3.svg'], "bundleName": "com.example.myapplication", "moduleName": "entry" });
            Image.debugLine("entry/src/main/ets/pages/index4.ets(28:11)", "entry");
            Image.width(30);
        }, Image);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Image.create({ "id": 0, "type": 30000, params: ['icons/bell_fill_3.svg'], "bundleName": "com.example.myapplication", "moduleName": "entry" });
            Image.debugLine("entry/src/main/ets/pages/index4.ets(29:11)", "entry");
            Image.width(30);
        }, Image);
        Row.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create({ space: 10 });
            Row.debugLine("entry/src/main/ets/pages/index4.ets(33:9)", "entry");
            Row.width('92%');
            Row.justifyContent(FlexAlign.Start);
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Image.create({ "id": 0, "type": 30000, params: ['image/edu3.jpg'], "bundleName": "com.example.myapplication", "moduleName": "entry" });
            Image.debugLine("entry/src/main/ets/pages/index4.ets(35:11)", "entry");
            Image.width('30%');
            Image.height(70);
            Image.borderRadius(50);
        }, Image);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/index4.ets(36:11)", "entry");
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('胡桃');
            Text.debugLine("entry/src/main/ets/pages/index4.ets(38:13)", "entry");
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('UID:232403677');
            Text.debugLine("entry/src/main/ets/pages/index4.ets(39:13)", "entry");
        }, Text);
        Text.pop();
        Column.pop();
        Row.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('观看历史');
            Text.debugLine("entry/src/main/ets/pages/index4.ets(44:9)", "entry");
            Text.fontSize(18);
            Text.fontWeight(600);
            Text.textAlign(TextAlign.Start);
            Text.width('92%');
            Text.margin(20);
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Grid.create();
            Grid.debugLine("entry/src/main/ets/pages/index4.ets(45:9)", "entry");
            Grid.backgroundColor(Color.White);
            Grid.width('95%');
            Grid.height(180);
            Grid.columnsGap(15);
            Grid.rowsTemplate('1fr');
            Grid.scrollBar(BarState.Off);
        }, Grid);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            ForEach.create();
            const forEachItemGenFunction = (_item, index: number) => {
                const news = _item;
                {
                    const itemCreation2 = (elmtId, isInitialRender) => {
                        GridItem.create(() => { }, false);
                        GridItem.debugLine("entry/src/main/ets/pages/index4.ets(47:13)", "entry");
                    };
                    const observedDeepRender = () => {
                        this.observeComponentCreation2(itemCreation2, GridItem);
                        this.gridCard.bind(this)(news);
                        GridItem.pop();
                    };
                    observedDeepRender();
                }
            };
            this.forEachUpdateFunction(elmtId, this.newsList, forEachItemGenFunction, undefined, true, false);
        }, ForEach);
        ForEach.pop();
        Grid.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            /*.shadow(
              {
                offsetX:2,
                offsetY:4,
                color:Color.Gray,
                radius:15
              }
            )*/
            Column.create({ space: 20 });
            Column.debugLine("entry/src/main/ets/pages/index4.ets(66:9)", "entry");
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('我的内容');
            Text.debugLine("entry/src/main/ets/pages/index4.ets(68:11)", "entry");
            Text.width('92%');
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create({ space: 50 });
            Row.debugLine("entry/src/main/ets/pages/index4.ets(69:11)", "entry");
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/index4.ets(70:13)", "entry");
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Image.create({ "id": 0, "type": 30000, params: ['icons/doc_3.svg'], "bundleName": "com.example.myapplication", "moduleName": "entry" });
            Image.debugLine("entry/src/main/ets/pages/index4.ets(71:15)", "entry");
            Image.width(30);
        }, Image);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('作业');
            Text.debugLine("entry/src/main/ets/pages/index4.ets(72:15)", "entry");
        }, Text);
        Text.pop();
        Column.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/index4.ets(75:13)", "entry");
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Image.create({ "id": 0, "type": 30000, params: ['icons/calendar_3.svg'], "bundleName": "com.example.myapplication", "moduleName": "entry" });
            Image.debugLine("entry/src/main/ets/pages/index4.ets(76:15)", "entry");
            Image.width(30);
        }, Image);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('打卡');
            Text.debugLine("entry/src/main/ets/pages/index4.ets(77:15)", "entry");
        }, Text);
        Text.pop();
        Column.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/index4.ets(80:13)", "entry");
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Image.create({ "id": 0, "type": 30000, params: ['icons/star.svg'], "bundleName": "com.example.myapplication", "moduleName": "entry" });
            Image.debugLine("entry/src/main/ets/pages/index4.ets(81:15)", "entry");
            Image.width(30);
        }, Image);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('收藏');
            Text.debugLine("entry/src/main/ets/pages/index4.ets(82:15)", "entry");
        }, Text);
        Text.pop();
        Column.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/index4.ets(85:13)", "entry");
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Image.create({ "id": 0, "type": 30000, params: ['icons/doc_plaintext_and_pencil_3.svg'], "bundleName": "com.example.myapplication", "moduleName": "entry" });
            Image.debugLine("entry/src/main/ets/pages/index4.ets(86:15)", "entry");
            Image.width(30);
        }, Image);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('笔记');
            Text.debugLine("entry/src/main/ets/pages/index4.ets(87:15)", "entry");
        }, Text);
        Text.pop();
        Column.pop();
        Row.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('我的账户');
            Text.debugLine("entry/src/main/ets/pages/index4.ets(91:11)", "entry");
            Text.width('92%');
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create({ space: 50 });
            Row.debugLine("entry/src/main/ets/pages/index4.ets(92:11)", "entry");
            Row.width('92%');
            Row.margin({ left: 50 });
            Row.justifyContent(FlexAlign.Start);
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/index4.ets(93:13)", "entry");
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Image.create({ "id": 0, "type": 30000, params: ['icons/list_checkmask_3.svg'], "bundleName": "com.example.myapplication", "moduleName": "entry" });
            Image.debugLine("entry/src/main/ets/pages/index4.ets(94:15)", "entry");
            Image.width(30);
        }, Image);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('订单');
            Text.debugLine("entry/src/main/ets/pages/index4.ets(95:15)", "entry");
        }, Text);
        Text.pop();
        Column.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/index4.ets(98:13)", "entry");
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Image.create({ "id": 0, "type": 30000, params: ['image/ticket.png'], "bundleName": "com.example.myapplication", "moduleName": "entry" });
            Image.debugLine("entry/src/main/ets/pages/index4.ets(99:15)", "entry");
            Image.width(30);
        }, Image);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('优惠券');
            Text.debugLine("entry/src/main/ets/pages/index4.ets(100:15)", "entry");
        }, Text);
        Text.pop();
        Column.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/index4.ets(103:13)", "entry");
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Image.create({ "id": 0, "type": 30000, params: ['image/balance.png'], "bundleName": "com.example.myapplication", "moduleName": "entry" });
            Image.debugLine("entry/src/main/ets/pages/index4.ets(104:15)", "entry");
            Image.width(30);
        }, Image);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('余额');
            Text.debugLine("entry/src/main/ets/pages/index4.ets(105:15)", "entry");
        }, Text);
        Text.pop();
        Column.pop();
        Row.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('我的账户');
            Text.debugLine("entry/src/main/ets/pages/index4.ets(112:11)", "entry");
            Text.width('92%');
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create({ space: 50 });
            Row.debugLine("entry/src/main/ets/pages/index4.ets(113:11)", "entry");
            Row.width('92%');
            Row.margin({ left: 50 });
            Row.justifyContent(FlexAlign.Start);
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/index4.ets(114:13)", "entry");
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Image.create({ "id": 0, "type": 30000, params: ['image/service.png'], "bundleName": "com.example.myapplication", "moduleName": "entry" });
            Image.debugLine("entry/src/main/ets/pages/index4.ets(115:15)", "entry");
            Image.width(30);
        }, Image);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('客服');
            Text.debugLine("entry/src/main/ets/pages/index4.ets(116:15)", "entry");
        }, Text);
        Text.pop();
        Column.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/index4.ets(119:13)", "entry");
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Image.create({ "id": 0, "type": 30000, params: ['image/cache.png'], "bundleName": "com.example.myapplication", "moduleName": "entry" });
            Image.debugLine("entry/src/main/ets/pages/index4.ets(120:15)", "entry");
            Image.width(30);
        }, Image);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('缓存');
            Text.debugLine("entry/src/main/ets/pages/index4.ets(121:15)", "entry");
        }, Text);
        Text.pop();
        Column.pop();
        Row.pop();
        /*.shadow(
          {
            offsetX:2,
            offsetY:4,
            color:Color.Gray,
            radius:15
          }
        )*/
        Column.pop();
        Column.pop();
    }
    gridCard(news: News, parent = null) {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/index4.ets(135:5)", "entry");
            Column.width('42%');
            Column.height('100%');
            Column.backgroundColor('#FFFFFF');
            Column.borderRadius(10);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Stack.create({ alignContent: Alignment.BottomEnd });
            Stack.debugLine("entry/src/main/ets/pages/index4.ets(136:7)", "entry");
            Stack.width('100%');
            Stack.height('55%');
        }, Stack);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Image.create({ "id": -1, "type": 30000, params: ['image/' + news.cover], "bundleName": "com.example.myapplication", "moduleName": "entry" });
            Image.debugLine("entry/src/main/ets/pages/index4.ets(137:9)", "entry");
            Image.width('100%');
            Image.height('100%');
            Image.objectFit(ImageFit.Cover);
            Image.borderRadius({ topLeft: 10, topRight: 10 });
        }, Image);
        Stack.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/index4.ets(143:7)", "entry");
            Column.width('100%');
            Column.height('45%');
            Column.justifyContent(FlexAlign.SpaceAround);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(news.title);
            Text.debugLine("entry/src/main/ets/pages/index4.ets(144:9)", "entry");
            Text.width('90%');
            Text.fontSize(14);
            Text.maxLines(2);
            Text.textOverflow({ overflow: TextOverflow.Ellipsis });
        }, Text);
        Text.pop();
        Column.pop();
        Column.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
}
