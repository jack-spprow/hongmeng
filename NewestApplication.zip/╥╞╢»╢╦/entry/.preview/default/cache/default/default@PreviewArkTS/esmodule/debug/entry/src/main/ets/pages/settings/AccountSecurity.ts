if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface AccountSecurity_Params {
    loginEmail?: string;
    phoneNumber?: string;
    is2FAEnabled?: boolean;
}
class AccountSecurity extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.__loginEmail = new ObservedPropertySimplePU('zhangsan@example.com', this, "loginEmail");
        this.__phoneNumber = new ObservedPropertySimplePU('138****8888', this, "phoneNumber");
        this.__is2FAEnabled = new ObservedPropertySimplePU(false, this, "is2FAEnabled");
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: AccountSecurity_Params) {
        if (params.loginEmail !== undefined) {
            this.loginEmail = params.loginEmail;
        }
        if (params.phoneNumber !== undefined) {
            this.phoneNumber = params.phoneNumber;
        }
        if (params.is2FAEnabled !== undefined) {
            this.is2FAEnabled = params.is2FAEnabled;
        }
    }
    updateStateVars(params: AccountSecurity_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__loginEmail.purgeDependencyOnElmtId(rmElmtId);
        this.__phoneNumber.purgeDependencyOnElmtId(rmElmtId);
        this.__is2FAEnabled.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__loginEmail.aboutToBeDeleted();
        this.__phoneNumber.aboutToBeDeleted();
        this.__is2FAEnabled.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    private __loginEmail: ObservedPropertySimplePU<string>;
    get loginEmail() {
        return this.__loginEmail.get();
    }
    set loginEmail(newValue: string) {
        this.__loginEmail.set(newValue);
    }
    private __phoneNumber: ObservedPropertySimplePU<string>;
    get phoneNumber() {
        return this.__phoneNumber.get();
    }
    set phoneNumber(newValue: string) {
        this.__phoneNumber.set(newValue);
    }
    private __is2FAEnabled: ObservedPropertySimplePU<boolean>;
    get is2FAEnabled() {
        return this.__is2FAEnabled.get();
    }
    set is2FAEnabled(newValue: boolean) {
        this.__is2FAEnabled.set(newValue);
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create({ space: 20 });
            Column.debugLine("entry/src/main/ets/pages/settings/AccountSecurity.ets(10:5)", "entry");
            Column.padding(20);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('登录邮箱: ' + this.loginEmail);
            Text.debugLine("entry/src/main/ets/pages/settings/AccountSecurity.ets(11:7)", "entry");
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('绑定手机号: ' + this.phoneNumber);
            Text.debugLine("entry/src/main/ets/pages/settings/AccountSecurity.ets(12:7)", "entry");
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/settings/AccountSecurity.ets(14:7)", "entry");
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('开启双重认证');
            Text.debugLine("entry/src/main/ets/pages/settings/AccountSecurity.ets(15:9)", "entry");
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Toggle.create({ type: ToggleType.Switch, isOn: this.is2FAEnabled });
            Toggle.debugLine("entry/src/main/ets/pages/settings/AccountSecurity.ets(16:9)", "entry");
            Toggle.onChange(value => {
                this.is2FAEnabled = value;
                console.log('2FA状态:', value);
            });
        }, Toggle);
        Toggle.pop();
        Row.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Button.createWithLabel('绑定第三方账号');
            Button.debugLine("entry/src/main/ets/pages/settings/AccountSecurity.ets(24:7)", "entry");
            Button.onClick(() => {
                console.log('跳转到绑定页面');
            });
        }, Button);
        Button.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Button.createWithLabel('忘记密码？找回');
            Button.debugLine("entry/src/main/ets/pages/settings/AccountSecurity.ets(29:7)", "entry");
            Button.onClick(() => {
                console.log('跳转找回密码页');
            });
        }, Button);
        Button.pop();
        Column.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
    static getEntryName(): string {
        return "AccountSecurity";
    }
}
registerNamedRoute(() => new AccountSecurity(undefined, {}), "", { bundleName: "com.example.myapplication", moduleName: "entry", pagePath: "pages/settings/AccountSecurity", pageFullPath: "entry/src/main/ets/pages/settings/AccountSecurity", integratedHsp: "false", moduleType: "followWithHap" });
