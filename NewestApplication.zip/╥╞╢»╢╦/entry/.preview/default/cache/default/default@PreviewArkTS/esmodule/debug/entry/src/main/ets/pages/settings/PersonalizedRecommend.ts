if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface PersonalizedRecommend_Params {
    isEnabled?: boolean;
    interestTags?: string[];
    newTag?: string;
}
class PersonalizedRecommend extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.__isEnabled = new ObservedPropertySimplePU(true, this, "isEnabled");
        this.__interestTags = new ObservedPropertyObjectPU(['编程', '英语', '数学'], this, "interestTags");
        this.__newTag = new ObservedPropertySimplePU('', this, "newTag");
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: PersonalizedRecommend_Params) {
        if (params.isEnabled !== undefined) {
            this.isEnabled = params.isEnabled;
        }
        if (params.interestTags !== undefined) {
            this.interestTags = params.interestTags;
        }
        if (params.newTag !== undefined) {
            this.newTag = params.newTag;
        }
    }
    updateStateVars(params: PersonalizedRecommend_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__isEnabled.purgeDependencyOnElmtId(rmElmtId);
        this.__interestTags.purgeDependencyOnElmtId(rmElmtId);
        this.__newTag.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__isEnabled.aboutToBeDeleted();
        this.__interestTags.aboutToBeDeleted();
        this.__newTag.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    private __isEnabled: ObservedPropertySimplePU<boolean>;
    get isEnabled() {
        return this.__isEnabled.get();
    }
    set isEnabled(newValue: boolean) {
        this.__isEnabled.set(newValue);
    }
    private __interestTags: ObservedPropertyObjectPU<string[]>;
    get interestTags() {
        return this.__interestTags.get();
    }
    set interestTags(newValue: string[]) {
        this.__interestTags.set(newValue);
    }
    private __newTag: ObservedPropertySimplePU<string>;
    get newTag() {
        return this.__newTag.get();
    }
    set newTag(newValue: string) {
        this.__newTag.set(newValue);
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create({ space: 20 });
            Column.debugLine("entry/src/main/ets/pages/settings/PersonalizedRecommend.ets(10:5)", "entry");
            Column.padding(20);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/settings/PersonalizedRecommend.ets(11:7)", "entry");
            Row.justifyContent(FlexAlign.SpaceBetween);
            Row.alignItems(VerticalAlign.Center);
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('开启个性化推荐');
            Text.debugLine("entry/src/main/ets/pages/settings/PersonalizedRecommend.ets(12:9)", "entry");
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Toggle.create({ type: ToggleType.Switch, isOn: this.isEnabled });
            Toggle.debugLine("entry/src/main/ets/pages/settings/PersonalizedRecommend.ets(13:9)", "entry");
            Toggle.onChange(v => this.isEnabled = v);
        }, Toggle);
        Toggle.pop();
        Row.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            If.create();
            if (this.isEnabled) {
                this.ifElseBranchUpdateFunction(0, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create('我的兴趣标签：');
                        Text.debugLine("entry/src/main/ets/pages/settings/PersonalizedRecommend.ets(20:9)", "entry");
                    }, Text);
                    Text.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Column.create({ space: 10 });
                        Column.debugLine("entry/src/main/ets/pages/settings/PersonalizedRecommend.ets(22:9)", "entry");
                    }, Column);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        ForEach.create();
                        const forEachItemGenFunction = _item => {
                            const tag = _item;
                            this.observeComponentCreation2((elmtId, isInitialRender) => {
                                Row.create({ space: 10 });
                                Row.debugLine("entry/src/main/ets/pages/settings/PersonalizedRecommend.ets(24:13)", "entry");
                            }, Row);
                            this.observeComponentCreation2((elmtId, isInitialRender) => {
                                Text.create(tag);
                                Text.debugLine("entry/src/main/ets/pages/settings/PersonalizedRecommend.ets(25:15)", "entry");
                            }, Text);
                            Text.pop();
                            this.observeComponentCreation2((elmtId, isInitialRender) => {
                                Button.createWithLabel('移除');
                                Button.debugLine("entry/src/main/ets/pages/settings/PersonalizedRecommend.ets(26:15)", "entry");
                                Button.onClick(() => {
                                    this.interestTags = this.interestTags.filter(t => t !== tag);
                                });
                            }, Button);
                            Button.pop();
                            Row.pop();
                        };
                        this.forEachUpdateFunction(elmtId, this.interestTags, forEachItemGenFunction);
                    }, ForEach);
                    ForEach.pop();
                    Column.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Row.create({ space: 10 });
                        Row.debugLine("entry/src/main/ets/pages/settings/PersonalizedRecommend.ets(33:9)", "entry");
                    }, Row);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        TextInput.create({ placeholder: '添加新标签', text: this.newTag });
                        TextInput.debugLine("entry/src/main/ets/pages/settings/PersonalizedRecommend.ets(34:11)", "entry");
                        TextInput.onChange(v => this.newTag = v);
                    }, TextInput);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Button.createWithLabel('添加');
                        Button.debugLine("entry/src/main/ets/pages/settings/PersonalizedRecommend.ets(36:11)", "entry");
                        Button.onClick(() => {
                            if (this.newTag.trim() && !this.interestTags.includes(this.newTag.trim())) {
                                this.interestTags.push(this.newTag.trim());
                                this.newTag = '';
                            }
                        });
                    }, Button);
                    Button.pop();
                    Row.pop();
                });
            }
            else {
                this.ifElseBranchUpdateFunction(1, () => {
                });
            }
        }, If);
        If.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Button.createWithLabel('保存设置');
            Button.debugLine("entry/src/main/ets/pages/settings/PersonalizedRecommend.ets(45:7)", "entry");
            Button.onClick(() => {
                console.log('个性化推荐设置保存:', ObservedObject.GetRawObject(this.interestTags));
            });
        }, Button);
        Button.pop();
        Column.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
    static getEntryName(): string {
        return "PersonalizedRecommend";
    }
}
registerNamedRoute(() => new PersonalizedRecommend(undefined, {}), "", { bundleName: "com.example.myapplication", moduleName: "entry", pagePath: "pages/settings/PersonalizedRecommend", pageFullPath: "entry/src/main/ets/pages/settings/PersonalizedRecommend", integratedHsp: "false", moduleType: "followWithHap" });
