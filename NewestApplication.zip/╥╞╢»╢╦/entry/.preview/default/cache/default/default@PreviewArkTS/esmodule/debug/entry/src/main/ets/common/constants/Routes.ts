// common/constants/Routes.ts
export const Routes = {
    PROFILE: 'pages/settings/ProfileSettings',
    ACCOUNT: 'pages/settings/AccountSecurity',
    NOTIFY: 'pages/settings/NotificationSettings',
    EYECARE: 'pages/settings/EyeCareMode',
    PARENT: 'pages/settings/ParentalControl',
    CACHE: 'pages/settings/ClearCache',
    RECOMMEND: 'pages/settings/PersonalizedRecommend',
    ABOUT: 'pages/settings/AboutPage',
    PRIVACY: 'pages/settings/PrivacyList',
    THIRD: 'pages/settings/ThirdPartyShare',
    LOGOUT: 'pages/settings/LogoutPage'
};
