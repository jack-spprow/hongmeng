if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface PrivacyList_Params {
}
class PrivacyList extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: PrivacyList_Params) {
    }
    updateStateVars(params: PrivacyList_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
    }
    aboutToBeDeleted() {
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create({ space: 15 });
            Column.debugLine("entry/src/main/ets/pages/settings/PrivacyList.ets(6:5)", "entry");
            Column.padding(20);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('我们收集以下个人信息：');
            Text.debugLine("entry/src/main/ets/pages/settings/PrivacyList.ets(7:7)", "entry");
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('- 姓名、邮箱、手机号');
            Text.debugLine("entry/src/main/ets/pages/settings/PrivacyList.ets(8:7)", "entry");
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('- 兴趣标签、课程浏览记录');
            Text.debugLine("entry/src/main/ets/pages/settings/PrivacyList.ets(9:7)", "entry");
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('- 头像、简介');
            Text.debugLine("entry/src/main/ets/pages/settings/PrivacyList.ets(10:7)", "entry");
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('用途包括：');
            Text.debugLine("entry/src/main/ets/pages/settings/PrivacyList.ets(12:7)", "entry");
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('- 提供定制化学习推荐');
            Text.debugLine("entry/src/main/ets/pages/settings/PrivacyList.ets(13:7)", "entry");
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('- 提升用户体验');
            Text.debugLine("entry/src/main/ets/pages/settings/PrivacyList.ets(14:7)", "entry");
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('- 账号安全与找回服务');
            Text.debugLine("entry/src/main/ets/pages/settings/PrivacyList.ets(15:7)", "entry");
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('我们不会出售您的信息，所有数据均加密存储。');
            Text.debugLine("entry/src/main/ets/pages/settings/PrivacyList.ets(17:7)", "entry");
        }, Text);
        Text.pop();
        Column.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
    static getEntryName(): string {
        return "PrivacyList";
    }
}
registerNamedRoute(() => new PrivacyList(undefined, {}), "", { bundleName: "com.example.myapplication", moduleName: "entry", pagePath: "pages/settings/PrivacyList", pageFullPath: "entry/src/main/ets/pages/settings/PrivacyList", integratedHsp: "false", moduleType: "followWithHap" });
