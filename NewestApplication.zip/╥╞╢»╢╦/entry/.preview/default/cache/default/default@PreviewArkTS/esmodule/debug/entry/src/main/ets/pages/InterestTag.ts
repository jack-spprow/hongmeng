if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface InterestPage_Params {
    selectedTags?: string[];
}
import router from "@ohos:router";
class InterestPage extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.__selectedTags = new ObservedPropertyObjectPU([], this, "selectedTags");
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: InterestPage_Params) {
        if (params.selectedTags !== undefined) {
            this.selectedTags = params.selectedTags;
        }
    }
    updateStateVars(params: InterestPage_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__selectedTags.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__selectedTags.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    private __selectedTags: ObservedPropertyObjectPU<string[]>;
    get selectedTags() {
        return this.__selectedTags.get();
    }
    set selectedTags(newValue: string[]) {
        this.__selectedTags.set(newValue);
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/InterestTag.ets(8:5)", "entry");
            Column.width('100%');
            Column.height('100%');
            Column.backgroundColor(Color.White);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // Header
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/InterestTag.ets(10:7)", "entry");
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('让我们更了解你');
            Text.debugLine("entry/src/main/ets/pages/InterestTag.ets(11:9)", "entry");
            Text.fontSize(20);
            Text.fontWeight(FontWeight.Bold);
            Text.padding({ top: 24, left: 16 });
            Text.width('100%');
            Text.textAlign(TextAlign.Start);
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('获取更精准的内容推荐，赢得高效的学习效果');
            Text.debugLine("entry/src/main/ets/pages/InterestTag.ets(18:9)", "entry");
            Text.fontSize(14);
            Text.fontColor('#888888');
            Text.padding({ left: 16, right: 16, top: 8, bottom: 16 });
        }, Text);
        Text.pop();
        // Header
        Column.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // Scrollable content area
            Scroll.create();
            Scroll.debugLine("entry/src/main/ets/pages/InterestTag.ets(25:7)", "entry");
            // Scrollable content area
            Scroll.layoutWeight(1);
        }, Scroll);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create({ space: 16 });
            Column.debugLine("entry/src/main/ets/pages/InterestTag.ets(26:9)", "entry");
            Column.padding({ bottom: 20 });
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            ForEach.create();
            const forEachItemGenFunction = _item => {
                const category = _item;
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Column.create();
                    Column.debugLine("entry/src/main/ets/pages/InterestTag.ets(28:13)", "entry");
                }, Column);
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Row.create();
                    Row.debugLine("entry/src/main/ets/pages/InterestTag.ets(29:15)", "entry");
                    Row.padding({ left: 16, bottom: 8 });
                    Row.width('100%');
                    Row.justifyContent(FlexAlign.Start);
                }, Row);
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Text.create('•');
                    Text.debugLine("entry/src/main/ets/pages/InterestTag.ets(30:17)", "entry");
                    Text.fontColor(Color.Blue);
                    Text.fontSize(16);
                    Text.margin({ right: 4 });
                }, Text);
                Text.pop();
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Text.create(category.title);
                    Text.debugLine("entry/src/main/ets/pages/InterestTag.ets(34:17)", "entry");
                    Text.fontSize(16);
                    Text.fontWeight(FontWeight.Medium);
                }, Text);
                Text.pop();
                Row.pop();
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Flex.create({ justifyContent: FlexAlign.Start, wrap: FlexWrap.Wrap });
                    Flex.debugLine("entry/src/main/ets/pages/InterestTag.ets(42:15)", "entry");
                    Flex.padding({ left: 16, right: 16 });
                }, Flex);
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    ForEach.create();
                    const forEachItemGenFunction = _item => {
                        const tag = _item;
                        this.observeComponentCreation2((elmtId, isInitialRender) => {
                            Button.createWithLabel(tag);
                            Button.debugLine("entry/src/main/ets/pages/InterestTag.ets(44:19)", "entry");
                            Button.margin({ right: 8, bottom: 8 });
                            Button.backgroundColor(this.selectedTags.indexOf(tag) !== -1 ? Color.Blue : '#F2F3F5');
                            Button.fontColor(this.selectedTags.indexOf(tag) !== -1 ? Color.White : Color.Black);
                            Button.padding({ left: 12, right: 12, top: 6, bottom: 6 });
                            Button.borderRadius(20);
                            Button.onClick(() => {
                                let index = this.selectedTags.indexOf(tag);
                                if (index !== -1) {
                                    this.selectedTags.splice(index, 1);
                                }
                                else {
                                    this.selectedTags.push(tag);
                                }
                            });
                        }, Button);
                        Button.pop();
                    };
                    this.forEachUpdateFunction(elmtId, category.tags, forEachItemGenFunction);
                }, ForEach);
                ForEach.pop();
                Flex.pop();
                Column.pop();
            };
            this.forEachUpdateFunction(elmtId, categoryList, forEachItemGenFunction);
        }, ForEach);
        ForEach.pop();
        Column.pop();
        // Scrollable content area
        Scroll.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // Bottom button
            Button.createWithLabel('选好了（' + this.selectedTags.length + '）');
            Button.debugLine("entry/src/main/ets/pages/InterestTag.ets(69:7)", "entry");
            // Bottom button
            Button.fontSize(16);
            // Bottom button
            Button.fontWeight(FontWeight.Bold);
            // Bottom button
            Button.backgroundColor(Color.Blue);
            // Bottom button
            Button.fontColor(Color.White);
            // Bottom button
            Button.width('90%');
            // Bottom button
            Button.height(44);
            // Bottom button
            Button.margin({ left: 20, right: 20, top: 16, bottom: 20 });
            // Bottom button
            Button.borderRadius(22);
            // Bottom button
            Button.onClick(() => { this.SelectRight(); });
        }, Button);
        // Bottom button
        Button.pop();
        Column.pop();
    }
    SelectRight() {
        router.pushUrl({ url: "pages/MainPage" });
    }
    rerender() {
        this.updateDirtyElements();
    }
    static getEntryName(): string {
        return "InterestPage";
    }
}
interface Category {
    title: string;
    tags: string[];
}
const categoryList: Category[] = [
    { title: '语言', tags: ['ArkTS', 'ArkUI', 'JavaScript', 'TypeScript'] },
    { title: '职业', tags: ['职场提升', '商业管理', '设计创作', '其他技能'] },
    { title: '认证', tags: ['软考高级', '逻辑二级', '公共安全'] },
    { title: 'HM OS', tags: ['生态介绍', '开发工具', '开发语言', '应用开发', '集成调测', '应用上架', '运营报表'] },
    { title: '大数据', tags: ['Spark', 'Oozie', 'HBase', 'Sqoop', 'Flume'] },
    { title: '华为云', tags: ['ECS', 'OBS', 'IoT'] },
    { title: '人工智能', tags: ['Python'] }
];
registerNamedRoute(() => new InterestPage(undefined, {}), "", { bundleName: "com.example.myapplication", moduleName: "entry", pagePath: "pages/InterestTag", pageFullPath: "entry/src/main/ets/pages/InterestTag", integratedHsp: "false", moduleType: "followWithHap" });
