if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface ThirdPartyShare_Params {
}
class ThirdPartyShare extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: ThirdPartyShare_Params) {
    }
    updateStateVars(params: ThirdPartyShare_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
    }
    aboutToBeDeleted() {
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create({ space: 15 });
            Column.debugLine("entry/src/main/ets/pages/settings/ThirdPartyShare.ets(6:5)", "entry");
            Column.padding(20);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('我们可能与以下第三方合作：');
            Text.debugLine("entry/src/main/ets/pages/settings/ThirdPartyShare.ets(7:7)", "entry");
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('1. 云存储服务商（如华为云）：用于备份用户数据');
            Text.debugLine("entry/src/main/ets/pages/settings/ThirdPartyShare.ets(9:7)", "entry");
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('2. 支付平台（如微信支付）：用于购买课程');
            Text.debugLine("entry/src/main/ets/pages/settings/ThirdPartyShare.ets(10:7)", "entry");
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('3. 数据分析平台（如友盟）：用于行为分析');
            Text.debugLine("entry/src/main/ets/pages/settings/ThirdPartyShare.ets(11:7)", "entry");
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('您可以联系这些服务商以查看或删除数据。');
            Text.debugLine("entry/src/main/ets/pages/settings/ThirdPartyShare.ets(13:7)", "entry");
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Button.createWithLabel('查看合作方详情');
            Button.debugLine("entry/src/main/ets/pages/settings/ThirdPartyShare.ets(14:7)", "entry");
            Button.onClick(() => {
                console.log('展示详细合作清单');
            });
        }, Button);
        Button.pop();
        Column.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
    static getEntryName(): string {
        return "ThirdPartyShare";
    }
}
registerNamedRoute(() => new ThirdPartyShare(undefined, {}), "", { bundleName: "com.example.myapplication", moduleName: "entry", pagePath: "pages/settings/ThirdPartyShare", pageFullPath: "entry/src/main/ets/pages/settings/ThirdPartyShare", integratedHsp: "false", moduleType: "followWithHap" });
