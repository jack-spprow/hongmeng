import router from "@ohos:router";
// common/router/Router.ts
export class Router {
    static push(url: string) {
        router.pushUrl({ url });
    }
    static replace(url: string) {
        router.replaceUrl({ url });
    }
    static back() {
        router.back();
    }
}
