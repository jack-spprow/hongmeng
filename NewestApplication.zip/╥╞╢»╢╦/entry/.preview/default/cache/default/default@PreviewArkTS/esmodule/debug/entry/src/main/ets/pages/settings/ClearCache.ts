if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface ClearCache_Params {
    courseCache?: boolean;
    imageCache?: boolean;
    otherCache?: boolean;
}
class ClearCache extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.__courseCache = new ObservedPropertySimplePU(true, this, "courseCache");
        this.__imageCache = new ObservedPropertySimplePU(true, this, "imageCache");
        this.__otherCache = new ObservedPropertySimplePU(false, this, "otherCache");
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: ClearCache_Params) {
        if (params.courseCache !== undefined) {
            this.courseCache = params.courseCache;
        }
        if (params.imageCache !== undefined) {
            this.imageCache = params.imageCache;
        }
        if (params.otherCache !== undefined) {
            this.otherCache = params.otherCache;
        }
    }
    updateStateVars(params: ClearCache_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__courseCache.purgeDependencyOnElmtId(rmElmtId);
        this.__imageCache.purgeDependencyOnElmtId(rmElmtId);
        this.__otherCache.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__courseCache.aboutToBeDeleted();
        this.__imageCache.aboutToBeDeleted();
        this.__otherCache.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    private __courseCache: ObservedPropertySimplePU<boolean>;
    get courseCache() {
        return this.__courseCache.get();
    }
    set courseCache(newValue: boolean) {
        this.__courseCache.set(newValue);
    }
    private __imageCache: ObservedPropertySimplePU<boolean>;
    get imageCache() {
        return this.__imageCache.get();
    }
    set imageCache(newValue: boolean) {
        this.__imageCache.set(newValue);
    }
    private __otherCache: ObservedPropertySimplePU<boolean>;
    get otherCache() {
        return this.__otherCache.get();
    }
    set otherCache(newValue: boolean) {
        this.__otherCache.set(newValue);
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create({ space: 20 });
            Column.debugLine("entry/src/main/ets/pages/settings/ClearCache.ets(10:5)", "entry");
            Column.padding(20);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('请选择要清除的缓存类型：');
            Text.debugLine("entry/src/main/ets/pages/settings/ClearCache.ets(11:7)", "entry");
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/settings/ClearCache.ets(13:7)", "entry");
            Row.justifyContent(FlexAlign.SpaceBetween);
            Row.alignItems(VerticalAlign.Center);
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('课程缓存');
            Text.debugLine("entry/src/main/ets/pages/settings/ClearCache.ets(14:9)", "entry");
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Toggle.create({ type: ToggleType.Switch, isOn: this.courseCache });
            Toggle.debugLine("entry/src/main/ets/pages/settings/ClearCache.ets(15:9)", "entry");
            Toggle.onChange(value => this.courseCache = value);
        }, Toggle);
        Toggle.pop();
        Row.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/settings/ClearCache.ets(21:7)", "entry");
            Row.justifyContent(FlexAlign.SpaceBetween);
            Row.alignItems(VerticalAlign.Center);
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('图片缓存');
            Text.debugLine("entry/src/main/ets/pages/settings/ClearCache.ets(22:9)", "entry");
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Toggle.create({ type: ToggleType.Switch, isOn: this.imageCache });
            Toggle.debugLine("entry/src/main/ets/pages/settings/ClearCache.ets(23:9)", "entry");
            Toggle.onChange(value => this.imageCache = value);
        }, Toggle);
        Toggle.pop();
        Row.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/settings/ClearCache.ets(29:7)", "entry");
            Row.justifyContent(FlexAlign.SpaceBetween);
            Row.alignItems(VerticalAlign.Center);
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('其他缓存');
            Text.debugLine("entry/src/main/ets/pages/settings/ClearCache.ets(30:9)", "entry");
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Toggle.create({ type: ToggleType.Switch, isOn: this.otherCache });
            Toggle.debugLine("entry/src/main/ets/pages/settings/ClearCache.ets(31:9)", "entry");
            Toggle.onChange(value => this.otherCache = value);
        }, Toggle);
        Toggle.pop();
        Row.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Button.createWithLabel('清除缓存');
            Button.debugLine("entry/src/main/ets/pages/settings/ClearCache.ets(37:7)", "entry");
            Button.type(ButtonType.Normal);
            Button.onClick(() => {
                console.log(`清除缓存：课程=${this.courseCache}, 图片=${this.imageCache}, 其他=${this.otherCache}`);
            });
        }, Button);
        Button.pop();
        Column.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
    static getEntryName(): string {
        return "ClearCache";
    }
}
registerNamedRoute(() => new ClearCache(undefined, {}), "", { bundleName: "com.example.myapplication", moduleName: "entry", pagePath: "pages/settings/ClearCache", pageFullPath: "entry/src/main/ets/pages/settings/ClearCache", integratedHsp: "false", moduleType: "followWithHap" });
