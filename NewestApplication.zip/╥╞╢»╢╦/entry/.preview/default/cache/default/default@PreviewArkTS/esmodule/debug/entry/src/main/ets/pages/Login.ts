if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface Login_Params {
    //控制跳转的对象
    pathStack?: NavPathStack;
    loginIdentifier?: string;
    password?: string;
    username?: string;
}
import type { User } from "../model/Model";
import router from "@ohos:router";
import http from "@ohos:net.http";
import type { BusinessError as BusinessError } from "@ohos:base";
export function LoginBuilder(parent = null) {
    {
        (parent ? parent : this).observeComponentCreation2((elmtId, isInitialRender) => {
            if (isInitialRender) {
                let componentCall = new Login(parent ? parent : this, {}, undefined, elmtId, () => { }, { page: "entry/src/main/ets/pages/Login.ets", line: 9, col: 3 });
                ViewPU.create(componentCall);
                let paramsLambda = () => {
                    return {};
                };
                componentCall.paramsGenerator_ = paramsLambda;
            }
            else {
                (parent ? parent : this).updateStateVarsOfChildByElmtId(elmtId, {});
            }
        }, { name: "Login" });
    }
}
class Login extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.pathStack = new NavPathStack();
        this.__loginIdentifier = new ObservedPropertySimplePU('', this, "loginIdentifier");
        this.__password = new ObservedPropertySimplePU('', this, "password");
        this.__username = new ObservedPropertySimplePU('', this, "username");
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: Login_Params) {
        if (params.pathStack !== undefined) {
            this.pathStack = params.pathStack;
        }
        if (params.loginIdentifier !== undefined) {
            this.loginIdentifier = params.loginIdentifier;
        }
        if (params.password !== undefined) {
            this.password = params.password;
        }
        if (params.username !== undefined) {
            this.username = params.username;
        }
    }
    updateStateVars(params: Login_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__loginIdentifier.purgeDependencyOnElmtId(rmElmtId);
        this.__password.purgeDependencyOnElmtId(rmElmtId);
        this.__username.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__loginIdentifier.aboutToBeDeleted();
        this.__password.aboutToBeDeleted();
        this.__username.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    //控制跳转的对象
    private pathStack: NavPathStack;
    private __loginIdentifier: ObservedPropertySimplePU<string>;
    get loginIdentifier() {
        return this.__loginIdentifier.get();
    }
    set loginIdentifier(newValue: string) {
        this.__loginIdentifier.set(newValue);
    }
    private __password: ObservedPropertySimplePU<string>;
    get password() {
        return this.__password.get();
    }
    set password(newValue: string) {
        this.__password.set(newValue);
    }
    private __username: ObservedPropertySimplePU<string>;
    get username() {
        return this.__username.get();
    }
    set username(newValue: string) {
        this.__username.set(newValue);
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            NavDestination.create(() => {
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Column.create({ space: 5 });
                    Column.debugLine("entry/src/main/ets/pages/Login.ets(23:7)", "entry");
                    Column.width('100%');
                    Column.height('100%');
                    Column.backgroundColor('#fff');
                    Column.expandSafeArea([SafeAreaType.SYSTEM], [SafeAreaEdge.TOP, SafeAreaEdge.BOTTOM]);
                }, Column);
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    // 顶部Logo
                    Row.create();
                    Row.debugLine("entry/src/main/ets/pages/Login.ets(25:9)", "entry");
                    // 顶部Logo
                    Row.width('100%');
                    // 顶部Logo
                    Row.justifyContent(FlexAlign.Start);
                    // 顶部Logo
                    Row.margin({ top: 5, left: 10 });
                    // 顶部Logo
                    Row.expandSafeArea([SafeAreaType.SYSTEM], [SafeAreaEdge.TOP, SafeAreaEdge.BOTTOM]);
                }, Row);
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    // Logo图片占位
                    Image.create({ "id": 0, "type": 30000, params: ['image/logo.png'], "bundleName": "com.example.myapplication", "moduleName": "entry" });
                    Image.debugLine("entry/src/main/ets/pages/Login.ets(27:11)", "entry");
                    // Logo图片占位
                    Image.height(50);
                }, Image);
                // 顶部Logo
                Row.pop();
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    // 标题
                    Text.create('通鸿云课堂');
                    Text.debugLine("entry/src/main/ets/pages/Login.ets(35:9)", "entry");
                    // 标题
                    Text.fontSize(28);
                    // 标题
                    Text.fontWeight(FontWeight.Bold);
                    // 标题
                    Text.fontColor('#F48B8B');
                    // 标题
                    Text.margin({ top: 32, bottom: 32 });
                    // 标题
                    Text.width('100%');
                    // 标题
                    Text.textAlign(TextAlign.Center);
                }, Text);
                // 标题
                Text.pop();
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    // 用户名输入框
                    TextInput.create({
                        placeholder: '请输入用户名或邮箱',
                        text: { value: this.loginIdentifier, changeEvent: newValue => { this.loginIdentifier = newValue; } }
                    });
                    TextInput.debugLine("entry/src/main/ets/pages/Login.ets(44:9)", "entry");
                    // 用户名输入框
                    TextInput.type(InputType.Normal);
                    // 用户名输入框
                    TextInput.width('80%');
                    // 用户名输入框
                    TextInput.height(48);
                    // 用户名输入框
                    TextInput.margin({ bottom: 16 });
                    // 用户名输入框
                    TextInput.backgroundColor('#F5F5F5');
                    // 用户名输入框
                    TextInput.borderRadius(8);
                    // 用户名输入框
                    TextInput.padding({ left: 16 });
                }, TextInput);
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    // 密码输入框
                    Row.create();
                    Row.debugLine("entry/src/main/ets/pages/Login.ets(57:9)", "entry");
                    // 密码输入框
                    Row.width('80%');
                    // 密码输入框
                    Row.margin({ bottom: 24 });
                }, Row);
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    TextInput.create({
                        placeholder: '请输入密码',
                        text: { value: this.password, changeEvent: newValue => { this.password = newValue; } }
                    });
                    TextInput.debugLine("entry/src/main/ets/pages/Login.ets(58:11)", "entry");
                    TextInput.type(InputType.Password);
                    TextInput.width('100%');
                    TextInput.height(48);
                    TextInput.backgroundColor('#F5F5F5');
                    TextInput.borderRadius(8);
                    TextInput.padding({ left: 16 });
                    TextInput.passwordIcon({
                        onIconSrc: { "id": 0, "type": 30000, params: ['icons/lock_open.svg'], "bundleName": "com.example.myapplication", "moduleName": "entry" },
                        offIconSrc: { "id": 0, "type": 30000, params: ['icons/lock.svg'], "bundleName": "com.example.myapplication", "moduleName": "entry" }
                    });
                }, TextInput);
                // 密码输入框
                Row.pop();
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    // 登录按钮
                    Button.createWithLabel('Sign In');
                    Button.debugLine("entry/src/main/ets/pages/Login.ets(75:9)", "entry");
                    // 登录按钮
                    Button.width('80%');
                    // 登录按钮
                    Button.height(48);
                    // 登录按钮
                    Button.fontSize(18);
                    // 登录按钮
                    Button.fontColor('#fff');
                    // 登录按钮
                    Button.backgroundColor('#F48B8B');
                    // 登录按钮
                    Button.borderRadius(8);
                    // 登录按钮
                    Button.margin({ bottom: 16 });
                    // 登录按钮
                    Button.onClick(() => {
                        this.login();
                    });
                }, Button);
                // 登录按钮
                Button.pop();
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    // 辅助文本链接
                    Row.create();
                    Row.debugLine("entry/src/main/ets/pages/Login.ets(88:9)", "entry");
                    // 辅助文本链接
                    Row.width('80%');
                    // 辅助文本链接
                    Row.justifyContent(FlexAlign.SpaceBetween);
                    // 辅助文本链接
                    Row.margin({ bottom: 32 });
                }, Row);
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Text.create('忘记密码');
                    Text.debugLine("entry/src/main/ets/pages/Login.ets(89:11)", "entry");
                    Text.fontSize(14);
                    Text.fontColor('#1976D2');
                    Text.onClick(() => {
                        this.update();
                    });
                }, Text);
                Text.pop();
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Text.create('快速注册');
                    Text.debugLine("entry/src/main/ets/pages/Login.ets(94:11)", "entry");
                    Text.fontSize(14);
                    Text.fontColor('#1976D2');
                    Text.onClick(() => {
                        this.insert();
                    });
                }, Text);
                Text.pop();
                // 辅助文本链接
                Row.pop();
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    // 第三方登录分割线
                    Row.create();
                    Row.debugLine("entry/src/main/ets/pages/Login.ets(105:9)", "entry");
                    // 第三方登录分割线
                    Row.width('80%');
                    // 第三方登录分割线
                    Row.margin({ bottom: 24 });
                    // 第三方登录分割线
                    Row.justifyContent(FlexAlign.Center);
                }, Row);
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Divider.create();
                    Divider.debugLine("entry/src/main/ets/pages/Login.ets(106:11)", "entry");
                    Divider.width('30%');
                }, Divider);
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Text.create('第三方登录');
                    Text.debugLine("entry/src/main/ets/pages/Login.ets(107:11)", "entry");
                    Text.fontSize(14);
                    Text.fontColor('#888');
                    Text.margin({ left: 8, right: 8 });
                }, Text);
                Text.pop();
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Divider.create();
                    Divider.debugLine("entry/src/main/ets/pages/Login.ets(108:11)", "entry");
                    Divider.width('30%');
                }, Divider);
                // 第三方登录分割线
                Row.pop();
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    // 第三方登录icon
                    Row.create({ space: 5 });
                    Row.debugLine("entry/src/main/ets/pages/Login.ets(115:9)", "entry");
                    // 第三方登录icon
                    Row.width('80%');
                    // 第三方登录icon
                    Row.justifyContent(FlexAlign.Center);
                }, Row);
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    // 微信icon占位
                    Image.create({ "id": 0, "type": 30000, params: ['image/weixinlogo.png'], "bundleName": "com.example.myapplication", "moduleName": "entry" });
                    Image.debugLine("entry/src/main/ets/pages/Login.ets(117:11)", "entry");
                    // 微信icon占位
                    Image.width(50);
                }, Image);
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    // QQ icon占位
                    Image.create({ "id": 0, "type": 30000, params: ['image/qqlogo.png'], "bundleName": "com.example.myapplication", "moduleName": "entry" });
                    Image.debugLine("entry/src/main/ets/pages/Login.ets(119:11)", "entry");
                    // QQ icon占位
                    Image.width(50);
                }, Image);
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    // 钉钉icon占位
                    Image.create({ "id": 0, "type": 30000, params: ['image/dingdinglogo.png'], "bundleName": "com.example.myapplication", "moduleName": "entry" });
                    Image.debugLine("entry/src/main/ets/pages/Login.ets(121:11)", "entry");
                    // 钉钉icon占位
                    Image.width(50);
                }, Image);
                // 第三方登录icon
                Row.pop();
                Column.pop();
            }, { moduleName: "entry", pagePath: "entry/src/main/ets/pages/Login" });
            NavDestination.onReady((context: NavDestinationContext) => {
                this.pathStack = context.pathStack;
            });
            NavDestination.debugLine("entry/src/main/ets/pages/Login.ets(22:5)", "entry");
        }, NavDestination);
        NavDestination.pop();
    }
    login() {
        let user: User = {
            username: this.loginIdentifier,
            password: this.password
        };
        console.log('账号:' + this.username, '密码:' + this.password);
        let url: string = 'http://localhost:8080/api/MyLogin';
        // 每一个httpRequest对应一个HTTP请求任务，不可复用。
        let httpRequest1 = http.createHttp();
        let options: http.HttpRequestOptions = {
            method: http.RequestMethod.POST,
            extraData: user,
            expectDataType: http.HttpDataType.OBJECT,
            header: { 'Accept': 'application/json', 'content-type': 'application/json' },
        };
        httpRequest1.request(url, options, (err: BusinessError, data: http.HttpResponse) => {
            if (!err) {
                console.log('user:', JSON.stringify(data.result));
                if (data.result["code"] === 500) {
                    AlertDialog.show({
                        message: data.result["message"],
                        autoCancel: true,
                        alignment: DialogAlignment.Bottom,
                        offset: { dx: 0, dy: -20 },
                        gridCount: 3
                    });
                    return;
                }
                router.pushUrl({
                    url: 'pages/InterestTag'
                });
            }
            else {
                console.info('error:' + JSON.stringify(err));
                httpRequest1.destroy();
            }
        });
    }
    insert() {
        let user: User = {
            username: this.loginIdentifier,
            password: this.password
        };
        console.log('账号:' + this.username, '密码:' + this.password);
        let url: string = 'http://localhost:8080/api/insertUser';
        // 每一个httpRequest对应一个HTTP请求任务，不可复用。
        let httpRequest1 = http.createHttp();
        let options: http.HttpRequestOptions = {
            method: http.RequestMethod.POST,
            extraData: user,
            expectDataType: http.HttpDataType.OBJECT,
            header: { 'Accept': 'application/json', 'content-type': 'application/json' },
        };
        httpRequest1.request(url, options, (err: BusinessError, data: http.HttpResponse) => {
            if (!err) {
                console.log('result:', JSON.stringify(data.result));
            }
            else {
                console.info('error:' + JSON.stringify(err));
                httpRequest1.destroy();
            }
        });
    }
    update() {
        let user: User = {
            username: this.loginIdentifier,
            password: this.password
        };
        console.log('账号:' + this.username, '密码:' + this.password);
        let url: string = 'http://localhost:8080/api/updateUser';
        // 每一个httpRequest对应一个HTTP请求任务，不可复用。
        let httpRequest1 = http.createHttp();
        let options: http.HttpRequestOptions = {
            method: http.RequestMethod.POST,
            extraData: user,
            expectDataType: http.HttpDataType.OBJECT,
            header: { 'Accept': 'application/json', 'content-type': 'application/json' },
        };
        httpRequest1.request(url, options, (err: BusinessError, data: http.HttpResponse) => {
            if (!err) {
                console.log('result:', JSON.stringify(data.result));
            }
            else {
                console.info('error:' + JSON.stringify(err));
                httpRequest1.destroy();
            }
        });
    }
    deleteUser() {
        let url: string = `http://localhost:8080/api/deleteUser/${this.loginIdentifier}`;
        http.createHttp().request(url, { method: http.RequestMethod.DELETE }, (err, data) => {
            if (!err) {
                console.log('删除结果:', data.result);
            }
            else {
                console.error('删除失败:', err);
            }
        });
    }
    rerender() {
        this.updateDirtyElements();
    }
    static getEntryName(): string {
        return "Login";
    }
}
registerNamedRoute(() => new Login(undefined, {}), "", { bundleName: "com.example.myapplication", moduleName: "entry", pagePath: "pages/Login", pageFullPath: "entry/src/main/ets/pages/Login", integratedHsp: "false", moduleType: "followWithHap" });
