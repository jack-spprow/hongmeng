if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface MainPage_Params {
    currentIndex?: number;
}
import Index1 from "@normalized:N&&&entry/src/main/ets/pages/FirstPage&";
import index3 from "@normalized:N&&&entry/src/main/ets/pages/Study&";
import index4 from "@normalized:N&&&entry/src/main/ets/pages/My&";
import Equipment from "@normalized:N&&&entry/src/main/ets/pages/SearchClass&";
class MainPage extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.__currentIndex = new ObservedPropertySimplePU(0, this, "currentIndex");
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: MainPage_Params) {
        if (params.currentIndex !== undefined) {
            this.currentIndex = params.currentIndex;
        }
    }
    updateStateVars(params: MainPage_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__currentIndex.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__currentIndex.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    private __currentIndex: ObservedPropertySimplePU<number>;
    get currentIndex() {
        return this.__currentIndex.get();
    }
    set currentIndex(newValue: number) {
        this.__currentIndex.set(newValue);
    }
    barBuilder(index: number, label: string, parent = null) {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/MainPage.ets(12:5)", "entry");
            Column.width('100%');
            Column.height('100%');
            Column.justifyContent(FlexAlign.SpaceAround);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            //Image(this.currentIndex == index ? $rawfile('icon/tabs1_fill.svg') : $rawfile('icon/tabs1.svg')).width(28)
            Text.create(label);
            Text.debugLine("entry/src/main/ets/pages/MainPage.ets(14:7)", "entry");
            //Image(this.currentIndex == index ? $rawfile('icon/tabs1_fill.svg') : $rawfile('icon/tabs1.svg')).width(28)
            Text.fontSize(12);
            //Image(this.currentIndex == index ? $rawfile('icon/tabs1_fill.svg') : $rawfile('icon/tabs1.svg')).width(28)
            Text.fontColor(this.currentIndex == index ? '#ff117ed4' : Color.Black);
        }, Text);
        //Image(this.currentIndex == index ? $rawfile('icon/tabs1_fill.svg') : $rawfile('icon/tabs1.svg')).width(28)
        Text.pop();
        Column.pop();
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Tabs.create({ barPosition: BarPosition.End, index: this.currentIndex });
            Tabs.debugLine("entry/src/main/ets/pages/MainPage.ets(22:5)", "entry");
            Tabs.vertical(false);
            Tabs.width('100%');
            Tabs.height('100%');
            Tabs.scrollable(false);
            Tabs.animationDuration(0);
            Tabs.barBackgroundColor(Color.White);
            Tabs.onChange((index: number) => {
                this.currentIndex = index;
            });
        }, Tabs);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            TabContent.create(() => {
                {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        if (isInitialRender) {
                            let componentCall = new Index1(this, {}, undefined, elmtId, () => { }, { page: "entry/src/main/ets/pages/MainPage.ets", line: 25, col: 9 });
                            ViewPU.create(componentCall);
                            let paramsLambda = () => {
                                return {};
                            };
                            componentCall.paramsGenerator_ = paramsLambda;
                        }
                        else {
                            this.updateStateVarsOfChildByElmtId(elmtId, {});
                        }
                    }, { name: "Index1" });
                }
            });
            TabContent.tabBar({ builder: () => {
                    this.barBuilder.call(this, 0, '首页');
                } });
            TabContent.debugLine("entry/src/main/ets/pages/MainPage.ets(24:7)", "entry");
        }, TabContent);
        TabContent.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            TabContent.create(() => {
                {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        if (isInitialRender) {
                            let componentCall = new Equipment(this, {}, undefined, elmtId, () => { }, { page: "entry/src/main/ets/pages/MainPage.ets", line: 28, col: 9 });
                            ViewPU.create(componentCall);
                            let paramsLambda = () => {
                                return {};
                            };
                            componentCall.paramsGenerator_ = paramsLambda;
                        }
                        else {
                            this.updateStateVarsOfChildByElmtId(elmtId, {});
                        }
                    }, { name: "Equipment" });
                }
            });
            TabContent.tabBar({ builder: () => {
                    this.barBuilder.call(this, 1, '找课');
                } });
            TabContent.debugLine("entry/src/main/ets/pages/MainPage.ets(27:7)", "entry");
        }, TabContent);
        TabContent.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            TabContent.create(() => {
                {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        if (isInitialRender) {
                            let componentCall = new index3(this, {}, undefined, elmtId, () => { }, { page: "entry/src/main/ets/pages/MainPage.ets", line: 31, col: 9 });
                            ViewPU.create(componentCall);
                            let paramsLambda = () => {
                                return {};
                            };
                            componentCall.paramsGenerator_ = paramsLambda;
                        }
                        else {
                            this.updateStateVarsOfChildByElmtId(elmtId, {});
                        }
                    }, { name: "index3" });
                }
            });
            TabContent.tabBar({ builder: () => {
                    this.barBuilder.call(this, 2, '学习');
                } });
            TabContent.debugLine("entry/src/main/ets/pages/MainPage.ets(30:7)", "entry");
        }, TabContent);
        TabContent.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            TabContent.create(() => {
                {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        if (isInitialRender) {
                            let componentCall = new index4(this, {}, undefined, elmtId, () => { }, { page: "entry/src/main/ets/pages/MainPage.ets", line: 34, col: 9 });
                            ViewPU.create(componentCall);
                            let paramsLambda = () => {
                                return {};
                            };
                            componentCall.paramsGenerator_ = paramsLambda;
                        }
                        else {
                            this.updateStateVarsOfChildByElmtId(elmtId, {});
                        }
                    }, { name: "index4" });
                }
            });
            TabContent.tabBar({ builder: () => {
                    this.barBuilder.call(this, 3, '我的');
                } });
            TabContent.debugLine("entry/src/main/ets/pages/MainPage.ets(33:7)", "entry");
        }, TabContent);
        TabContent.pop();
        Tabs.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
    static getEntryName(): string {
        return "MainPage";
    }
}
registerNamedRoute(() => new MainPage(undefined, {}), "", { bundleName: "com.example.myapplication", moduleName: "entry", pagePath: "pages/MainPage", pageFullPath: "entry/src/main/ets/pages/MainPage", integratedHsp: "false", moduleType: "followWithHap" });
