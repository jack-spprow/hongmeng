if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface EyeCareMode_Params {
    isEyeCareOn?: boolean;
    eyeBrightness?: number;
    eyeColorTemp?: number;
}
class EyeCareMode extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.__isEyeCareOn = new ObservedPropertySimplePU(false, this, "isEyeCareOn");
        this.__eyeBrightness = new ObservedPropertySimplePU(50, this, "eyeBrightness");
        this.__eyeColorTemp = new ObservedPropertySimplePU(50, this, "eyeColorTemp");
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: EyeCareMode_Params) {
        if (params.isEyeCareOn !== undefined) {
            this.isEyeCareOn = params.isEyeCareOn;
        }
        if (params.eyeBrightness !== undefined) {
            this.eyeBrightness = params.eyeBrightness;
        }
        if (params.eyeColorTemp !== undefined) {
            this.eyeColorTemp = params.eyeColorTemp;
        }
    }
    updateStateVars(params: EyeCareMode_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__isEyeCareOn.purgeDependencyOnElmtId(rmElmtId);
        this.__eyeBrightness.purgeDependencyOnElmtId(rmElmtId);
        this.__eyeColorTemp.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__isEyeCareOn.aboutToBeDeleted();
        this.__eyeBrightness.aboutToBeDeleted();
        this.__eyeColorTemp.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    private __isEyeCareOn: ObservedPropertySimplePU<boolean>;
    get isEyeCareOn() {
        return this.__isEyeCareOn.get();
    }
    set isEyeCareOn(newValue: boolean) {
        this.__isEyeCareOn.set(newValue);
    }
    private __eyeBrightness: ObservedPropertySimplePU<number>;
    get eyeBrightness() {
        return this.__eyeBrightness.get();
    }
    set eyeBrightness(newValue: number) {
        this.__eyeBrightness.set(newValue);
    }
    private __eyeColorTemp: ObservedPropertySimplePU<number>;
    get eyeColorTemp() {
        return this.__eyeColorTemp.get();
    }
    set eyeColorTemp(newValue: number) {
        this.__eyeColorTemp.set(newValue);
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create({ space: 20 });
            Column.debugLine("entry/src/main/ets/pages/settings/EyeCareMode.ets(10:5)", "entry");
            Column.padding(20);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/settings/EyeCareMode.ets(11:7)", "entry");
            Row.justifyContent(FlexAlign.SpaceBetween);
            Row.alignItems(VerticalAlign.Center);
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('开启护眼模式');
            Text.debugLine("entry/src/main/ets/pages/settings/EyeCareMode.ets(12:9)", "entry");
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Toggle.create({ type: ToggleType.Switch, isOn: this.isEyeCareOn });
            Toggle.debugLine("entry/src/main/ets/pages/settings/EyeCareMode.ets(13:9)", "entry");
            Toggle.onChange(v => {
                this.isEyeCareOn = v;
                console.log('护眼模式:', v);
            });
        }, Toggle);
        Toggle.pop();
        Row.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            If.create();
            // ✅ 直接使用 if 判断语法，而不是 If()
            if (this.isEyeCareOn) {
                this.ifElseBranchUpdateFunction(0, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Column.create({ space: 12 });
                        Column.debugLine("entry/src/main/ets/pages/settings/EyeCareMode.ets(24:9)", "entry");
                    }, Column);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create('亮度调节: ' + this.eyeBrightness + '%');
                        Text.debugLine("entry/src/main/ets/pages/settings/EyeCareMode.ets(25:11)", "entry");
                    }, Text);
                    Text.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Slider.create({ value: this.eyeBrightness, min: 0, max: 100 });
                        Slider.debugLine("entry/src/main/ets/pages/settings/EyeCareMode.ets(26:11)", "entry");
                        Slider.onChange(v => this.eyeBrightness = v);
                    }, Slider);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create('色温调节: ' + this.eyeColorTemp + '%');
                        Text.debugLine("entry/src/main/ets/pages/settings/EyeCareMode.ets(29:11)", "entry");
                    }, Text);
                    Text.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Slider.create({ value: this.eyeColorTemp, min: 0, max: 100 });
                        Slider.debugLine("entry/src/main/ets/pages/settings/EyeCareMode.ets(30:11)", "entry");
                        Slider.onChange(v => this.eyeColorTemp = v);
                    }, Slider);
                    Column.pop();
                });
            }
            else {
                this.ifElseBranchUpdateFunction(1, () => {
                });
            }
        }, If);
        If.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Button.createWithLabel('应用设置');
            Button.debugLine("entry/src/main/ets/pages/settings/EyeCareMode.ets(35:7)", "entry");
            Button.type(ButtonType.Normal);
            Button.onClick(() => {
                console.log(`亮度: ${this.eyeBrightness}, 色温: ${this.eyeColorTemp}`);
            });
        }, Button);
        Button.pop();
        Column.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
    static getEntryName(): string {
        return "EyeCareMode";
    }
}
registerNamedRoute(() => new EyeCareMode(undefined, {}), "", { bundleName: "com.example.myapplication", moduleName: "entry", pagePath: "pages/settings/EyeCareMode", pageFullPath: "entry/src/main/ets/pages/settings/EyeCareMode", integratedHsp: "false", moduleType: "followWithHap" });
