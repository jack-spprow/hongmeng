if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface index3_Params {
    currentTab?: number;
}
import promptAction from "@ohos:promptAction";
import { OperationType as OperationType } from "@ohos:arkui.advanced.SubHeader";
import { SubHeader as SubHeader } from "@ohos:arkui.advanced.SubHeader";
import router from "@ohos:router";
export default class index3 extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.__currentTab = new ObservedPropertySimplePU(0 // 0-近期学习 1-我的购买
        , this, "currentTab");
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: index3_Params) {
        if (params.currentTab !== undefined) {
            this.currentTab = params.currentTab;
        }
    }
    updateStateVars(params: index3_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__currentTab.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__currentTab.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    private __currentTab: ObservedPropertySimplePU<number>; // 0-近期学习 1-我的购买
    get currentTab() {
        return this.__currentTab.get();
    }
    set currentTab(newValue: number) {
        this.__currentTab.set(newValue);
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Scroll.create();
            Scroll.debugLine("entry/src/main/ets/pages/Study.ets(11:5)", "entry");
            Scroll.width('100%');
        }, Scroll);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/Study.ets(13:7)", "entry");
            Column.width('100%');
        }, Column);
        {
            this.observeComponentCreation2((elmtId, isInitialRender) => {
                if (isInitialRender) {
                    let componentCall = new SubHeader(this, {
                        primaryTitle: '学习,成为更好的自己',
                        operationType: OperationType.TEXT_ARROW,
                        operationItem: [{
                                value: '班级群',
                                action: () => {
                                    promptAction.showToast({ message: 'demo' });
                                }
                            }]
                    }, undefined, elmtId, () => { }, { page: "entry/src/main/ets/pages/Study.ets", line: 15, col: 9 });
                    ViewPU.create(componentCall);
                    let paramsLambda = () => {
                        return {
                            primaryTitle: '学习,成为更好的自己',
                            operationType: OperationType.TEXT_ARROW,
                            operationItem: [{
                                    value: '班级群',
                                    action: () => {
                                        promptAction.showToast({ message: 'demo' });
                                    }
                                }]
                        };
                    };
                    componentCall.paramsGenerator_ = paramsLambda;
                }
                else {
                    this.updateStateVarsOfChildByElmtId(elmtId, {
                        primaryTitle: '学习,成为更好的自己',
                        operationType: OperationType.TEXT_ARROW
                    });
                }
            }, { name: "SubHeader" });
        }
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('上次学习');
            Text.debugLine("entry/src/main/ets/pages/Study.ets(25:9)", "entry");
            Text.fontSize(20);
            Text.width('92%');
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/Study.ets(26:7)", "entry");
            Column.width('100%');
            Column.shadow({
                offsetX: 2,
                offsetY: 4,
                color: Color.Gray,
                radius: 15
            });
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Image.create({ "id": 0, "type": 30000, params: ['image/edu11.png'], "bundleName": "com.example.myapplication", "moduleName": "entry" });
            Image.debugLine("entry/src/main/ets/pages/Study.ets(28:9)", "entry");
        }, Image);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create({ space: 5 });
            Column.debugLine("entry/src/main/ets/pages/Study.ets(29:9)", "entry");
            Column.width('100%');
            Column.shadow({
                offsetX: 2,
                offsetY: 4,
                color: Color.White,
                radius: 25
            });
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('HarmonyOs应用开发');
            Text.debugLine("entry/src/main/ets/pages/Study.ets(31:11)", "entry");
            Text.fontSize(18);
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/Study.ets(32:11)", "entry");
            Row.width('80%');
            Row.alignItems(VerticalAlign.Center);
            Row.justifyContent(FlexAlign.SpaceBetween);
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('华为开发者联盟');
            Text.debugLine("entry/src/main/ets/pages/Study.ets(34:13)", "entry");
            Text.fontSize(10);
            Text.fontColor(0xCCCCCC);
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('共32节');
            Text.debugLine("entry/src/main/ets/pages/Study.ets(35:13)", "entry");
            Text.fontSize(10);
            Text.fontColor(0xCCCCCC);
        }, Text);
        Text.pop();
        Row.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Button.createWithLabel('继续学习', { buttonStyle: ButtonStyleMode.EMPHASIZED });
            Button.debugLine("entry/src/main/ets/pages/Study.ets(40:11)", "entry");
            Button.width('60%');
        }, Button);
        Button.pop();
        Column.pop();
        Column.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 标签栏
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/Study.ets(61:9)", "entry");
            // 标签栏
            Row.width('100%');
            // 标签栏
            Row.borderRadius(8);
            // 标签栏
            Row.margin({ bottom: 20 });
            // 标签栏
            Row.justifyContent(FlexAlign.SpaceBetween);
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('我的课程');
            Text.debugLine("entry/src/main/ets/pages/Study.ets(62:11)", "entry");
            Text.fontSize(10);
            Text.fontWeight(FontWeight.Bold);
            Text.margin({ top: 20, bottom: 20 });
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            //.textAlign(TextAlign.Center)
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/Study.ets(67:11)", "entry");
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Button.createWithLabel('近期学习');
            Button.debugLine("entry/src/main/ets/pages/Study.ets(69:13)", "entry");
            Button.width('25%');
            Button.height(40);
            Button.fontColor(this.currentTab === 0 ? Color.White : Color.Black);
            Button.backgroundColor(this.currentTab === 0 ? '#007DFF' : '#F5F5F5');
            Button.onClick(() => {
                this.currentTab = 0;
            });
        }, Button);
        Button.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Button.createWithLabel('我的购买');
            Button.debugLine("entry/src/main/ets/pages/Study.ets(78:13)", "entry");
            Button.width('25%');
            Button.height(40);
            Button.fontColor(this.currentTab === 1 ? Color.White : Color.Black);
            Button.backgroundColor(this.currentTab === 1 ? '#007DFF' : '#F5F5F5');
            Button.onClick(() => {
                this.currentTab = 1;
            });
        }, Button);
        Button.pop();
        //.textAlign(TextAlign.Center)
        Row.pop();
        // 标签栏
        Row.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            If.create();
            // 内容区域
            if (this.currentTab === 0) {
                this.ifElseBranchUpdateFunction(0, () => {
                    this.recentStudyContent.bind(this)();
                });
            }
            else {
                this.ifElseBranchUpdateFunction(1, () => {
                    this.myPurchasesContent.bind(this)();
                });
            }
        }, If);
        If.pop();
        Column.pop();
        Scroll.pop();
    }
    // 近期学习内容
    recentStudyContent(parent = null) {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/Study.ets(107:5)", "entry");
        }, Column);
        this.courseItem.bind(this)('课程封面1.png', 'ArkUI开发入门', '学习至第3章', '80%');
        this.courseItem.bind(this)('课程封面2.png', 'HarmonyOS应用开发', '学习至第5章', '65%');
        this.courseItem.bind(this)('课程封面3.png', 'ArkTs基础知识', '学习至第6章', '70%');
        this.courseItem.bind(this)('课程封面4.png', '应用程序入口', '学习至第2章', '50%');
        Column.pop();
    }
    // 我的购买内容
    myPurchasesContent(parent = null) {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/Study.ets(118:5)", "entry");
            Column.onClick(() => { this.ClickEvent(); });
        }, Column);
        this.courseItem.bind(this)('课程封面4.png', 'TypeScript进阶', '已购买', '');
        this.courseItem.bind(this)('课程封面5.png', '前端性能优化', '已购买', '');
        this.courseItem.bind(this)('课程封面6', 'ArkTs开发实践', '已购买', '');
        Column.pop();
    }
    // 课程项组件
    courseItem(image: string, title: string, subTitle: string, progress: string, parent = null) {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/Study.ets(129:5)", "entry");
            Row.width('100%');
            Row.padding(12);
            Row.margin({ bottom: 12 });
            Row.backgroundColor('#F9F9F9');
            Row.borderRadius(8);
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 课程封面
            Image.create({ "id": 0, "type": 30000, params: ['image/edu2.jpg'], "bundleName": "com.example.myapplication", "moduleName": "entry" });
            Image.debugLine("entry/src/main/ets/pages/Study.ets(131:7)", "entry");
            // 课程封面
            Image.width(80);
            // 课程封面
            Image.height(60);
            // 课程封面
            Image.objectFit(ImageFit.Cover);
            // 课程封面
            Image.borderRadius(4);
        }, Image);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 课程信息
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/Study.ets(138:7)", "entry");
            // 课程信息
            Column.margin({ left: 12 });
            // 课程信息
            Column.alignItems(HorizontalAlign.Start);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(title);
            Text.debugLine("entry/src/main/ets/pages/Study.ets(139:9)", "entry");
            Text.fontSize(16);
            Text.fontWeight(FontWeight.Medium);
            Text.margin({ bottom: 4 });
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(subTitle);
            Text.debugLine("entry/src/main/ets/pages/Study.ets(144:9)", "entry");
            Text.fontSize(12);
            Text.fontColor('#999999');
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            If.create();
            if (progress) {
                this.ifElseBranchUpdateFunction(0, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Row.create();
                        Row.debugLine("entry/src/main/ets/pages/Study.ets(149:11)", "entry");
                        Row.width('100%');
                        Row.margin({ top: 8 });
                    }, Row);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Progress.create({ value: parseInt(progress), total: 100, type: ProgressType.Linear });
                        Progress.debugLine("entry/src/main/ets/pages/Study.ets(150:13)", "entry");
                        Progress.width('70%');
                        Progress.height(4);
                    }, Progress);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create(progress);
                        Text.debugLine("entry/src/main/ets/pages/Study.ets(154:13)", "entry");
                        Text.fontSize(12);
                        Text.margin({ left: 8 });
                    }, Text);
                    Text.pop();
                    Row.pop();
                });
            }
            else {
                this.ifElseBranchUpdateFunction(1, () => {
                });
            }
        }, If);
        If.pop();
        // 课程信息
        Column.pop();
        Row.pop();
    }
    ClickEvent() {
        router.pushUrl({
            url: 'pages/buyPage'
        });
    }
    rerender() {
        this.updateDirtyElements();
    }
    static getEntryName(): string {
        return "index3";
    }
}
registerNamedRoute(() => new index3(undefined, {}), "", { bundleName: "com.example.myapplication", moduleName: "entry", pagePath: "pages/Study", pageFullPath: "entry/src/main/ets/pages/Study", integratedHsp: "false", moduleType: "followWithHap" });
