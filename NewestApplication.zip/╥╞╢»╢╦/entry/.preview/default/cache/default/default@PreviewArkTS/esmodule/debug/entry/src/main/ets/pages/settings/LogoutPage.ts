if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface LogoutPage_Params {
}
import router from "@ohos:router";
class LogoutPage extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: LogoutPage_Params) {
    }
    updateStateVars(params: LogoutPage_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
    }
    aboutToBeDeleted() {
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create({ space: 30 });
            Column.debugLine("entry/src/main/ets/pages/settings/LogoutPage.ets(8:5)", "entry");
            Column.padding(50);
            Column.alignItems(HorizontalAlign.Center);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('确定要退出当前账号吗？');
            Text.debugLine("entry/src/main/ets/pages/settings/LogoutPage.ets(9:7)", "entry");
            Text.fontSize(20);
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create({ space: 20 });
            Row.debugLine("entry/src/main/ets/pages/settings/LogoutPage.ets(12:7)", "entry");
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Button.createWithLabel('取消');
            Button.debugLine("entry/src/main/ets/pages/settings/LogoutPage.ets(13:9)", "entry");
            Button.onClick(() => {
                router.back();
            });
        }, Button);
        Button.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Button.createWithLabel('退出登录');
            Button.debugLine("entry/src/main/ets/pages/settings/LogoutPage.ets(18:9)", "entry");
            Button.type(ButtonType.Capsule);
            Button.onClick(() => {
                // 清除缓存 / token / 用户信息
                console.log('用户已退出');
                router.replaceUrl({ url: 'pages/LoginPage' });
            });
        }, Button);
        Button.pop();
        Row.pop();
        Column.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
    static getEntryName(): string {
        return "LogoutPage";
    }
}
registerNamedRoute(() => new LogoutPage(undefined, {}), "", { bundleName: "com.example.myapplication", moduleName: "entry", pagePath: "pages/settings/LogoutPage", pageFullPath: "entry/src/main/ets/pages/settings/LogoutPage", integratedHsp: "false", moduleType: "followWithHap" });
