if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface Index1_Params {
    swiperImages?: string[];
}
export default class Index1 extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.__swiperImages = new ObservedPropertyObjectPU(['edu1.jpg', 'edu2.jpg', 'edu3.jpg', 'edu4.jpg', 'edu5.jpg']
        // @State arr:number[]=[0,1,2,3,4,5,6]
        , this, "swiperImages");
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: Index1_Params) {
        if (params.swiperImages !== undefined) {
            this.swiperImages = params.swiperImages;
        }
    }
    updateStateVars(params: Index1_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__swiperImages.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__swiperImages.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    private __swiperImages: ObservedPropertyObjectPU<string[]>;
    get swiperImages() {
        return this.__swiperImages.get();
    }
    set swiperImages(newValue: string[]) {
        this.__swiperImages.set(newValue);
    }
    // @State arr:number[]=[0,1,2,3,4,5,6]
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Scroll.create();
            Scroll.debugLine("entry/src/main/ets/pages/Index1.ets(10:5)", "entry");
            Scroll.width('100%');
            Scroll.height('100%');
            Scroll.align(Alignment.Top);
        }, Scroll);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create({ space: 15 });
            Column.debugLine("entry/src/main/ets/pages/Index1.ets(11:7)", "entry");
            Column.width('100%');
            Column.justifyContent(FlexAlign.Start);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Search.create({ placeholder: '想问什么都可以' });
            Search.debugLine("entry/src/main/ets/pages/Index1.ets(12:9)", "entry");
            Search.searchButton("探索");
        }, Search);
        Search.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 轮播图
            Swiper.create();
            Swiper.debugLine("entry/src/main/ets/pages/Index1.ets(15:9)", "entry");
            // 轮播图
            Swiper.width('95%');
            // 轮播图
            Swiper.borderRadius(15);
            // 轮播图
            Swiper.indicator(new DotIndicator().color(Color.Black).selectedColor(Color.Red));
        }, Swiper);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            ForEach.create();
            const forEachItemGenFunction = (_item, index: number) => {
                const item = _item;
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Image.create({ "id": -1, "type": 30000, params: ['image/' + item], "bundleName": "com.example.myapplication", "moduleName": "entry" });
                    Image.debugLine("entry/src/main/ets/pages/Index1.ets(17:13)", "entry");
                    Image.width('100%');
                }, Image);
            };
            this.forEachUpdateFunction(elmtId, this.swiperImages, forEachItemGenFunction, undefined, true, false);
        }, ForEach);
        ForEach.pop();
        // 轮播图
        Swiper.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create({ space: 5 });
            Row.debugLine("entry/src/main/ets/pages/Index1.ets(23:8)", "entry");
            Row.width('95%');
            Row.height(120);
            Row.shadow({
                radius: 25,
                color: Color.Blue,
                offsetX: 2,
                offsetY: 4
            });
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/Index1.ets(25:10)", "entry");
            Column.width('25%');
            Column.alignItems(HorizontalAlign.Center);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/Index1.ets(27:12)", "entry");
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Image.create({ "id": 0, "type": 30000, params: ['image/edu7.png'], "bundleName": "com.example.myapplication", "moduleName": "entry" });
            Image.debugLine("entry/src/main/ets/pages/Index1.ets(29:14)", "entry");
            Image.width(30);
        }, Image);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('课程');
            Text.debugLine("entry/src/main/ets/pages/Index1.ets(30:14)", "entry");
            Text.fontSize(18);
            Text.fontWeight(600);
        }, Text);
        Text.pop();
        Column.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/Index1.ets(32:11)", "entry");
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Image.create({ "id": 0, "type": 30000, params: ['image/edu6.jpg'], "bundleName": "com.example.myapplication", "moduleName": "entry" });
            Image.debugLine("entry/src/main/ets/pages/Index1.ets(34:13)", "entry");
            Image.width(30);
        }, Image);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('测评');
            Text.debugLine("entry/src/main/ets/pages/Index1.ets(35:13)", "entry");
            Text.fontSize(18);
            Text.fontWeight(600);
        }, Text);
        Text.pop();
        Column.pop();
        Column.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/Index1.ets(40:10)", "entry");
            Column.width('25%');
            Column.alignItems(HorizontalAlign.Center);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/Index1.ets(42:12)", "entry");
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Image.create({ "id": 0, "type": 30000, params: ['image/edu5.jpg'], "bundleName": "com.example.myapplication", "moduleName": "entry" });
            Image.debugLine("entry/src/main/ets/pages/Index1.ets(44:14)", "entry");
            Image.width(30);
        }, Image);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('班级');
            Text.debugLine("entry/src/main/ets/pages/Index1.ets(45:14)", "entry");
            Text.fontSize(18);
            Text.fontWeight(600);
        }, Text);
        Text.pop();
        Column.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/Index1.ets(47:12)", "entry");
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Image.create({ "id": 0, "type": 30000, params: ['image/edu4.jpg'], "bundleName": "com.example.myapplication", "moduleName": "entry" });
            Image.debugLine("entry/src/main/ets/pages/Index1.ets(49:14)", "entry");
            Image.width(30);
        }, Image);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('消息');
            Text.debugLine("entry/src/main/ets/pages/Index1.ets(50:16)", "entry");
            Text.fontSize(18);
            Text.fontWeight(600);
        }, Text);
        Text.pop();
        Column.pop();
        Column.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/Index1.ets(55:10)", "entry");
            Column.width('25%');
            Column.alignItems(HorizontalAlign.Center);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/Index1.ets(57:12)", "entry");
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Image.create({ "id": 0, "type": 30000, params: ['image/edu3.jpg'], "bundleName": "com.example.myapplication", "moduleName": "entry" });
            Image.debugLine("entry/src/main/ets/pages/Index1.ets(59:14)", "entry");
            Image.width(30);
        }, Image);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('圈子');
            Text.debugLine("entry/src/main/ets/pages/Index1.ets(60:14)", "entry");
            Text.fontSize(18);
            Text.fontWeight(600);
        }, Text);
        Text.pop();
        Column.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/Index1.ets(62:12)", "entry");
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Image.create({ "id": 0, "type": 30000, params: ['image/edu2.jpg'], "bundleName": "com.example.myapplication", "moduleName": "entry" });
            Image.debugLine("entry/src/main/ets/pages/Index1.ets(64:14)", "entry");
            Image.width(30);
        }, Image);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('我的收益');
            Text.debugLine("entry/src/main/ets/pages/Index1.ets(65:14)", "entry");
            Text.fontSize(18);
            Text.fontWeight(600);
        }, Text);
        Text.pop();
        Column.pop();
        Column.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/Index1.ets(70:10)", "entry");
            Column.width('25%');
            Column.alignItems(HorizontalAlign.Center);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/Index1.ets(72:12)", "entry");
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Image.create({ "id": 0, "type": 30000, params: ['image/edu1.jpg'], "bundleName": "com.example.myapplication", "moduleName": "entry" });
            Image.debugLine("entry/src/main/ets/pages/Index1.ets(74:14)", "entry");
            Image.width(30);
        }, Image);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('计划');
            Text.debugLine("entry/src/main/ets/pages/Index1.ets(75:14)", "entry");
            Text.fontSize(18);
            Text.fontWeight(600);
        }, Text);
        Text.pop();
        Column.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/Index1.ets(77:12)", "entry");
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Image.create({ "id": 0, "type": 30000, params: ['image/edu7.png'], "bundleName": "com.example.myapplication", "moduleName": "entry" });
            Image.debugLine("entry/src/main/ets/pages/Index1.ets(79:14)", "entry");
            Image.width(30);
        }, Image);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('回收站');
            Text.debugLine("entry/src/main/ets/pages/Index1.ets(80:14)", "entry");
            Text.fontSize(18);
            Text.fontWeight(600);
        }, Text);
        Text.pop();
        Column.pop();
        Column.pop();
        Row.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            //热门课程
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/Index1.ets(95:9)", "entry");
            //热门课程
            Row.width('95%');
            //热门课程
            Row.alignItems(VerticalAlign.Bottom);
            //热门课程
            Row.justifyContent(FlexAlign.SpaceBetween);
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('热门课程');
            Text.debugLine("entry/src/main/ets/pages/Index1.ets(96:11)", "entry");
            Text.fontSize(18);
            Text.fontWeight(600);
        }, Text);
        Text.pop();
        //热门课程
        Row.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            List.create({ space: 15 });
            List.debugLine("entry/src/main/ets/pages/Index1.ets(103:9)", "entry");
            List.width('95%');
        }, List);
        {
            const itemCreation = (elmtId, isInitialRender) => {
                ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                itemCreation2(elmtId, isInitialRender);
                if (!isInitialRender) {
                    ListItem.pop();
                }
                ViewStackProcessor.StopGetAccessRecording();
            };
            const itemCreation2 = (elmtId, isInitialRender) => {
                ListItem.create(deepRenderFunction, true);
                ListItem.debugLine("entry/src/main/ets/pages/Index1.ets(105:15)", "entry");
            };
            const deepRenderFunction = (elmtId, isInitialRender) => {
                itemCreation(elmtId, isInitialRender);
                this.listCard.bind(this)();
                ListItem.pop();
            };
            this.observeComponentCreation2(itemCreation2, ListItem);
            ListItem.pop();
        }
        List.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            List.create({ space: 15 });
            List.debugLine("entry/src/main/ets/pages/Index1.ets(111:9)", "entry");
            List.width('95%');
        }, List);
        {
            const itemCreation = (elmtId, isInitialRender) => {
                ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                itemCreation2(elmtId, isInitialRender);
                if (!isInitialRender) {
                    ListItem.pop();
                }
                ViewStackProcessor.StopGetAccessRecording();
            };
            const itemCreation2 = (elmtId, isInitialRender) => {
                ListItem.create(deepRenderFunction, true);
                ListItem.debugLine("entry/src/main/ets/pages/Index1.ets(113:11)", "entry");
            };
            const deepRenderFunction = (elmtId, isInitialRender) => {
                itemCreation(elmtId, isInitialRender);
                this.listCard1.bind(this)();
                ListItem.pop();
            };
            this.observeComponentCreation2(itemCreation2, ListItem);
            ListItem.pop();
        }
        List.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            List.create({ space: 15 });
            List.debugLine("entry/src/main/ets/pages/Index1.ets(119:9)", "entry");
            List.width('95%');
        }, List);
        {
            const itemCreation = (elmtId, isInitialRender) => {
                ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                itemCreation2(elmtId, isInitialRender);
                if (!isInitialRender) {
                    ListItem.pop();
                }
                ViewStackProcessor.StopGetAccessRecording();
            };
            const itemCreation2 = (elmtId, isInitialRender) => {
                ListItem.create(deepRenderFunction, true);
                ListItem.debugLine("entry/src/main/ets/pages/Index1.ets(121:11)", "entry");
            };
            const deepRenderFunction = (elmtId, isInitialRender) => {
                itemCreation(elmtId, isInitialRender);
                this.listCard2.bind(this)();
                ListItem.pop();
            };
            this.observeComponentCreation2(itemCreation2, ListItem);
            ListItem.pop();
        }
        List.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            List.create({ space: 15 });
            List.debugLine("entry/src/main/ets/pages/Index1.ets(127:9)", "entry");
            List.width('95%');
        }, List);
        {
            const itemCreation = (elmtId, isInitialRender) => {
                ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                itemCreation2(elmtId, isInitialRender);
                if (!isInitialRender) {
                    ListItem.pop();
                }
                ViewStackProcessor.StopGetAccessRecording();
            };
            const itemCreation2 = (elmtId, isInitialRender) => {
                ListItem.create(deepRenderFunction, true);
                ListItem.debugLine("entry/src/main/ets/pages/Index1.ets(129:11)", "entry");
            };
            const deepRenderFunction = (elmtId, isInitialRender) => {
                itemCreation(elmtId, isInitialRender);
                this.listCard3.bind(this)();
                ListItem.pop();
            };
            this.observeComponentCreation2(itemCreation2, ListItem);
            ListItem.pop();
        }
        List.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            List.create({ space: 15 });
            List.debugLine("entry/src/main/ets/pages/Index1.ets(135:9)", "entry");
            List.width('95%');
        }, List);
        {
            const itemCreation = (elmtId, isInitialRender) => {
                ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                itemCreation2(elmtId, isInitialRender);
                if (!isInitialRender) {
                    ListItem.pop();
                }
                ViewStackProcessor.StopGetAccessRecording();
            };
            const itemCreation2 = (elmtId, isInitialRender) => {
                ListItem.create(deepRenderFunction, true);
                ListItem.debugLine("entry/src/main/ets/pages/Index1.ets(137:11)", "entry");
            };
            const deepRenderFunction = (elmtId, isInitialRender) => {
                itemCreation(elmtId, isInitialRender);
                this.listCard4.bind(this)();
                ListItem.pop();
            };
            this.observeComponentCreation2(itemCreation2, ListItem);
            ListItem.pop();
        }
        List.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            List.create({ space: 15 });
            List.debugLine("entry/src/main/ets/pages/Index1.ets(143:9)", "entry");
            List.width('95%');
        }, List);
        {
            const itemCreation = (elmtId, isInitialRender) => {
                ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                itemCreation2(elmtId, isInitialRender);
                if (!isInitialRender) {
                    ListItem.pop();
                }
                ViewStackProcessor.StopGetAccessRecording();
            };
            const itemCreation2 = (elmtId, isInitialRender) => {
                ListItem.create(deepRenderFunction, true);
                ListItem.debugLine("entry/src/main/ets/pages/Index1.ets(145:11)", "entry");
            };
            const deepRenderFunction = (elmtId, isInitialRender) => {
                itemCreation(elmtId, isInitialRender);
                this.listCard5.bind(this)();
                ListItem.pop();
            };
            this.observeComponentCreation2(itemCreation2, ListItem);
            ListItem.pop();
        }
        List.pop();
        Column.pop();
        Scroll.pop();
    }
    listCard(parent = null) {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/Index1.ets(161:5)", "entry");
            Row.width('100%');
            Row.height(100);
            Row.padding(10);
            Row.borderRadius(10);
            Row.backgroundColor('#FFFFFF');
            Row.justifyContent(FlexAlign.SpaceBetween);
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/Index1.ets(162:7)", "entry");
            Column.width('60%');
            Column.height('90%');
            Column.alignItems(HorizontalAlign.Start);
            Column.justifyContent(FlexAlign.SpaceBetween);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/Index1.ets(163:9)", "entry");
            Column.width('100%');
            Column.alignItems(HorizontalAlign.Start);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('TypeScript快速入门');
            Text.debugLine("entry/src/main/ets/pages/Index1.ets(164:11)", "entry");
            Text.fontSize(14);
            Text.maxLines(2);
            Text.textOverflow({ overflow: TextOverflow.Ellipsis });
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('2022/02/21更新');
            Text.debugLine("entry/src/main/ets/pages/Index1.ets(166:11)", "entry");
            Text.fontColor('#999999');
            Text.fontSize(12);
            Text.maxLines(1);
            Text.textOverflow({ overflow: TextOverflow.Ellipsis });
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/Index1.ets(168:11)", "entry");
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('66.6');
            Text.debugLine("entry/src/main/ets/pages/Index1.ets(170:13)", "entry");
            Text.fontColor(Color.Red);
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('周卓');
            Text.debugLine("entry/src/main/ets/pages/Index1.ets(171:13)", "entry");
            Text.fontColor(Color.Red);
            Text.padding({ left: 50 });
        }, Text);
        Text.pop();
        Row.pop();
        Column.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/Index1.ets(175:9)", "entry");
            Row.width('100%');
            Row.justifyContent(FlexAlign.SpaceBetween);
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create({ space: 3 });
            Row.debugLine("entry/src/main/ets/pages/Index1.ets(176:11)", "entry");
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Image.create({ "id": 0, "type": 30000, params: ['icons/eye.svg'], "bundleName": "com.example.myapplication", "moduleName": "entry" });
            Image.debugLine("entry/src/main/ets/pages/Index1.ets(177:13)", "entry");
            Image.width(14);
        }, Image);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('123');
            Text.debugLine("entry/src/main/ets/pages/Index1.ets(178:13)", "entry");
            Text.fontSize(12);
        }, Text);
        Text.pop();
        Row.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create({ space: 3 });
            Row.debugLine("entry/src/main/ets/pages/Index1.ets(181:11)", "entry");
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Image.create({ "id": 0, "type": 30000, params: ['icons/hand_thumbsup_fill.svg'], "bundleName": "com.example.myapplication", "moduleName": "entry" });
            Image.debugLine("entry/src/main/ets/pages/Index1.ets(182:13)", "entry");
            Image.width(14);
        }, Image);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('123');
            Text.debugLine("entry/src/main/ets/pages/Index1.ets(183:13)", "entry");
            Text.fontSize(12);
        }, Text);
        Text.pop();
        Row.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create({ space: 3 });
            Row.debugLine("entry/src/main/ets/pages/Index1.ets(186:11)", "entry");
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Image.create({ "id": 0, "type": 30000, params: ['icons/star.svg'], "bundleName": "com.example.myapplication", "moduleName": "entry" });
            Image.debugLine("entry/src/main/ets/pages/Index1.ets(187:13)", "entry");
            Image.width(14);
        }, Image);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('123');
            Text.debugLine("entry/src/main/ets/pages/Index1.ets(188:13)", "entry");
            Text.fontSize(12);
        }, Text);
        Text.pop();
        Row.pop();
        Row.pop();
        Column.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Image.create({ "id": 0, "type": 30000, params: ['image/edu8.png'], "bundleName": "com.example.myapplication", "moduleName": "entry" });
            Image.debugLine("entry/src/main/ets/pages/Index1.ets(198:7)", "entry");
            Image.width('35%');
            Image.height('100%');
            Image.borderRadius(5);
        }, Image);
        Row.pop();
    }
    listCard1(parent = null) {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/Index1.ets(209:5)", "entry");
            Row.width('100%');
            Row.height(100);
            Row.padding(10);
            Row.borderRadius(10);
            Row.backgroundColor('#FFFFFF');
            Row.justifyContent(FlexAlign.SpaceBetween);
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/Index1.ets(210:7)", "entry");
            Column.width('60%');
            Column.height('90%');
            Column.alignItems(HorizontalAlign.Start);
            Column.justifyContent(FlexAlign.SpaceBetween);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/Index1.ets(211:9)", "entry");
            Column.width('100%');
            Column.alignItems(HorizontalAlign.Start);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('ArkTs基础知识');
            Text.debugLine("entry/src/main/ets/pages/Index1.ets(212:11)", "entry");
            Text.fontSize(14);
            Text.maxLines(2);
            Text.textOverflow({ overflow: TextOverflow.Ellipsis });
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('2022/02/21更新');
            Text.debugLine("entry/src/main/ets/pages/Index1.ets(214:11)", "entry");
            Text.fontColor('#999999');
            Text.fontSize(12);
            Text.maxLines(1);
            Text.textOverflow({ overflow: TextOverflow.Ellipsis });
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/Index1.ets(216:11)", "entry");
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('48.5');
            Text.debugLine("entry/src/main/ets/pages/Index1.ets(218:13)", "entry");
            Text.fontColor(Color.Red);
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('周卓');
            Text.debugLine("entry/src/main/ets/pages/Index1.ets(219:13)", "entry");
            Text.fontColor(Color.Red);
            Text.padding({ left: 50 });
        }, Text);
        Text.pop();
        Row.pop();
        Column.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/Index1.ets(223:9)", "entry");
            Row.width('100%');
            Row.justifyContent(FlexAlign.SpaceBetween);
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create({ space: 3 });
            Row.debugLine("entry/src/main/ets/pages/Index1.ets(224:11)", "entry");
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Image.create({ "id": 0, "type": 30000, params: ['icons/eye.svg'], "bundleName": "com.example.myapplication", "moduleName": "entry" });
            Image.debugLine("entry/src/main/ets/pages/Index1.ets(225:13)", "entry");
            Image.width(14);
        }, Image);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('123');
            Text.debugLine("entry/src/main/ets/pages/Index1.ets(226:13)", "entry");
            Text.fontSize(12);
        }, Text);
        Text.pop();
        Row.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create({ space: 3 });
            Row.debugLine("entry/src/main/ets/pages/Index1.ets(229:11)", "entry");
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Image.create({ "id": 0, "type": 30000, params: ['icons/hand_thumbsup_fill.svg'], "bundleName": "com.example.myapplication", "moduleName": "entry" });
            Image.debugLine("entry/src/main/ets/pages/Index1.ets(230:13)", "entry");
            Image.width(14);
        }, Image);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('123');
            Text.debugLine("entry/src/main/ets/pages/Index1.ets(231:13)", "entry");
            Text.fontSize(12);
        }, Text);
        Text.pop();
        Row.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create({ space: 3 });
            Row.debugLine("entry/src/main/ets/pages/Index1.ets(234:11)", "entry");
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Image.create({ "id": 0, "type": 30000, params: ['icons/star.svg'], "bundleName": "com.example.myapplication", "moduleName": "entry" });
            Image.debugLine("entry/src/main/ets/pages/Index1.ets(235:13)", "entry");
            Image.width(14);
        }, Image);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('123');
            Text.debugLine("entry/src/main/ets/pages/Index1.ets(236:13)", "entry");
            Text.fontSize(12);
        }, Text);
        Text.pop();
        Row.pop();
        Row.pop();
        Column.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Image.create({ "id": 0, "type": 30000, params: ['image/edu9.png'], "bundleName": "com.example.myapplication", "moduleName": "entry" });
            Image.debugLine("entry/src/main/ets/pages/Index1.ets(246:7)", "entry");
            Image.width('35%');
            Image.height('100%');
            Image.borderRadius(5);
        }, Image);
        Row.pop();
    }
    listCard2(parent = null) {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/Index1.ets(257:5)", "entry");
            Row.width('100%');
            Row.height(100);
            Row.padding(10);
            Row.borderRadius(10);
            Row.backgroundColor('#FFFFFF');
            Row.justifyContent(FlexAlign.SpaceBetween);
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/Index1.ets(258:7)", "entry");
            Column.width('60%');
            Column.height('90%');
            Column.alignItems(HorizontalAlign.Start);
            Column.justifyContent(FlexAlign.SpaceBetween);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/Index1.ets(259:9)", "entry");
            Column.width('100%');
            Column.alignItems(HorizontalAlign.Start);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('ArkTs开发实践');
            Text.debugLine("entry/src/main/ets/pages/Index1.ets(260:11)", "entry");
            Text.fontSize(14);
            Text.maxLines(2);
            Text.textOverflow({ overflow: TextOverflow.Ellipsis });
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('2022/02/21更新');
            Text.debugLine("entry/src/main/ets/pages/Index1.ets(262:11)", "entry");
            Text.fontColor('#999999');
            Text.fontSize(12);
            Text.maxLines(1);
            Text.textOverflow({ overflow: TextOverflow.Ellipsis });
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/Index1.ets(264:11)", "entry");
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('99.0');
            Text.debugLine("entry/src/main/ets/pages/Index1.ets(266:13)", "entry");
            Text.fontColor(Color.Red);
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('周卓');
            Text.debugLine("entry/src/main/ets/pages/Index1.ets(267:13)", "entry");
            Text.fontColor(Color.Red);
            Text.padding({ left: 50 });
        }, Text);
        Text.pop();
        Row.pop();
        Column.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/Index1.ets(271:9)", "entry");
            Row.width('100%');
            Row.justifyContent(FlexAlign.SpaceBetween);
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create({ space: 3 });
            Row.debugLine("entry/src/main/ets/pages/Index1.ets(272:11)", "entry");
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Image.create({ "id": 0, "type": 30000, params: ['icons/eye.svg'], "bundleName": "com.example.myapplication", "moduleName": "entry" });
            Image.debugLine("entry/src/main/ets/pages/Index1.ets(273:13)", "entry");
            Image.width(14);
        }, Image);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('123');
            Text.debugLine("entry/src/main/ets/pages/Index1.ets(274:13)", "entry");
            Text.fontSize(12);
        }, Text);
        Text.pop();
        Row.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create({ space: 3 });
            Row.debugLine("entry/src/main/ets/pages/Index1.ets(277:11)", "entry");
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Image.create({ "id": 0, "type": 30000, params: ['icons/hand_thumbsup_fill.svg'], "bundleName": "com.example.myapplication", "moduleName": "entry" });
            Image.debugLine("entry/src/main/ets/pages/Index1.ets(278:13)", "entry");
            Image.width(14);
        }, Image);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('123');
            Text.debugLine("entry/src/main/ets/pages/Index1.ets(279:13)", "entry");
            Text.fontSize(12);
        }, Text);
        Text.pop();
        Row.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create({ space: 3 });
            Row.debugLine("entry/src/main/ets/pages/Index1.ets(282:11)", "entry");
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Image.create({ "id": 0, "type": 30000, params: ['icons/star.svg'], "bundleName": "com.example.myapplication", "moduleName": "entry" });
            Image.debugLine("entry/src/main/ets/pages/Index1.ets(283:13)", "entry");
            Image.width(14);
        }, Image);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('123');
            Text.debugLine("entry/src/main/ets/pages/Index1.ets(284:13)", "entry");
            Text.fontSize(12);
        }, Text);
        Text.pop();
        Row.pop();
        Row.pop();
        Column.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Image.create({ "id": 0, "type": 30000, params: ['image/edu7.png'], "bundleName": "com.example.myapplication", "moduleName": "entry" });
            Image.debugLine("entry/src/main/ets/pages/Index1.ets(294:7)", "entry");
            Image.width('35%');
            Image.height('100%');
            Image.borderRadius(5);
        }, Image);
        Row.pop();
    }
    listCard3(parent = null) {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/Index1.ets(305:5)", "entry");
            Row.width('100%');
            Row.height(100);
            Row.padding(10);
            Row.borderRadius(10);
            Row.backgroundColor('#FFFFFF');
            Row.justifyContent(FlexAlign.SpaceBetween);
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/Index1.ets(306:7)", "entry");
            Column.width('60%');
            Column.height('90%');
            Column.alignItems(HorizontalAlign.Start);
            Column.justifyContent(FlexAlign.SpaceBetween);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/Index1.ets(307:9)", "entry");
            Column.width('100%');
            Column.alignItems(HorizontalAlign.Start);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('应用程序入口');
            Text.debugLine("entry/src/main/ets/pages/Index1.ets(308:11)", "entry");
            Text.fontSize(14);
            Text.maxLines(2);
            Text.textOverflow({ overflow: TextOverflow.Ellipsis });
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('2022/02/21更新');
            Text.debugLine("entry/src/main/ets/pages/Index1.ets(310:11)", "entry");
            Text.fontColor('#999999');
            Text.fontSize(12);
            Text.maxLines(1);
            Text.textOverflow({ overflow: TextOverflow.Ellipsis });
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/Index1.ets(312:11)", "entry");
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('9.9');
            Text.debugLine("entry/src/main/ets/pages/Index1.ets(314:13)", "entry");
            Text.fontColor(Color.Red);
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('周卓');
            Text.debugLine("entry/src/main/ets/pages/Index1.ets(315:13)", "entry");
            Text.fontColor(Color.Red);
            Text.padding({ left: 50 });
        }, Text);
        Text.pop();
        Row.pop();
        Column.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/Index1.ets(319:9)", "entry");
            Row.width('100%');
            Row.justifyContent(FlexAlign.SpaceBetween);
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create({ space: 3 });
            Row.debugLine("entry/src/main/ets/pages/Index1.ets(320:11)", "entry");
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Image.create({ "id": 0, "type": 30000, params: ['icons/eye.svg'], "bundleName": "com.example.myapplication", "moduleName": "entry" });
            Image.debugLine("entry/src/main/ets/pages/Index1.ets(321:13)", "entry");
            Image.width(14);
        }, Image);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('123');
            Text.debugLine("entry/src/main/ets/pages/Index1.ets(322:13)", "entry");
            Text.fontSize(12);
        }, Text);
        Text.pop();
        Row.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create({ space: 3 });
            Row.debugLine("entry/src/main/ets/pages/Index1.ets(325:11)", "entry");
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Image.create({ "id": 0, "type": 30000, params: ['icons/hand_thumbsup_fill.svg'], "bundleName": "com.example.myapplication", "moduleName": "entry" });
            Image.debugLine("entry/src/main/ets/pages/Index1.ets(326:13)", "entry");
            Image.width(14);
        }, Image);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('123');
            Text.debugLine("entry/src/main/ets/pages/Index1.ets(327:13)", "entry");
            Text.fontSize(12);
        }, Text);
        Text.pop();
        Row.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create({ space: 3 });
            Row.debugLine("entry/src/main/ets/pages/Index1.ets(330:11)", "entry");
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Image.create({ "id": 0, "type": 30000, params: ['icons/star.svg'], "bundleName": "com.example.myapplication", "moduleName": "entry" });
            Image.debugLine("entry/src/main/ets/pages/Index1.ets(331:13)", "entry");
            Image.width(14);
        }, Image);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('123');
            Text.debugLine("entry/src/main/ets/pages/Index1.ets(332:13)", "entry");
            Text.fontSize(12);
        }, Text);
        Text.pop();
        Row.pop();
        Row.pop();
        Column.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Image.create({ "id": 0, "type": 30000, params: ['image/edu6.jpg'], "bundleName": "com.example.myapplication", "moduleName": "entry" });
            Image.debugLine("entry/src/main/ets/pages/Index1.ets(342:7)", "entry");
            Image.width('35%');
            Image.height('100%');
            Image.borderRadius(5);
        }, Image);
        Row.pop();
    }
    listCard4(parent = null) {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/Index1.ets(353:5)", "entry");
            Row.width('100%');
            Row.height(100);
            Row.padding(10);
            Row.borderRadius(10);
            Row.backgroundColor('#FFFFFF');
            Row.justifyContent(FlexAlign.SpaceBetween);
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/Index1.ets(354:7)", "entry");
            Column.width('60%');
            Column.height('90%');
            Column.alignItems(HorizontalAlign.Start);
            Column.justifyContent(FlexAlign.SpaceBetween);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/Index1.ets(355:9)", "entry");
            Column.width('100%');
            Column.alignItems(HorizontalAlign.Start);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('Api基础知识');
            Text.debugLine("entry/src/main/ets/pages/Index1.ets(356:11)", "entry");
            Text.fontSize(14);
            Text.maxLines(2);
            Text.textOverflow({ overflow: TextOverflow.Ellipsis });
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('2022/02/21更新');
            Text.debugLine("entry/src/main/ets/pages/Index1.ets(358:11)", "entry");
            Text.fontColor('#999999');
            Text.fontSize(12);
            Text.maxLines(1);
            Text.textOverflow({ overflow: TextOverflow.Ellipsis });
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/Index1.ets(360:11)", "entry");
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('66.6');
            Text.debugLine("entry/src/main/ets/pages/Index1.ets(362:13)", "entry");
            Text.fontColor(Color.Red);
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('周卓');
            Text.debugLine("entry/src/main/ets/pages/Index1.ets(363:13)", "entry");
            Text.fontColor(Color.Red);
            Text.padding({ left: 50 });
        }, Text);
        Text.pop();
        Row.pop();
        Column.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/Index1.ets(367:9)", "entry");
            Row.width('100%');
            Row.justifyContent(FlexAlign.SpaceBetween);
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create({ space: 3 });
            Row.debugLine("entry/src/main/ets/pages/Index1.ets(368:11)", "entry");
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Image.create({ "id": 0, "type": 30000, params: ['icons/eye.svg'], "bundleName": "com.example.myapplication", "moduleName": "entry" });
            Image.debugLine("entry/src/main/ets/pages/Index1.ets(369:13)", "entry");
            Image.width(14);
        }, Image);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('123');
            Text.debugLine("entry/src/main/ets/pages/Index1.ets(370:13)", "entry");
            Text.fontSize(12);
        }, Text);
        Text.pop();
        Row.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create({ space: 3 });
            Row.debugLine("entry/src/main/ets/pages/Index1.ets(373:11)", "entry");
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Image.create({ "id": 0, "type": 30000, params: ['icons/hand_thumbsup_fill.svg'], "bundleName": "com.example.myapplication", "moduleName": "entry" });
            Image.debugLine("entry/src/main/ets/pages/Index1.ets(374:13)", "entry");
            Image.width(14);
        }, Image);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('123');
            Text.debugLine("entry/src/main/ets/pages/Index1.ets(375:13)", "entry");
            Text.fontSize(12);
        }, Text);
        Text.pop();
        Row.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create({ space: 3 });
            Row.debugLine("entry/src/main/ets/pages/Index1.ets(378:11)", "entry");
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Image.create({ "id": 0, "type": 30000, params: ['icons/star.svg'], "bundleName": "com.example.myapplication", "moduleName": "entry" });
            Image.debugLine("entry/src/main/ets/pages/Index1.ets(379:13)", "entry");
            Image.width(14);
        }, Image);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('123');
            Text.debugLine("entry/src/main/ets/pages/Index1.ets(380:13)", "entry");
            Text.fontSize(12);
        }, Text);
        Text.pop();
        Row.pop();
        Row.pop();
        Column.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Image.create({ "id": 0, "type": 30000, params: ['image/edu5.jpg'], "bundleName": "com.example.myapplication", "moduleName": "entry" });
            Image.debugLine("entry/src/main/ets/pages/Index1.ets(390:7)", "entry");
            Image.width('35%');
            Image.height('100%');
            Image.borderRadius(5);
        }, Image);
        Row.pop();
    }
    listCard5(parent = null) {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/Index1.ets(401:5)", "entry");
            Row.width('100%');
            Row.height(100);
            Row.padding(10);
            Row.borderRadius(10);
            Row.backgroundColor('#FFFFFF');
            Row.justifyContent(FlexAlign.SpaceBetween);
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/Index1.ets(402:7)", "entry");
            Column.width('60%');
            Column.height('90%');
            Column.alignItems(HorizontalAlign.Start);
            Column.justifyContent(FlexAlign.SpaceBetween);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/Index1.ets(403:9)", "entry");
            Column.width('100%');
            Column.alignItems(HorizontalAlign.Start);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('API实践训练');
            Text.debugLine("entry/src/main/ets/pages/Index1.ets(404:11)", "entry");
            Text.fontSize(14);
            Text.maxLines(2);
            Text.textOverflow({ overflow: TextOverflow.Ellipsis });
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('2022/02/21更新');
            Text.debugLine("entry/src/main/ets/pages/Index1.ets(406:11)", "entry");
            Text.fontColor('#999999');
            Text.fontSize(12);
            Text.maxLines(1);
            Text.textOverflow({ overflow: TextOverflow.Ellipsis });
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/Index1.ets(408:11)", "entry");
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('62.6');
            Text.debugLine("entry/src/main/ets/pages/Index1.ets(410:13)", "entry");
            Text.fontColor(Color.Red);
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('周卓');
            Text.debugLine("entry/src/main/ets/pages/Index1.ets(411:13)", "entry");
            Text.fontColor(Color.Red);
            Text.padding({ left: 50 });
        }, Text);
        Text.pop();
        Row.pop();
        Column.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/Index1.ets(415:9)", "entry");
            Row.width('100%');
            Row.justifyContent(FlexAlign.SpaceBetween);
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create({ space: 3 });
            Row.debugLine("entry/src/main/ets/pages/Index1.ets(416:11)", "entry");
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Image.create({ "id": 0, "type": 30000, params: ['icons/eye.svg'], "bundleName": "com.example.myapplication", "moduleName": "entry" });
            Image.debugLine("entry/src/main/ets/pages/Index1.ets(417:13)", "entry");
            Image.width(14);
        }, Image);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('123');
            Text.debugLine("entry/src/main/ets/pages/Index1.ets(418:13)", "entry");
            Text.fontSize(12);
        }, Text);
        Text.pop();
        Row.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create({ space: 3 });
            Row.debugLine("entry/src/main/ets/pages/Index1.ets(421:11)", "entry");
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Image.create({ "id": 0, "type": 30000, params: ['icons/hand_thumbsup_fill.svg'], "bundleName": "com.example.myapplication", "moduleName": "entry" });
            Image.debugLine("entry/src/main/ets/pages/Index1.ets(422:13)", "entry");
            Image.width(14);
        }, Image);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('123');
            Text.debugLine("entry/src/main/ets/pages/Index1.ets(423:13)", "entry");
            Text.fontSize(12);
        }, Text);
        Text.pop();
        Row.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create({ space: 3 });
            Row.debugLine("entry/src/main/ets/pages/Index1.ets(426:11)", "entry");
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Image.create({ "id": 0, "type": 30000, params: ['icons/star.svg'], "bundleName": "com.example.myapplication", "moduleName": "entry" });
            Image.debugLine("entry/src/main/ets/pages/Index1.ets(427:13)", "entry");
            Image.width(14);
        }, Image);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('123');
            Text.debugLine("entry/src/main/ets/pages/Index1.ets(428:13)", "entry");
            Text.fontSize(12);
        }, Text);
        Text.pop();
        Row.pop();
        Row.pop();
        Column.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Image.create({ "id": 0, "type": 30000, params: ['image/edu4.jpg'], "bundleName": "com.example.myapplication", "moduleName": "entry" });
            Image.debugLine("entry/src/main/ets/pages/Index1.ets(438:7)", "entry");
            Image.width('35%');
            Image.height('100%');
            Image.borderRadius(5);
        }, Image);
        Row.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
}
