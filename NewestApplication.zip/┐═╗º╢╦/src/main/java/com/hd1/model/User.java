package com.hd1.model;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.ToString;
@ToString
@Data
@AllArgsConstructor
public class User
{
    //int id;
    String Username;
    String Password;
    //String PhoneNumber;
}
