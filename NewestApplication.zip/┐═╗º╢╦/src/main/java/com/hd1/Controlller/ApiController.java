/*package com.hd1.Controlller;
import com.hd1.model.User;
import java.util.HashMap;
import java.util.Map;
import org.springframework.web.bind.annotation.*;
import com.hd1.Db.DataBase;

@RestController
@RequestMapping("/api")
public class ApiController {
  @PostMapping("/MyLogin")
  public Map<String, Object> MyLogin(@RequestBody User user)
  {
    Map<String, Object> map = new HashMap<>();
    System.out.println("开始查询........登录用户名" + "正在检索账户:" + user.getUsername() + "正在检索密码" + user.getPassword());
    //User currentuser = new User(user.getUsername(), user.getPassword());
    for(User item:DataBase.UserTable)
    {
      if (item.getUsername().equals(user.getUsername())&&item.getPassword().equals(user.getPassword()))
      {
       User currentuser = user;
        map.put("code", 200);
        map.put("user", currentuser);
        return map;
      }
      else
      {
        map.put("code", 500);
        map.put("message", "账户名或者密码错误");
      }
    }
    return map;
  }
  @PostMapping("/insertUser")
  public Map<String,Object> insertUser(@RequestBody User user)
  {
    Map<String, Object> map = new HashMap<>();
    DataBase.UserTable.add(user);
    map.put("code", 200);
    map.put("message", "success");
    //遍历数据库看是否添加成功
    for(User item:DataBase.UserTable)
    {
      System.out.println(item);
    }
    return map;
  }
  @PostMapping("/updateUser")
  public Map<String,Object> updateUser(@RequestBody User user)
  {
    Map<String, Object> map = new HashMap<>();
    for(User item:DataBase.UserTable)
    {
      if (item.getUsername() == user.getUsername())
      {
           DataBase.UserTable.remove(item);//删除原有记录
           DataBase.UserTable.add(user);//将新数据添加到数据库
      }
    }
    //修改成功后，遍历数据库确认数据是否修改成功
    for(User item:DataBase.UserTable)
    {
      System.out.println(item);
    }
    map.put("code", 200);
    return map;
  }
}*/
package com.hd1.Controlller;

import com.hd1.Db.DataBase;
import com.hd1.model.User;
import org.springframework.web.bind.annotation.*;
import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/api")
public class ApiController {

  // 用户登录
  @PostMapping("/MyLogin")
  public Map<String, Object> login(@RequestBody User user) {
    Map<String, Object> map = new HashMap<>();
    if (DataBase.validateUser(user.getUsername(), user.getPassword())) {
      map.put("code", 200);
      map.put("user", user);
    } else {
      map.put("code", 500);
      map.put("message", "用户名或密码错误");
    }
    return map;
  }

  // 添加用户
  @PostMapping("/insertUser")
  public Map<String, Object> insertUser(@RequestBody User user) {
    Map<String, Object> map = new HashMap<>();
    if (DataBase.insertUser(user)) {
      map.put("code", 200);
      map.put("message", "用户添加成功");
    } else {
      map.put("code", 500);
      map.put("message", "用户已存在");
    }
    DataBase.printAllUsers(); // 调试打印
    return map;
  }

  // 更新用户
  @PostMapping("/updateUser")
  public Map<String, Object> updateUser(@RequestBody User user) {
    Map<String, Object> map = new HashMap<>();
    if (DataBase.updateUser(user)) {
      map.put("code", 200);
      map.put("message", "用户更新成功");
    } else {
      map.put("code", 500);
      map.put("message", "用户不存在");
    }
    DataBase.printAllUsers(); // 调试打印
    return map;
  }

  // 删除用户
  @DeleteMapping("/deleteUser/{username}")
  public Map<String, Object> deleteUser(@PathVariable String username) {
    Map<String, Object> map = new HashMap<>();
    if (DataBase.deleteUser(username)) {
      map.put("code", 200);
      map.put("message", "用户删除成功");
    } else {
      map.put("code", 500);
      map.put("message", "用户不存在");
    }
    return map;
  }
}