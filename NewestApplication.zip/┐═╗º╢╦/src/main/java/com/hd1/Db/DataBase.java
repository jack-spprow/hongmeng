/*package com.hd1.Db;

import com.hd1.model.User;

import java.util.ArrayList;
import java.util.List;

public class DataBase
{

    public static void initDataBase()
    {
           DataBase.UserTable.add(new User("22","222222"));
           DataBase.UserTable.add(new User("33","333333"));

    }
}*/
package com.hd1.Db;

import com.hd1.model.User;
import java.util.ArrayList;
import java.util.List;

public class DataBase {
    public static List<User> UserTable = new ArrayList<>();

    // 初始化测试数据
    public static void initDataBase() {
        UserTable.add(new User("admin", "123456"));
        UserTable.add(new User("user1", "111111"));
    }

    // 增：添加用户
    public static boolean insertUser(User user) {
        if (findUserByUsername(user.getUsername()) != null) {
            return false; // 用户已存在
        }
        UserTable.add(user);
        return true;
    }

    // 删：根据用户名删除用户
    public static boolean deleteUser(String username) {
        return UserTable.removeIf(user -> user.getUsername().equals(username));
    }

    // 改：更新用户信息
    public static boolean updateUser(User user) {
        deleteUser(user.getUsername()); // 先删除旧数据
        return insertUser(user);       // 再插入新数据
    }

    // 查：根据用户名查找用户
    public static User findUserByUsername(String username) {
        return UserTable.stream()
                .filter(user -> user.getUsername().equals(username))
                .findFirst()
                .orElse(null);
    }

    // 查：验证用户登录
    public static boolean validateUser(String username, String password) {
        User user = findUserByUsername(username);
        return user != null && user.getPassword().equals(password);
    }

    // 打印所有用户（调试用）
    public static void printAllUsers() {
        UserTable.forEach(System.out::println);
    }
}