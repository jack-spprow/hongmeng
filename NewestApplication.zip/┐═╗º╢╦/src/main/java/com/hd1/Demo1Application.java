package com.hd1;

import com.hd1.Db.DataBase;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Demo1Application {

    public static void main(String[] args) {
        DataBase.initDataBase();
        SpringApplication.run(Demo1Application.class, args);
    }

}
